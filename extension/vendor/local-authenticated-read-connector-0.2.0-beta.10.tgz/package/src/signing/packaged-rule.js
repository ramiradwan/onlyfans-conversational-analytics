import { ORIGIN } from './operations.js';
import {
  createSignatureFromDigest,
  createSigningInput,
  validateRenewableSigningConfig,
  webCryptoSha1Hex,
} from './renewable-signing.js';

export const PACKAGED_SIGNING_RULE_SCHEMA = 'local-packaged-signing-rule/v1';

const OBSERVED_STATIC_HEADERS = Object.freeze(['accept', 'app-token', 'x-bc', 'x-of-rev']);
const REQUIRED_OBSERVED_HEADERS = Object.freeze(['app-token', 'x-bc', 'x-of-rev']);
const OBSERVED_CAPTURE_HEADERS = new Set([
  ...OBSERVED_STATIC_HEADERS,
  'sign',
  'time',
  'user-id',
]);
const IDENTITY_PATH = '/api2/v2/users/me';

function hasOnlyKeys(value, keys) {
  return Object.keys(value).every((key) => keys.has(key));
}

function copyFormat(format) {
  if (
    !format ||
    typeof format !== 'object' ||
    Array.isArray(format) ||
    !hasOnlyKeys(
      format,
      new Set(['prefix', 'suffix', 'checksum_indexes', 'checksum_constant']),
    ) ||
    typeof format.prefix !== 'string' ||
    format.prefix.length === 0 ||
    format.prefix.length > 128 ||
    format.prefix.includes(':') ||
    typeof format.suffix !== 'string' ||
    format.suffix.length === 0 ||
    format.suffix.length > 128 ||
    format.suffix.includes(':') ||
    !Array.isArray(format.checksum_indexes) ||
    format.checksum_indexes.length === 0 ||
    format.checksum_indexes.length > 256 ||
    !Number.isSafeInteger(format.checksum_constant)
  ) {
    throw new TypeError('Packaged signing rule format is invalid.');
  }
  const checksumIndexes = format.checksum_indexes.map((index) => {
    if (!Number.isSafeInteger(index) || index < 0 || index >= 40) {
      throw new TypeError('Packaged signing checksum indexes must address a SHA-1 digest.');
    }
    return index;
  });
  return Object.freeze({
    prefix: format.prefix,
    suffix: format.suffix,
    checksum_indexes: Object.freeze(checksumIndexes),
    checksum_constant: format.checksum_constant,
  });
}

export function validatePackagedSigningRule(rule) {
  if (
    !rule ||
    typeof rule !== 'object' ||
    Array.isArray(rule) ||
    !hasOnlyKeys(
      rule,
      new Set(['schema', 'source_revision', 'static_param', 'format']),
    ) ||
    rule.schema !== PACKAGED_SIGNING_RULE_SCHEMA ||
    typeof rule.source_revision !== 'string' ||
    rule.source_revision.length === 0 ||
    rule.source_revision.length > 128 ||
    /[\r\n]/.test(rule.source_revision) ||
    typeof rule.static_param !== 'string' ||
    rule.static_param.length === 0 ||
    rule.static_param.length > 4_096 ||
    /[\r\n]/.test(rule.static_param)
  ) {
    throw new TypeError('Packaged signing rule is invalid.');
  }
  return Object.freeze({
    schema: PACKAGED_SIGNING_RULE_SCHEMA,
    source_revision: rule.source_revision,
    static_param: rule.static_param,
    format: copyFormat(rule.format),
  });
}

function createPackagedSigningRuleRegistry(rules) {
  if (!Array.isArray(rules) || rules.length === 0) {
    throw new TypeError('At least one packaged signing rule is required.');
  }
  const byRevision = new Map();
  for (const input of rules) {
    const rule = validatePackagedSigningRule(input);
    if (byRevision.has(rule.source_revision)) {
      throw new TypeError(`Duplicate packaged signing revision: ${rule.source_revision}.`);
    }
    byRevision.set(rule.source_revision, rule);
  }
  return Object.freeze({
    revisions: Object.freeze([...byRevision.keys()]),
    get(revision) {
      return typeof revision === 'string' ? byRevision.get(revision) ?? null : null;
    },
  });
}

function identityCapture(capture) {
  if (!capture || capture.method !== 'GET' || typeof capture.url !== 'string') {
    throw new TypeError('Packaged signing activation requires an observed identity GET.');
  }
  const url = new URL(capture.url);
  if (url.origin !== ORIGIN || url.pathname !== IDENTITY_PATH || url.search !== '') {
    throw new TypeError('Packaged signing activation requires the exact identity endpoint.');
  }
  if (!capture.headers || typeof capture.headers !== 'object' || Array.isArray(capture.headers)) {
    throw new TypeError('Observed identity headers are invalid.');
  }
  const headers = {};
  for (const [rawName, value] of Object.entries(capture.headers)) {
    const name = rawName.toLowerCase();
    if (!OBSERVED_CAPTURE_HEADERS.has(name) || Object.hasOwn(headers, name)) {
      throw new TypeError('Observed identity request contains a disallowed or duplicate header.');
    }
    headers[name] = value;
  }
  for (const name of [...REQUIRED_OBSERVED_HEADERS, 'sign', 'time', 'user-id']) {
    if (typeof headers[name] !== 'string' || headers[name].length === 0) {
      throw new TypeError(`Observed identity request is missing ${name}.`);
    }
  }
  if (!/^[1-9]\d*$/.test(headers.time) || !/^[1-9]\d*$/.test(headers['user-id'])) {
    throw new TypeError('Observed identity time and user-id headers must be positive integers.');
  }
  if (typeof capture.responseRevision !== 'string' || capture.responseRevision.length === 0) {
    throw new TypeError('Observed identity response is missing x-of-rev.');
  }
  if (capture.responseRevision !== headers['x-of-rev']) {
    throw new TypeError('Observed request and response revisions do not match.');
  }
  return { headers, path: `${url.pathname}${url.search}` };
}

export async function createGenerationFromPackagedRule({
  rule: inputRule,
  capture,
  sha1Hex = webCryptoSha1Hex,
}) {
  if (typeof sha1Hex !== 'function') throw new TypeError('A SHA-1 digest provider is required.');
  const rule = validatePackagedSigningRule(inputRule);
  const observed = identityCapture(capture);
  if (observed.headers['x-of-rev'] !== rule.source_revision) {
    throw new TypeError('Observed identity revision is not supported by the packaged rule.');
  }

  const staticHeaders = {};
  for (const name of OBSERVED_STATIC_HEADERS) {
    const value = observed.headers[name];
    if (typeof value === 'string' && value.length > 0) staticHeaders[name] = value;
  }
  const config = {
    schema: 'local-renewable-signing-config/v1',
    source_revision: rule.source_revision,
    static_param: rule.static_param,
    format: {
      prefix: rule.format.prefix,
      suffix: rule.format.suffix,
      checksum_indexes: [...rule.format.checksum_indexes],
      checksum_constant: rule.format.checksum_constant,
    },
    headers: staticHeaders,
  };
  const validatedConfig = validateRenewableSigningConfig(config);
  const input = createSigningInput({
    config: validatedConfig,
    path: observed.path,
    timestamp: observed.headers.time,
    userId: observed.headers['user-id'],
  });
  const digest = await sha1Hex(input);
  const expectedSignature = createSignatureFromDigest({ config: validatedConfig, digest });
  if (expectedSignature !== observed.headers.sign) {
    throw new TypeError('Packaged signing rule does not reproduce the observed identity signature.');
  }

  return {
    config,
    context: { session: { userId: observed.headers['user-id'] } },
    summary: {
      source: 'packaged-rule',
      source_revision: rule.source_revision,
      reproduced_observed_signature: true,
    },
  };
}

export function generationMatchesPackagedRule(generation, registry) {
  const config = generation?.config;
  const rule = registry?.get?.(config?.source_revision);
  if (rule === null || rule === undefined) return false;
  try {
    const validated = validateRenewableSigningConfig(config);
    return (
      validated.sourceRevision === rule.source_revision &&
      validated.staticParam === rule.static_param &&
      validated.format.prefix === rule.format.prefix &&
      validated.format.suffix === rule.format.suffix &&
      validated.format.checksumConstant === rule.format.checksum_constant &&
      validated.format.checksumIndexes.length === rule.format.checksum_indexes.length &&
      validated.format.checksumIndexes.every(
        (value, index) => value === rule.format.checksum_indexes[index],
      )
    );
  } catch {
    return false;
  }
}

export {
  createPackagedSigningRuleRegistry,
  IDENTITY_PATH,
  OBSERVED_STATIC_HEADERS,
  REQUIRED_OBSERVED_HEADERS,
};
