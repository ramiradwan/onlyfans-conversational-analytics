import {
  expectedResponse,
  MAX_CURSOR_LENGTH,
  MAX_PAGE_LIMIT,
  SAFE_CURSOR,
} from './operations.js';

const MAX_IDENTIFIER_LENGTH = 256;
const MAX_DISPLAY_NAME_LENGTH = 512;
const MAX_MESSAGE_TEXT_BYTES = 350_000;
const SAFE_IDENTIFIER = /^[A-Za-z0-9_-]+$/;
const TEXT_ENCODER = new TextEncoder();

const CONVERSATION_KEYS = new Set([
  'id',
  'chat_id',
  'chatId',
  'platform_user_id',
  'platformUserId',
  'withUser',
  'with_user',
  'user',
  'display_name',
  'displayName',
  'updated_at',
  'updatedAt',
  'changedAt',
  'lastMessage',
  'last_message',
]);
const CONVERSATION_USER_KEYS = new Set(['id', 'name', 'displayName', 'username']);
const MESSAGE_KEYS = new Set([
  'id',
  'message_id',
  'messageId',
  'chat_id',
  'chatId',
  'chat',
  'sender_platform_user_id',
  'senderPlatformUserId',
  'sender_id',
  'senderId',
  'fromUser',
  'from_user',
  'sender',
  'text',
  'body',
  'sent_at',
  'sentAt',
  'created_at',
  'createdAt',
  'postedAt',
  'direction',
  'isFromCreator',
  'is_from_creator',
  'isOutgoing',
  'is_outgoing',
  'outgoing',
]);
const MESSAGE_USER_KEYS = new Set(['id', 'is_me', 'isMe', 'me']);
const ID_ONLY_KEYS = new Set(['id']);

class TypedResponseValidationError extends Error {
  constructor(code) {
    super(code);
    this.name = 'TypedResponseValidationError';
    this.code = code;
  }
}

function responseClass(summary) {
  return [
    summary.status,
    summary.content_type?.split(';', 1)[0] || 'unknown',
    summary.semantic_success ? 'expected-shape' : summary.json ? 'json-other' : 'non-json',
  ].join('|');
}

function isJsonContentType(contentType) {
  if (typeof contentType !== 'string') return false;
  const mediaType = contentType.split(';', 1)[0].trim().toLowerCase();
  return mediaType === 'application/json' || mediaType.endsWith('+json');
}

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function rejectUnknownKeys(value, allowed, code) {
  if (!isPlainObject(value)) throw new TypedResponseValidationError(code);
  if (Object.keys(value).some((key) => !allowed.has(key))) {
    throw new TypedResponseValidationError(code);
  }
}

function validateNestedObject(record, key, allowed, code) {
  if (!Object.hasOwn(record, key)) return;
  rejectUnknownKeys(record[key], allowed, code);
}

export function normalizeIdentifier(value) {
  if (Number.isSafeInteger(value) && value >= 0) return String(value);
  if (
    typeof value === 'string'
    && value.length >= 1
    && value.length <= MAX_IDENTIFIER_LENGTH
    && SAFE_IDENTIFIER.test(value)
  ) return value;
  return null;
}

function valueAt(record, path) {
  let value = record;
  for (const segment of path) {
    if (!isPlainObject(value) || !Object.hasOwn(value, segment)) {
      return { present: false, value: undefined };
    }
    value = value[segment];
  }
  return { present: true, value };
}

function resolveAliases(record, paths, normalize, invalidCode, conflictCode) {
  const normalized = [];
  for (const path of paths) {
    const candidate = valueAt(record, path);
    if (!candidate.present) continue;
    let value;
    try {
      value = normalize(candidate.value);
    } catch {
      throw new TypedResponseValidationError(invalidCode);
    }
    if (value === undefined) throw new TypedResponseValidationError(invalidCode);
    normalized.push(value);
  }
  if (normalized.length === 0) return undefined;
  if (normalized.some((value) => !Object.is(value, normalized[0]))) {
    throw new TypedResponseValidationError(conflictCode);
  }
  return normalized[0];
}

function requiredIdentifier(value) {
  const normalized = normalizeIdentifier(value);
  if (normalized === null) throw new TypeError('invalid identifier');
  return normalized;
}

function optionalDisplayName(value) {
  if (value === null || value === '') return null;
  if (typeof value !== 'string' || value.length > MAX_DISPLAY_NAME_LENGTH) {
    throw new TypeError('invalid display name');
  }
  return value;
}

function normalizedTimestamp(value) {
  let milliseconds;
  if (typeof value === 'number' && Number.isFinite(value)) {
    milliseconds = Math.abs(value) < 1_000_000_000_000 ? value * 1000 : value;
  } else if (
    typeof value === 'string'
    && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)
  ) {
    milliseconds = Date.parse(value);
  } else {
    throw new TypeError('invalid timestamp');
  }
  if (!Number.isFinite(milliseconds)) throw new TypeError('invalid timestamp');
  return new Date(milliseconds).toISOString();
}

function normalizedText(value) {
  if (typeof value !== 'string' || TEXT_ENCODER.encode(value).byteLength > MAX_MESSAGE_TEXT_BYTES) {
    throw new TypeError('invalid message text');
  }
  return value;
}

function normalizedDirection(value) {
  if (typeof value !== 'string') throw new TypeError('invalid direction');
  const normalized = value.toLowerCase();
  if (['outbound', 'creator', 'outgoing', 'sent'].includes(normalized)) return 'outbound';
  if (['inbound', 'fan', 'incoming', 'received'].includes(normalized)) return 'inbound';
  throw new TypeError('invalid direction');
}

function directionFromBoolean(value) {
  if (typeof value !== 'boolean') throw new TypeError('invalid direction flag');
  return value ? 'outbound' : 'inbound';
}

function normalizeConversation(record) {
  rejectUnknownKeys(record, CONVERSATION_KEYS, 'invalid_conversation');
  for (const key of ['withUser', 'with_user', 'user']) {
    validateNestedObject(record, key, CONVERSATION_USER_KEYS, 'invalid_conversation_user');
  }
  validateNestedObject(record, 'lastMessage', new Set(['createdAt']), 'invalid_last_message');
  validateNestedObject(record, 'last_message', new Set(['created_at']), 'invalid_last_message');

  const platformUserId = resolveAliases(record, [
    ['platform_user_id'],
    ['platformUserId'],
    ['withUser', 'id'],
    ['with_user', 'id'],
    ['user', 'id'],
  ], requiredIdentifier, 'invalid_conversation_user_identifier', 'conflicting_conversation_user_identifier');
  if (platformUserId === undefined) {
    throw new TypedResponseValidationError('missing_conversation_user_identifier');
  }
  const explicitConversationId = resolveAliases(record, [
    ['id'],
    ['chat_id'],
    ['chatId'],
  ], requiredIdentifier, 'invalid_conversation_identifier', 'conflicting_conversation_identifier');
  const displayName = resolveAliases(record, [
    ['display_name'],
    ['displayName'],
    ['withUser', 'name'],
    ['withUser', 'displayName'],
    ['withUser', 'username'],
    ['with_user', 'name'],
    ['with_user', 'displayName'],
    ['with_user', 'username'],
    ['user', 'name'],
    ['user', 'displayName'],
    ['user', 'username'],
  ], optionalDisplayName, 'invalid_conversation_display_name', 'conflicting_conversation_display_name');
  const directUpdatedAt = resolveAliases(record, [
    ['updated_at'],
    ['updatedAt'],
    ['changedAt'],
  ], normalizedTimestamp, 'invalid_conversation_updated_at', 'conflicting_conversation_updated_at');
  const fallbackUpdatedAt = resolveAliases(record, [
    ['lastMessage', 'createdAt'],
    ['last_message', 'created_at'],
  ], normalizedTimestamp, 'invalid_last_message_timestamp', 'conflicting_last_message_timestamp');
  const updatedAt = directUpdatedAt ?? fallbackUpdatedAt;
  if (updatedAt === undefined) throw new TypedResponseValidationError('missing_conversation_updated_at');

  return {
    id: explicitConversationId ?? platformUserId,
    platform_user_id: platformUserId,
    display_name: displayName ?? null,
    updated_at: updatedAt,
  };
}

function normalizeMessage(record) {
  rejectUnknownKeys(record, MESSAGE_KEYS, 'invalid_message');
  validateNestedObject(record, 'chat', ID_ONLY_KEYS, 'invalid_message_chat');
  for (const key of ['fromUser', 'from_user']) {
    validateNestedObject(record, key, MESSAGE_USER_KEYS, 'invalid_message_sender');
  }
  validateNestedObject(record, 'sender', ID_ONLY_KEYS, 'invalid_message_sender');

  const id = resolveAliases(record, [
    ['id'],
    ['message_id'],
    ['messageId'],
  ], requiredIdentifier, 'invalid_message_identifier', 'conflicting_message_identifier');
  if (id === undefined) throw new TypedResponseValidationError('missing_message_identifier');
  const chatId = resolveAliases(record, [
    ['chat_id'],
    ['chatId'],
    ['chat', 'id'],
  ], requiredIdentifier, 'invalid_message_chat_identifier', 'conflicting_message_chat_identifier');
  const senderId = resolveAliases(record, [
    ['sender_platform_user_id'],
    ['senderPlatformUserId'],
    ['sender_id'],
    ['senderId'],
    ['fromUser', 'id'],
    ['from_user', 'id'],
    ['sender', 'id'],
  ], requiredIdentifier, 'invalid_message_sender_identifier', 'conflicting_message_sender_identifier');
  if (senderId === undefined) throw new TypedResponseValidationError('missing_message_sender_identifier');
  const text = resolveAliases(record, [
    ['text'],
    ['body'],
  ], normalizedText, 'invalid_message_text', 'conflicting_message_text');
  if (text === undefined) throw new TypedResponseValidationError('missing_message_text');
  const sentAt = resolveAliases(record, [
    ['sent_at'],
    ['sentAt'],
    ['created_at'],
    ['createdAt'],
    ['postedAt'],
  ], normalizedTimestamp, 'invalid_message_sent_at', 'conflicting_message_sent_at');
  if (sentAt === undefined) throw new TypedResponseValidationError('missing_message_sent_at');
  const explicitDirection = resolveAliases(record, [
    ['direction'],
  ], normalizedDirection, 'invalid_message_direction', 'conflicting_message_direction');
  const flagDirection = resolveAliases(record, [
    ['isFromCreator'],
    ['is_from_creator'],
    ['isOutgoing'],
    ['is_outgoing'],
    ['outgoing'],
    ['fromUser', 'is_me'],
    ['fromUser', 'isMe'],
    ['fromUser', 'me'],
    ['from_user', 'is_me'],
    ['from_user', 'isMe'],
    ['from_user', 'me'],
  ], directionFromBoolean, 'invalid_message_direction_flag', 'conflicting_message_direction_flag');
  if (
    explicitDirection !== undefined
    && flagDirection !== undefined
    && explicitDirection !== flagDirection
  ) throw new TypedResponseValidationError('conflicting_message_direction');

  return {
    id,
    chat_id: chatId ?? null,
    sender_platform_user_id: senderId,
    text,
    sent_at: sentAt,
    direction: explicitDirection ?? flagDirection ?? null,
  };
}

function normalizeItems(operation, value) {
  if (!Array.isArray(value)) throw new TypedResponseValidationError('missing_items');
  if (value.length > MAX_PAGE_LIMIT) throw new TypedResponseValidationError('too_many_items');
  const normalize = operation === 'conversations' ? normalizeConversation : normalizeMessage;
  return value.map((record) => normalize(record));
}

// OnlyFans returns full platform objects rather than the reduced shapes the
// development simulator emits. The adapter below extracts the canonical fields
// and ignores everything else instead of rejecting unknown keys.
function firstPresent(record, paths, normalize, invalidCode) {
  for (const path of paths) {
    const candidate = valueAt(record, path);
    if (!candidate.present || candidate.value === undefined || candidate.value === null) continue;
    let value;
    try {
      value = normalize(candidate.value);
    } catch {
      throw new TypedResponseValidationError(invalidCode);
    }
    if (value !== undefined && value !== null) return value;
  }
  return undefined;
}

function normalizeOnlyFansConversation(record) {
  if (!isPlainObject(record)) throw new TypedResponseValidationError('invalid_conversation');
  const platformUserId = resolveAliases(record, [
    ['platform_user_id'], ['platformUserId'],
    ['withUser', 'id'], ['with_user', 'id'], ['user', 'id'],
  ], requiredIdentifier, 'invalid_conversation_user_identifier', 'conflicting_conversation_user_identifier');
  if (platformUserId === undefined) {
    throw new TypedResponseValidationError('missing_conversation_user_identifier');
  }
  const explicitConversationId = resolveAliases(record, [
    ['id'], ['chat_id'], ['chatId'],
  ], requiredIdentifier, 'invalid_conversation_identifier', 'conflicting_conversation_identifier');
  // Display name has several legitimate OnlyFans sources that need not agree.
  const displayName = firstPresent(record, [
    ['display_name'], ['displayName'],
    ['withUser', 'displayName'], ['withUser', 'name'], ['withUser', 'username'],
    ['with_user', 'displayName'], ['with_user', 'name'], ['with_user', 'username'],
    ['user', 'displayName'], ['user', 'name'], ['user', 'username'],
  ], optionalDisplayName, 'invalid_conversation_display_name');
  const updatedAt = resolveAliases(record, [
    ['updated_at'], ['updatedAt'], ['changedAt'],
    ['lastMessage', 'createdAt'], ['last_message', 'created_at'],
  ], normalizedTimestamp, 'invalid_conversation_updated_at', 'conflicting_conversation_updated_at');
  if (updatedAt === undefined) {
    throw new TypedResponseValidationError('missing_conversation_updated_at');
  }
  return {
    id: explicitConversationId ?? platformUserId,
    platform_user_id: platformUserId,
    display_name: displayName ?? null,
    updated_at: updatedAt,
  };
}

function normalizeOnlyFansMessage(record) {
  if (!isPlainObject(record)) throw new TypedResponseValidationError('invalid_message');
  const id = resolveAliases(record, [
    ['id'], ['message_id'], ['messageId'],
  ], requiredIdentifier, 'invalid_message_identifier', 'conflicting_message_identifier');
  if (id === undefined) throw new TypedResponseValidationError('missing_message_identifier');
  const chatId = resolveAliases(record, [
    ['chat_id'], ['chatId'], ['chat', 'id'],
  ], requiredIdentifier, 'invalid_message_chat_identifier', 'conflicting_message_chat_identifier');
  const senderId = resolveAliases(record, [
    ['sender_platform_user_id'], ['senderPlatformUserId'], ['sender_id'], ['senderId'],
    ['fromUser', 'id'], ['from_user', 'id'], ['sender', 'id'], ['author', 'id'],
  ], requiredIdentifier, 'invalid_message_sender_identifier', 'conflicting_message_sender_identifier');
  if (senderId === undefined) throw new TypedResponseValidationError('missing_message_sender_identifier');
  const text = resolveAliases(record, [
    ['text'], ['body'],
  ], normalizedText, 'invalid_message_text', 'conflicting_message_text');
  if (text === undefined) throw new TypedResponseValidationError('missing_message_text');
  const sentAt = resolveAliases(record, [
    ['sent_at'], ['sentAt'], ['created_at'], ['createdAt'], ['postedAt'],
  ], normalizedTimestamp, 'invalid_message_sent_at', 'conflicting_message_sent_at');
  if (sentAt === undefined) throw new TypedResponseValidationError('missing_message_sent_at');
  const explicitDirection = resolveAliases(record, [
    ['direction'],
  ], normalizedDirection, 'invalid_message_direction', 'conflicting_message_direction');
  const flagDirection = resolveAliases(record, [
    ['isFromCreator'], ['is_from_creator'], ['isOutgoing'], ['is_outgoing'], ['outgoing'],
    ['fromUser', 'isMe'], ['fromUser', 'is_me'], ['fromUser', 'me'],
    ['from_user', 'isMe'], ['from_user', 'is_me'], ['from_user', 'me'],
  ], directionFromBoolean, 'invalid_message_direction_flag', 'conflicting_message_direction_flag');
  if (
    explicitDirection !== undefined
    && flagDirection !== undefined
    && explicitDirection !== flagDirection
  ) throw new TypedResponseValidationError('conflicting_message_direction');
  return {
    id,
    chat_id: chatId ?? null,
    sender_platform_user_id: senderId,
    text,
    sent_at: sentAt,
    direction: explicitDirection ?? flagDirection ?? null,
  };
}

function normalizeOnlyFansPage(operation, object) {
  const list = object.list;
  if (!Array.isArray(list)) throw new TypedResponseValidationError('missing_items');
  if (list.length > MAX_PAGE_LIMIT) throw new TypedResponseValidationError('too_many_items');
  const normalize = operation === 'conversations'
    ? normalizeOnlyFansConversation
    : normalizeOnlyFansMessage;
  const items = list.map((record) => normalize(record));
  const hasMore = object.hasMore === true;
  let continuation = null;
  if (hasMore) {
    const next = object.nextOffset;
    if (!Number.isSafeInteger(next) || next < 0) {
      throw new TypedResponseValidationError('invalid_continuation');
    }
    continuation = String(next);
  }
  const boundary = hasMore ? null : expectedResponse(operation).boundary;
  return { items, continuation, boundary };
}

function normalizeContinuation(value) {
  if (value === undefined || value === null) return null;
  if (
    typeof value !== 'string'
    || value.length < 1
    || value.length > MAX_CURSOR_LENGTH
    || !SAFE_CURSOR.test(value)
  ) throw new TypedResponseValidationError('invalid_continuation');
  return value;
}

function normalizeBoundary(value, expectedBoundary) {
  if (value === undefined || value === null) return null;
  if (value !== expectedBoundary) throw new TypedResponseValidationError('invalid_boundary');
  return value;
}

function normalizeTypedData(operation, object) {
  const expectation = expectedResponse(operation);
  if (operation === 'identity') {
    // The identity endpoint returns the full authenticated user object; reduce
    // it to the id rather than requiring an exact single-key shape.
    if (!isPlainObject(object)) throw new TypedResponseValidationError('invalid_identity');
    const id = normalizeIdentifier(object.id);
    if (id === null) throw new TypedResponseValidationError('invalid_identity');
    return { id };
  }

  // OnlyFans paginates with hasMore/nextOffset and returns full platform
  // objects; the development simulator uses the reduced next_cursor/boundary
  // contract below.
  if (typeof object.hasMore === 'boolean') {
    return normalizeOnlyFansPage(operation, object);
  }

  rejectUnknownKeys(
    object,
    new Set([expectation.key, 'next_cursor', 'boundary']),
    'unsupported_response_field',
  );
  const items = normalizeItems(operation, object[expectation.key]);
  const continuation = normalizeContinuation(object.next_cursor);
  const boundary = normalizeBoundary(object.boundary, expectation.boundary);
  if ((continuation === null) === (boundary === null)) {
    throw new TypedResponseValidationError(
      continuation === null
        ? 'missing_continuation_or_boundary'
        : 'boundary_continuation_conflict',
    );
  }
  return { items, continuation, boundary };
}

export function parseTypedResponse({ operation, status, contentType, body }) {
  const contentTypeValue = typeof contentType === 'string' ? contentType : '';
  const object = isPlainObject(body) ? body : null;
  let data = null;
  let validationError = null;
  if (status >= 200 && status < 300 && isJsonContentType(contentTypeValue) && object !== null) {
    try {
      data = normalizeTypedData(operation, object);
    } catch (error) {
      if (!(error instanceof TypedResponseValidationError)) throw error;
      validationError = error.code;
    }
  }
  const summary = {
    status,
    content_type: contentTypeValue,
    json: object !== null,
    semantic_success: data !== null,
    validation_error: validationError,
  };
  summary.response_class = responseClass(summary);
  return { summary, data };
}

export function summarizeTypedResponse(input) {
  return parseTypedResponse(input).summary;
}

export function publicResponseSummary(summary) {
  return {
    status: summary.status,
    content_type: summary.content_type,
    response_class: summary.response_class,
    retry_after_ms: Number.isSafeInteger(summary.retry_after_ms)
      ? summary.retry_after_ms
      : null,
  };
}

export function classifyDifferentialProof(candidate, negativeControl = null) {
  if (!candidate.semantic_success) {
    return { outcome: 'failed', detail: 'Candidate response did not contain the expected semantic shape.' };
  }
  if (!negativeControl) {
    return { outcome: 'partial', detail: 'Candidate succeeded; no invalid comparison was configured.' };
  }
  if (!negativeControl.semantic_success || negativeControl.response_class !== candidate.response_class) {
    return { outcome: 'strong', detail: 'Candidate succeeded and the invalid comparison diverged.' };
  }
  return {
    outcome: 'inconclusive',
    detail: 'Candidate succeeded, but the invalid comparison produced the same response class.',
  };
}

export { TypedResponseValidationError };
