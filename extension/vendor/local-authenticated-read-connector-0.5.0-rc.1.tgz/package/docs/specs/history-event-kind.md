# History record kind

Provider history reads add `data.items[i].event_kind` after the existing parser
accepts the entire page. In `readHistoryWithEvidence()`, that path is
`read.data.items[i].event_kind`. No records are filtered, reordered or rejected
because kind evidence is missing. Identifiers, text, timestamps, direction,
pagination and transport limits keep their existing meanings. The standalone
`parseTypedResponse()` continues returning its original canonical shape.

## Installed-package usage

```sh
npm install --ignore-scripts ./local-authenticated-read-connector-0.5.0-rc.1.tgz
```

```js
import { createChromeBrowserSigningProvider }
  from 'local-authenticated-read-connector/browser-signing';

export async function readHistoryPage({
  chromeApi, packagedRule, persistence, accountId, conversationId, signal,
}) {
  const provider = await createChromeBrowserSigningProvider({
    chromeApi, packagedRule, persistence, expectedIdentity: accountId,
  });
  return provider.read({
    operation: 'message-page', parameters: { conversationId, query: { limit: 20 } },
    refreshMode: 'never', signal,
  });
}
```

Reuse the provider for later reads. Missing or stale signing state with
`refreshMode: 'never'` requires the caller to decide whether refresh is permitted.
This example does not implement traversal, persistence or application analytics.

## Versioned metadata

Each returned history record carries:

```text
event_kind: {
  schema: "connector-history-kind/v1",
  mapping_version: "onlyfans-event-kind/0.2.0",
  evidence_standard: "client-parity",
  client_pin_set_version: "onlyfans-client-parity-pins/2026-10-04.1",
  kind: "human_message" | "non_message_event" | "unknown",
  rule_id: "CP-H1" | "CP-S1" | "U-UNAVAILABLE" | "U-CONFLICT"
           | "U-SCOPE" | "U-RESPONSE" | "U-SYSTEM",
  evidence_state: "supported" | "unavailable" | "conflicting"
                  | "out_of_scope" | "missing" | "unsupported",
  context: { account_id, conversation_id, generation_id, method, endpoint, surface },
  source_kind_evidence: { availability, representations, alias_comparisons }
}
```

The context and observations have the bounded shapes defined in
[history kind evidence](history-kind-evidence.md). Source observations stay
separate from interpretation. Persist the complete metadata atomically with its
record and account/conversation context; invalidate derived answers when either
the record or metadata changes. No raw discriminator strings, objects or their
hashes are exposed. The public types are `HistoryReadMessage`,
`HistoryRecordEventKind`, `HistoryRecordKind` and `ReadData`.

The schema is part of the mapping identity. The older `connector-event-kind/v2`
observation sidecar uses the same lexical mapping version but continues emitting
its original unknown interpretation. It must not be reinterpreted as this new
schema. Missing or unsupported metadata versions remain unknown in consumers;
discarded source fields cannot be reconstructed from canonical text or sender.

## Exact predicate and limits

The supported surface is accepted `body.list[]` from the actual prepared
`GET /api2/v2/chats/{id}/messages` request, with its existing bounded query.
The projector must have available evidence, one `list` representation and the
supported observation schema/mapping. Both aliases together remain outside the
positive predicate, even when they agree. Differing aliases retain a conflicting
state. Reduced records and unavailable projection remain unknown.

| Exact source evidence | Kind | Rule |
| --- | --- | --- |
| String `responseType: "message"`, own `systemType` absent | `human_message` | `CP-H1` |
| Same response type, string `systemType` in the set below | `non_message_event` | `CP-S1` |
| Missing/other response type, null, falsy, unfamiliar or unsupported system value | `unknown` | `U-RESPONSE` / `U-SYSTEM` |
| Unavailable, conflicting or unsupported scope evidence | `unknown` | Corresponding `U-*` |

The system set is `call_requested`, `call_missed`, `call_approved`, `call_paid`,
`call_ended`, `call_declined`, `call_disconnected`. Null does not mean absent.
No trimming, case conversion, truthiness default or guessed precedence is used.
Heads, sockets, nested replies, search results, queue endpoints and individual
message endpoints acquire no kind from this rule.

These are **client categories**, supported by pinned client dispatch, not a
backend semantic guarantee. `human_message` does not assert manual typing or
visibility. `non_message_event` identifies the supported system-renderer category,
not a proved absence of every participant-content component. Text, sender,
direction, media, queue, price, tips and deletion flags have no effect on kind.
Visibility, deletion eligibility and whether a queued message counts as a reply
are separate consumer decisions. This capability does not enable pricing.

## Drift monitoring and qualification

The immutable pin sets retain SHA-256 of the module source strings. They share
the same structural behaviour fingerprint and do not change the kind mapping:

| Pin set | Role/module | SHA-256 |
| --- | --- | --- |
| `2026-10-03.1` | Dispatch / 557720 | `059c2cd4b5c3eeabd809cd9fafd85bb3d791b3362cdf0177afcc8a083e33b234` |
| `2026-10-03.1` | Labels / 872603 | `a10beef282df4a5ac644f6a32dbfcb6a921071a48d4a6fd56de104bc8fcf12b7` |
| `2026-10-04.1` | Dispatch / 600318 | `64b0a8c055fcaa44ef7820c3a77f73bed866056f57e705ca46d8c4a918bc3673` |
| `2026-10-04.1` | Labels / 872603 | `58d3d5b0a77156753844554605b7627f8d82d1cca82d91d2b176dc0c560f5e97` |

The full pin-set prefix is `onlyfans-client-parity-pins/`.
`client_pin_set_version` identifies the packaged evidence baseline, not an
assertion about which bytes a browser currently has loaded. The original pin set
is preserved unchanged. The common fingerprint is
`4076a3294f8d081b8cab5cddd695d214640b24dea2794e07ee2f80ca9fabaac6`.
Its canonical input is `client-history-behaviour/v1`, truthy `systemType` dispatch
to `item-system`, the same-record visibility fallback to `messages-item` or empty,
and the sorted seven-label set. Both source versions have this same dispatch
structure, link to the corresponding label module, and the same switch cases.

The repository tool `npm run check:history-kind-drift -- --history <file>
--client-dir <directory>` is read-only and emits numeric counts only. History
input is `{ "body": { "list": [...] } }`; client files are `module-<id>.json`
with a `source` string. `--history` is optional for a pins-only check. The monitor
flags truthy or null `systemType` and a missing/non-message `responseType`.
It parses factories with the pinned local TypeScript parser, without executing
them. The monitor locates the history dispatch and a linked system-label switch
by AST structure rather than module numbers. It checks the exact truthy condition,
same-record renderer branches, visibility fallback and complete label set.
Byte changes with that same fingerprint produce numeric warnings and exit 0.
Changed behaviour, missing or ambiguous roles, unsupported structure, malformed
source, invalid inputs or history flags produce exit 1.
A recognized system token is still a drift flag requiring review, even though
the classifier supports it. False/zero/empty-string system fields remain unknown
in classification without triggering the truthy/null monitor flag.

Run the monitor with authorized local snapshots after opening a chat so history
chunks are loaded, before trusting a deployment's client parity. Include the
relevant factories as `module-<id>.json`; their IDs may move between builds.
Equivalent byte changes can receive a new immutable pin set without modifying
the old one. A behaviour change or an unverified structure stops use of positive
classifications pending review. The fingerprint checks these bounded static
invariants, not arbitrary JavaScript equivalence, full UI behaviour or backend
semantics. Unchanged client behaviour does not certify unchanged backend behavior.
This tool does not collect traffic or alter a session.
The CLI is repository tooling and is excluded from the runtime tarball.

`qualify:node` runs the monitor's synthetic tests in its existing `source` step.
`qualify:coverage` also runs them and enforces a coverage floor on the classifier.
Installed-package, strict-type and real MV3 tests verify per-record delivery.
Synthetic examples verify behavior; they are not live source guarantees.

## Consumer decisions

Translate this schema's `human_message` to the consumer's message category and
`non_message_event` to system. Exclude known system items **before** choosing the
latest message. Unknown items remain ordering contenders: a potentially later
or unresolved tied unknown blocks an unqualified latest-message/no-reply claim.
An empty classified set is insufficient evidence, not proof of no messages.

Retain cutoff, coverage, ordering and invalidation safeguards. IDs, pagination,
heads and signing generations do not establish complete history or authoritative
tie ordering. Client parity must be an explicit analytics evidence standard;
it cannot silently replace a stronger certified participant-message contract or
the separately versioned latest-imported-inbox-entry question.
