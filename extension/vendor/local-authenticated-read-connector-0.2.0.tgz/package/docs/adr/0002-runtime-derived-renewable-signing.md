# ADR 0002: Derive renewable signing configuration from the local page runtime

- Status: accepted
- Date: 2026-07-18

## Context

Captured signed headers are useful for validating the browser probe but are time-bound. A maintainable local read connector needs to prepare a fresh signature for each typed request without exporting cookies, storing account-specific values in source, or depending on an externally maintained rule feed.

The authenticated web client already contains the active revision's request-signing implementation. Its revision-specific constants can change independently of this repository.

## Decision

1. Inspect the already loaded signing module inside the account owner's authenticated local browser tab.
2. Derive the current digest input and checksum behavior in memory, then prove that the derived rule reproduces the browser module's output.
3. Write revision-specific rule values and stable request-header values only to a gitignored `.local/` configuration.
4. Write the authenticated upstream user ID to a separate gitignored session-context file.
5. Generate `time` and `sign` locally for the exact typed `GET` path and serialized query.
6. Continue to let the browser manage cookies, origin, user agent, CSRF state, and transport headers.
7. Refresh configuration explicitly from a new browser capture when the upstream revision or browser profile changes.

## Consequences

### Positive

- Prepared signatures are fresh rather than captured replays.
- No cookie or response-body export is introduced.
- Account context remains separate from revision-specific rule configuration.
- Rule rotation can be handled from the current local page runtime without committing a rule feed.
- The development extraction, preparation, and differential-proof tools own
  private rule rotation; the browser provider owns browser-hosted signing, and
  the consumer owns orchestration and durable acquisition state.

### Negative

- Runtime extraction depends on recognizable structures in the loaded web bundle and can fail explicitly after a major bundler or hashing implementation change.
- A browser capture is still required to obtain the profile-bound stable headers for a configuration revision.
- Development refresh is explicit. A production consumer supplies the packaged
  rule, browser host, account-scoped persistence, and authorized identity at its
  provider boundary. The browser provider validates and activates signing
  generations; the consumer owns configuration activation and acquisition.

## Validation

The implementation must:

- reproduce the instrumented browser module's signature before writing configuration;
- reject non-typed destinations, non-GET methods, invalid session IDs, dynamic values stored in configuration, and malformed checksum rules;
- produce different signatures when path, query, time, or authenticated user changes;
- succeed semantically in the authenticated browser context;
- fail the deliberately corrupted-sign comparison.

Validation must be reported from the reproducible harness and release gates:
independent signature reproduction, fresh candidate/control comparison, typed
path/query checks, and explicit evidence limits for live message continuation
and complete history. A controlled browser result is evidence for the exercised
operation and context; it does not establish a universal upstream error schema
or full-history behavior.
