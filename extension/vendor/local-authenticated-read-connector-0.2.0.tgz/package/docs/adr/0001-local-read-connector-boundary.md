# ADR 0001: Put request authorization behind a local read-connector boundary

- Status: accepted
- Date: 2026-07-18

## Context

Historical backfill and reconciliation need deterministic authenticated reads, while authorization behavior may be supplied by a page-native client, a locally implemented request-authorizer, or a test double. Binding the product directly to one mechanism would spread upstream-specific behavior into scheduling, coverage, storage, and analytics.

This repository must be able to test the difficult lifecycle properties before proposing integration with another product: session binding, authorization-rule rotation, constrained destinations, pagination termination, overlap between observations, and truthful completeness evidence.

## Decision

Use a local authenticated read connector with the following boundaries:

1. Callers submit semantic, read-only intents. They do not submit arbitrary URLs, headers, methods, cookies, or authorization material.
2. A session provider supplies a short-lived account-bound session context. It is not serialized into downstream domain events.
3. A replaceable authorization adapter prepares a constrained request. Page-native and locally prepared implementations must satisfy the same interface.
4. A constrained transport sends only allow-listed `GET` requests to the configured upstream origin.
5. Pagination and coverage are connector responsibilities. A successful page is not equivalent to complete history; completeness requires explicit upstream-boundary evidence.
6. Acquisition results retain mechanism-neutral provenance and source observations. Downstream consumers do not depend on authorization headers or algorithms.
7. Authorization configuration is versioned, validated, atomically replaced, and refreshed once after an explicit stale-revision response. Failures are visible and bounded.

## Explicit exclusions

- Generic request signing or forwarding as a service.
- State-changing operations.
- Persisting raw browser credentials outside the local session boundary.
- Mechanisms intended to impersonate unrelated clients, conceal traffic, or defeat platform challenges.
- Coupling authorization configuration revisions to local storage-schema migrations.

## Consequences

### Positive

- Acquisition policy, pagination, and coverage remain stable if authorization mechanics change.
- A simulator can exercise rotation and failure behavior without live-platform dependencies.
- The eventual product integration can consume one observation contract regardless of adapter selection.
- The smallest privileged component is the request-preparation adapter.

### Negative

- The connector needs explicit contracts for sessions, authorization configuration, pagination, and coverage.
- Page-native and locally prepared strategies may expose different failure modes that require normalization.
- A later live integration still needs separate legal, product-risk, and maintenance decisions.

## Validation requirements

- Tests must reject non-`GET`, cross-origin, non-allow-listed, and body-bearing intents before transport.
- A request must be bound to the active session and authorization revision.
- A rotated revision must trigger at most one refresh and retry.
- Tampering after request preparation must fail validation.
- Pagination must detect exhaustion, cursor loops, malformed pages, and configured page limits.
- Complete coverage may be reported only after explicit history-boundary evidence.

The connector test suite exercises these boundaries with synthetic adapters and
the controlled browser qualification workflow exercises the browser provider.
The consuming product remains responsible for account authorization, consent,
acquisition scheduling, durable commits, and any live or full-history gate.
