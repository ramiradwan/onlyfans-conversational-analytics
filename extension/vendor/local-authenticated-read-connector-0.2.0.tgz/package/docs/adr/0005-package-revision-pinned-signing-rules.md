# ADR 0005: Package revision-pinned signing rules for production

- Status: accepted
- Date: 2026-08-26

## Context

The first browser provider derived a signing rule by inspecting the authenticated site's loaded
webpack runtime and invoking page-loaded module factories. Although the result was independently
verified, that production behavior is not suitable for a Chrome MV3 package whose executable logic
must be reviewable and self-contained.

The development harness still needs an offline mechanism to derive and validate a new rule when the
upstream revision changes. Per-browser request headers and account identity must not become source
artifacts.

## Decision

1. Production accepts one `local-packaged-signing-rule/v1` value supplied by the consuming
   build. A rule contains only its exact `source_revision`, static signing parameter, and deterministic
   signature format.
2. The Chrome host observes only an exact `GET /api2/v2/users/me` request and its response. It keeps
   the allow-listed non-cookie headers needed for a private generation.
3. Activation requires request and response `x-of-rev` equality, an exact packaged-rule match, and
   independent reproduction of the observed signature before differential proof.
4. An unknown or missing revision fails closed with `unsupported_revision`; production never derives
   a replacement from page code or a remote rule feed.
5. Runtime/webpack discovery remains under `tools/` for development validation. It is absent from
   package exports and the published executable file set.

## Consequences

- Rule rotation requires an extension build and review rather than an automatic runtime refresh.
- Each creator's observed app token, browser-context header, request signature, timestamp, and user ID
  remain local and are never checked in.
- The consuming product must pin the supported rule artifact and pass it as `packagedRule` when it
  constructs the browser provider.
- Existing stored generations are reused only while their signing format still matches a rule in the
  current package.
