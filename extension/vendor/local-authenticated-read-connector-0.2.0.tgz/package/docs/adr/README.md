# Architecture decision records

ADR numbering is local to this isolated repository. It does not consume numbers from the conversational-analytics project.

- [0001: Put request authorization behind a local read-connector boundary](0001-local-read-connector-boundary.md)
- [0002: Derive renewable signing configuration from the local page runtime](0002-runtime-derived-renewable-signing.md)
- [0003: Activate signing-rule rotation through private atomic generations](0003-atomic-signing-rule-rotation.md)
- [0004: Separate portable signing policy from browser and CDP hosts](0004-browser-portable-signing-provider.md)
- [0005: Package revision-pinned signing rules for production](0005-package-revision-pinned-signing-rules.md)
- [0006: Evidence-bearing prerelease gates](0006-evidence-bearing-release-gates.md)
