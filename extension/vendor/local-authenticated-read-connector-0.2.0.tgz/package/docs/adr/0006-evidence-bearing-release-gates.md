# ADR 0006: Evidence-bearing release and readiness gates

Status: accepted; stable promotion remains separately gated and unpublished.

## Context

A source-only test result or historical authenticated probe does not identify what
a delivered tarball passed. Package qualification builds on private-tool and MV3
qualification work. Existing pagination observations do not establish complete
message-history traversal. The signer `0.2.0` stable candidate also requires a
separate readiness review, while the original signer/consumer boundary remains
unchanged.

## Decision

Build once, inspect the actual tarball, and bind independent installed consumer
and type checks, the Node/platform matrix, focused per-module coverage, real
transport and baseline/stable MV3 lifecycle evidence to one source revision and
package digest. Preserve existing package-boundary regressions. Reject missing,
failed, mislabeled and mixed-input evidence. Keep the intentionally Node-only
adapter distinct from the browser graph.

Use one read-only reusable qualification workflow for CI and releases. Separate
publication and optional provenance privileges from ordinary PR jobs. Pin actions
to full reviewed upstream commits. Verify downloaded release assets before leaving
draft, without replacing assets or blindly retrying ambiguous outcomes. Record
unavailable provenance separately from qualification; do not assume a private
repository has the necessary entitlement.

Release-evidence policy v1 allows explicitly versioned prereleases only and always
reports `production_ready: false`. A separate `signer-production-readiness/v1`
policy may mark an unpublished `0.2.0` candidate eligible for stable promotion
after a fresh bundle contains the exact Git-bound package, all eleven
receipts/logs, provenance, sanitized live and consumer inventories, and explicit
technical review. That result does not authorize a merge, tag, publication,
consumer deployment or account change. Hashes bind bundle contents but do not
prove authenticity.

The fixed signer contract remains typed `identity`, `conversations` and
`message-page` operations with opaque continuation handling. Consumer traversal,
durable cursors, migration/recovery orchestration and account authorization stay
outside the signer. MAIN-world trust assumptions, API boundaries and resource
limits remain explicit review topics. Controlled Chrome 106/stable MV3 results
are not exhaustive crash, live-account or history-completeness claims. Record
private-tool platform skips and filesystem threat limits. Capability, policy and
limitation changes require reviewed code and executable evidence, not an edited
success flag.

## Consequences

Seven Node/platform jobs, ten focused module floors, transport and two MV3
browsers cost CI time and may expose previously untested platform defects. A
single local run cannot manufacture the complete report. Every eligible delivered
package identifies its source, bytes, environments, outcomes and remaining limits.

The static audit is conservative, not a universal obfuscated-code/secret detector.
Release environment protections still require repository-owner configuration.
No runtime API, consumer acquisition generation, application account epoch,
single-writer persistence contract or cancellation commit point changes. The
readiness bundle is generated, verified and release-checked separately:

```sh
npm run production:generate -- <bundle>
npm run production:verify -- <bundle>
npm run production:release-check -- <bundle> v0.2.0
```

No merge, tag, publication or consumer update is authorized by this ADR. Owner
publication controls remain separate and must enforce integrated-source/tag
checks, no-clobber behavior, bounded operations and exact uploaded-byte
verification. Existing historical candidate evidence and its workflow
provenance remain historical records; they are not silently reused for a new
candidate.

See [release qualification](../specs/release-qualification.md) for schemas, gates,
operational ownership, proof migration, MAIN-world trust and the capability matrix.
