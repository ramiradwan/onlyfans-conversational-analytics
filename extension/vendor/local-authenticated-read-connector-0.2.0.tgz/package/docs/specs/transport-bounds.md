# Bounded browser transport

The reference MAIN-world executor enforces the **8,388,608-byte** response limit, accepting equality.
This applies to identity, conversations, messages, candidate proofs, negative
controls, and error responses. No configuration, dependency, permission, package
version, public export, retry, or consumer change is required.

## Network and body consumption

The actual Fetch call sets `redirect: 'error'`. There is no redirect-following
fallback or retry. Native Fetch exposes redirects in this mode as network errors;
the signer does not invent a redirect-specific diagnosis when that information
is unavailable. The final signed-request freshness and absolute transport expiry
checks remain immediately before transmission, preserving strict clock freshness policy.

The executor acquires a stream reader and counts the bytes in each received
`Uint8Array`. It rejects a chunk that would cross the budget **before copying or
decoding that chunk**. `Content-Length` is not used as an authoritative size or
an early-rejection heuristic: it may be missing, incorrect, or describe compressed
rather than decoded response-stream bytes. Bytes delivered by Fetch, including
any content decoding already performed by the browser, are what count.

Storage grows geometrically up to the cap. Small chunks do not create an
unbounded retained chunk list; small views are copied rather than retaining a
potentially much larger source buffer. After the complete bounded stream has
ended, the executor decodes UTF-8 and parses JSON. It never calls `json()`,
`text()`, or `arrayBuffer()` as a fallback. Empty/null-body responses and malformed
JSON retain the existing unsuccessful typed-response behavior.

This is a bound on the signer's consumed/retained body bytes, not an absolute
browser heap bound. Fetch can deliver an already allocated oversized chunk;
network buffers, temporary growth copies, decoded strings, parsed-object overhead,
Chrome result serialization, and hostile MAIN-world code remain outside such a
heap claim. Canonical-page and field accounting are separate policies; canonical-page
enforcement is documented separately.

## Safe results and proof policy

Before body consumption, the executor retains the observed status and only the
required bounded metadata: content type (4,096 characters), revision (128), and
429 retry timing (input at most 4,096 characters, existing one-hour output cap).
Retained header values must be printable ASCII; other response headers are not
copied into the result.

An incomplete/rejected body returns `body: null` and one internal allowlisted
`bodyError`. The provider passes it to the parser for ordinary reads and both
proof phases; public `response.validation_error` carries the safe code:

| Code | Observation |
| --- | --- |
| `response_too_large` | Actual body bytes crossed the response limit |
| `response_body_unavailable` | No usable body stream reader was available |
| `response_body_read_failed` | Stream consumption failed before completion |
| `invalid_response_metadata` | Required retained metadata violated its bound or character rules |

The existing successful transport result and canonical data shapes are unchanged.
Observed HTTP status still determines `failure_code`: an oversized 429 remains
`rate_limited`, retaining bounded `retry_after_ms`; an oversized 5xx remains
`upstream_unavailable`. A 2xx oversized response is `invalid_response` with the
specific validation code. No upstream body fragment, exception message, rejected
metadata value, or partial parsed result is exposed as a diagnostic.

Body-error evidence never establishes semantic success or a negative-control
rejection, even if a custom host supplies a partial object alongside the error.
Unknown host body-error codes suppress that object without echoing the code.
An oversized candidate sends no control; an oversized control cannot authorize
activation. Missing revision on an unsuccessful read does not trigger recovery.

## Cancellation and cleanup

The existing finite transport and caller-cancellation machinery covers every
stream read. Overflow, read failure, cancellation, navigation, and timeout cancel
the owned reader and abort unfinished Fetch work. Reader locks, pagehide listeners,
timers, and registry entries are released on settlement. Cleanup cancellation is
observed but not awaited: a rejecting or hanging source cannot extend the deadline
or replace the primary result. Late fetch/body failures are observed, and a body
returned by a noncooperative fetch after abandonment is canceled without parsing.

## Tests and qualification

The transport suite covers focused transport cases, retained boundary tests,
and the full test suite. The suite includes independently packed/installed consumer
contracts covering exact-byte-boundary and failed-control-body cases through the
public import.

Stream test doubles provide lazy byte streams to exercise chunk inspection,
byte-ceiling enforcement, and cancellation gates. The production runtime consumes
responses strictly as streaming bodies with no legacy unbuffered fallback. Rejection
behaviors and error codes are strictly preserved.

A dependency-free minimum browser runner is available:

```sh
SIGNER_CHROME_BINARY=chromium node tools/check-transport-browser.mjs
```

It packs and independently installs the signer, runs the serialized production
executor in a browser page, and serves streaming HTTPS fixtures through a closed
loopback proxy. Only the two fixture origins connect to the local TLS server;
unknown proxy destinations are rejected and direct DNS resolution is disabled.
It tests same/cross-origin redirect targets receiving no request, the three size
boundaries, status/retry preservation, and real-stream cancellation. Linux-style
`npm`, Chromium, and `openssl` executables are required; generated certificates
and browser profiles are temporary and never committed.

Real-browser and live-platform qualification remain separate gates. The runner is
not the full MV3/`executeScript`, service-worker termination, baseline-browser, or
live-platform qualification harness. Those remain separate gates.


Standards references: [Fetch redirect modes](https://fetch.spec.whatwg.org/#concept-request-redirect-mode)
and [Streams readers and locks](https://streams.spec.whatwg.org/#rs-default-reader-class).
