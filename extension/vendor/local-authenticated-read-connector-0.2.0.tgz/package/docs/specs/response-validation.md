# Bounded projection and continuation validation

Bounded projection and continuation validation define the canonical transformation
of upstream response payloads into validated `{ items, continuation, boundary }` pages.
Upstream objects are projected into strict canonical shapes with explicit byte caps,
continuation validation, and mutually exclusive boundary markers. Multi-page scheduling,
cross-page deduplication, and historical completeness tracking remain consumer responsibilities.

## Independent canonical budget

The canonical page limit is **2,097,152 UTF-8 bytes of JSON**. It includes keys,
quotes, delimiters, item commas, continuation, boundary, and JSON escaping, not
just message text bytes. Equality succeeds; one byte over fails with
`canonical_page_too_large`, `data: null`, and no partial/truncated page. Identity
continues to project to its bounded `{ id }` form, not a page.

`canonicalPageByteLength` is internal and runs only on freshly projected records
containing primitives. It serializes the small page envelope and then individual
bounded items, stopping at overflow rather than serializing a whole oversized page.
The parser assigns data only after validation completes. The 8 MiB transport cap
remains separate; custom hosts remain responsible for their own body-read
bounds. This is not an absolute process-heap limit.

Message text retains the 350,000-byte UTF-8 limit. Byte counting stops on overflow
without allocating an encoded copy. Names retain 512 UTF-16 code units. Unpaired
surrogates cost replacement bytes for the text limit but escaped `\ud800`-style
bytes in JSON; tests cover that distinction with independent serialized oracles.

## One usable continuation domain

The parser and builder both use the internal `isUsableContinuation` predicate:
nonempty strings of at most 512 ASCII characters from `[A-Za-z0-9._~-]`. The
standalone executor mirrors that domain, tested after function serialization.
Caller `query.cursor` remains unchanged at the public boundary. Conversation
cursors and other supported message cursors map to wire `offset`; an opaque
`msg1.<chat>.<message>` message-history cursor maps to wire `id` on the message
endpoint with fixed `order=desc`. The consumer does not decode or rewrite the
token. The public builder emits that fixed order; a legacy raw message URL
without `order` remains a compatibility input. The matcher also allows
`order=desc` on other `message-page` wire forms; when `id` is present, that
order is required. The native `lastId` query is the separate newer/ascending
mode and is outside this older-history contract. No trimming,
numeric coercion, case normalization, double encoding, or expansion to
arbitrary token characters is allowed.

Reduced `next_cursor` values preserve their exact spelling, including leading
zeros and numeric-looking strings longer than a safe integer. Upstream
`nextOffset` is separately a nonnegative safe-integer **number** and projects to
its exact decimal string, up to `9007199254740991`. That string is accepted by
both builder and executor without clamping. Tests drive parsed continuations
through the next request, portable validation, and the serialized executor.

An upstream nonterminal page with `hasMore` requires its own `nextOffset`
unless it is a message page whose nonempty list supplies bounded
positive decimal IDs that are unique within the page and strictly descending.
That message-only fallback derives a bounded opaque `msg1` cursor from the
tail ID and requested conversation. Empty or unusable lists fail closed;
malformed `hasMore` fails closed.
When reduced pagination aliases are also supplied, they must agree exactly with
the authoritative upstream result. Terminal `hasMore: false` remains terminal;
a valid numeric `nextOffset` (including the captured zero sentinel) is unused
metadata, never an invented continuation. Explicit contradictory boundary or
cursor evidence is rejected.

## Projection and interpretation

Full upstream objects retain projection, including harmless wrapper, record, and
nested fields. The reduced simulator contract retains its existing exact-key
validation. Known authoritative identifier/text/timestamp aliases must agree;
malformed recognized nested objects cannot hide behind another valid alias.
Full message `list`/`messages` aliases must project to the same ordered canonical
items when both are present. Explicit conversation display-name aliases must
agree; legitimate user `displayName`, `name`, and `username` fallbacks still need
not agree. Optional `lastMessage: null` remains supported. Sparse arrays supplied
by a custom host fail instead of creating successful pages with missing items.

Validated explicit message direction or boolean flags are preserved. The existing
participant-shape heuristic is only a fallback; its scope is not expanded.
Ambiguous direction stays null. Null explicit direction is accepted as unknown;
valid flags may supply evidence, but conflicting explicit direction/flags fail.
No account identity, history completeness, or acquisition coverage is inferred.

## Regression evidence

`test/response-validation-slice6.test.js` covers exact canonical byte boundaries
with ASCII, multibyte text, controls, quotes, backslashes and unpaired surrogates;
field limits; opaque and numeric continuation round trips; pagination conflicts;
projection; malformed aliases; and preservation of explicit/nullable direction.
The existing captured-response and compatibility suites remain applicable.
Full browser lifecycle and live-account qualification remain separate gates.
