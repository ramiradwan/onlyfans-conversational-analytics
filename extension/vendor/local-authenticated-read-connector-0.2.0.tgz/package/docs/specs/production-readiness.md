# Production Readiness and Capability Guide

## Qualification Gates and Release Policy

Release qualification is evidence-bearing: a package build is qualified only when
backed by verifiable execution receipts across all eleven required environments
for the exact tarball and source revision. See [release qualification](release-qualification.md)
and [ADR 0006](../adr/0006-evidence-bearing-release-gates.md).

- **Prerelease policy**: Policy v1 is explicitly prerelease-only and always reports
  `production_ready: false`. Separately controlled live-session results do not automatically
  lift this release policy.
- **Stable-candidate review**: `signer-production-readiness/v1` is a separate,
  reviewable eligibility policy for an unpublished signer `0.2.0` candidate. It
  evaluates a fresh evidence bundle bound to one Git revision and one package;
  it does not change release-evidence v1, authorize publication, approve a
  merge, deploy the consumer or change account configuration.
- **Evidence bundle**: The bundle must contain the exact Git-bound package and
  package metadata, all eleven receipt/log sets, runner and source provenance,
  fresh sanitized live-session and consumer inventories, and an explicit
  technical review. SHA-256 values bind bundle contents but are not authenticity
  proofs. Historical completed evidence and the workflow revision that produced
  it remain separate provenance records and must not be silently reused for a
  new candidate.
- **Promotion separation**: Generate and verify readiness evidence before the
  separate promotion check. The commands are:

  ```sh
  npm run production:generate -- <bundle>
  npm run production:verify -- <bundle>
  npm run production:release-check -- <bundle> v0.2.0
  ```

  A successful release check means stable promotion is eligible for owner review;
  it does not perform publication. Integrated-source/tag checks, exact asset
  upload and download verification, no-clobber behavior, bounded retries and
  final inventory remain separate publication controls.
- **Message history ownership**: The signer validates one page and an opaque
  continuation; the consumer owns inventory traversal, durable cursor state,
  deduplication, commit fencing and coverage. Policy v1 controlled CI therefore
  leaves complete history unqualified without implying that a native continuation
  is absent.
- **Complete consumer qualification**: A separately run, account-scoped acceptance
  must prove inventory termination and `history_start` for every observed chat (or
  a validated empty history), matching conversation and message ID/material sets,
  cursor persistence across coordinator reconstruction, and no failed/pending/out-of-
  generation jobs. Controlled consumer fixtures establish empty, terminal,
  exact-page-boundary and overlap/replay behavior. The live run binds the same
  package SHA, signer source revision, consumer revision and built extension
  artifacts. The observed snapshot and RAM-backed reconstruction do not establish
  live IndexedDB crash durability, universal history or universal pagination.
- **Live accounts**: Deterministic CI environments do not exercise live production
  accounts or external platforms.

The fixed signer boundary is the typed `identity`, `conversations` and
`message-page` operations plus their opaque continuation. It does not add a
history store, traversal scheduler, account database, external ingestion path or
arbitrary request API. Readiness evidence may include a scoped account snapshot
from the consumer, but that evidence does not widen the signer API or turn a
current account result into a universal platform claim.

## Architectural Boundaries and Invariants

The connector enforces strict division of responsibility between the signing provider
and the consuming application:

- **Single-page ownership**: The signer owns single-page authenticated read execution,
  signing-generation validity, and differential proof. The consumer owns all multi-page
  orchestration, acquisition scheduling, durable cursor storage, coverage tracking,
  deduplication, retry policy, and frozen-tab management.
- **Single-writer persistence**: Injected `{ load, save }` persistence assumes a single
  writer. The connector serializes lifecycle transitions through an internal queue, but
  does not provide cross-process distributed locking.
- **Non-cancelable save commit point**: Once persistent `save()` begins during generation
  activation or rollback, cancellation cannot abort the write or revert state. A canceled
  operation whose save completes leaves the validated generation active in storage, but
  returns an aborted failure to the caller without data.
- **Proof migration and policy**: Active generations must satisfy current proof policy
  (`proof_policy_version: 2`). Generations with obsolete or legacy proof require
  revalidation before use.
- **MAIN-world trust**: In-page execution operates in the page's MAIN world and trusts
  page-realm integrity. The host verifies document identity, top-frame context, and
  lifecycle state, but cannot protect against a compromised host page environment.
- **Safe refresh conditions**: Browser tab refresh during credential recovery requires
  an inactive, non-visible OnlyFans tab with no active composer draft. Active tabs or
  drafts fail immediately with `refresh_unsafe`.
- **Coalesced lifecycle operations**: Concurrent `refresh()` requests coalesce into a
  single underlying operation. Canceling one waiter decrements waiter accounting and
  aborts the shared operation only when all waiters have detached.

## Enforced Capability Contracts

Detailed specifications define the normative behavior across all subsystems:

- [Request validation](request-validation.md): Parameter preflight, URL structure,
  restricted query fields, and strict header dictionary limits.
- [Signing input validation](signing-input-validation.md): Four-field signing inputs,
  digest normalization, constant arithmetic bounds, canonical decimal timestamps, and
  final dispatch freshness checks.
- [Transport bounds](transport-bounds.md): Network consumption bounds, 8 MiB response
  byte limit, stream chunk inspection before copy/decode, redirect refusal (`redirect: 'error'`),
  and bounded metadata retention.
- [Response validation](response-validation.md): 2 MiB canonical JSON page limit,
  continuation/boundary consistency, nullable evidenced message direction preservation,
  and sparse array rejection.
- [HTTP response status validation](response-validation.md): Finite integer HTTP status
  enforcement (100–599) at the shared parser/provider boundary, failing closed as
  `invalid_response_metadata` / `invalid_response` with no canonical data and suppression
  of negative controls on invalid candidate status.
- [Failure classification and proof](failure-classification-and-proof.md): Differential
  proof policy, single-refresh error budget, and strict failure code classification.
- [Diagnostics and public types](diagnostics-and-public-types.md): Bounded, allowlisted
  diagnostic events (`onDiagnostic`), network-free `status()`, and checked TypeScript
  declarations for all entry points.
- [Browser document context](browser-document-context.md): Isolated-world document
  identification, active frame checks, tab querying, and context loss detection.
- [Cancellation and resource cleanup](cancellation-and-resource-cleanup.md): Clean
  retirement of abort controllers, stream locks, timers, and storage operations.
- [Consumer compatibility](consumer-compatibility.md): Stable package exports,
  offline independent install verification, and isolated consumer fixture suites.
- [Transport qualification](transport-qualification.md): Cross-layer transport
  harness, seeded property suites, and controlled browser runner.
- [Browser qualification](browser-qualification.md): MV3 extension isolation,
  Chrome 106 compatibility baseline, service worker termination, and resource leak gates.
- [Private development state](private-development-state.md): Restricted `.local/`
  file storage, ephemeral test keys, and private release rule emission.
- [Development validation harness](development-validation-harness.md): Local
  request capture, extraction, comparison, and probe tools.

## Verification Commands

```sh
# Full test suite
npm test

# Independently packed and installed consumer contract
npm run test:contract

# Public TypeScript declaration parity
npm run test:types

# Release policy and evidence gates
npm run test:release

# Browser transport test against controlled proxy
npm run test:browser:transport

# Packed MV3 extension harness
npm run test:browser:harness
```

## Production-readiness bundle

The production-readiness commands consume a directory assembled for one
candidate. `production:index` freezes a hash inventory of `artifacts/`,
`evidence/`, `acceptance/`, and `provenance/`. An explicit `review.json` binds
that index digest, the fixed support-scope digest, and the exact package/source
identity. `production:generate` reconstructs the decision and writes
`production-readiness.json` and its checksums without overwriting existing
files. `production:verify` independently reconstructs the same decision and checks
the required eleven receipts and logs, source/package identity, runner
provenance, sanitized consumer/live inventories and the technical review.
`production:release-check` evaluates the separate `signer-production-readiness/v1`
policy for the requested unpublished version, for example `v0.2.0`.

The bundle records API and consumer boundaries explicitly: single-page
identity/conversations/message-page behavior, opaque continuation handling,
consumer traversal and durable cursor ownership, migration and recovery
semantics, MAIN-world trust assumptions, and resource/response limits. A
successful check remains an eligibility result. It does not assert universal
history completeness, unattended frozen-tab recovery, crash durability beyond
the recorded evidence, or authenticity from hashes alone. The technical review
identifies its reviewer and role; it is not owner publication approval or a
cryptographic runner attestation. The verifier does not need a live session.

From a fresh checkout containing the qualified source Git objects, install the
locked tooling dependency with `npm ci --ignore-scripts`, then run:

```sh
npm run production:verify -- /path/to/evidence-bundle
npm run production:release-check -- /path/to/evidence-bundle v0.2.0
```

Both commands read the supplied evidence without changing it. The stable check
reports source ancestry against the locally recorded `origin/main`; actual
publication must fetch and recheck the integrated source at publication time.
Bundle integrity includes the tarball, every packed file against raw Git blobs
(including line endings), all mandatory logs, separate browser/coverage reports,
live-driver and disposable extension bytes, and retained execution provenance.
