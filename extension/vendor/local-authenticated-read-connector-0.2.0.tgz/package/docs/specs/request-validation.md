# Request validation

Request handling enforces measured transport limits. `read()` validates and freezes detached parameters
before storage, host selection, capture, reload, or activation. Only plain data
records are accepted; symbols, accessors, unknown keys and unsupported operation
names fail with fixed messages rather than echoing rejected values.

The portable adapter and the serialized executor enforce the same executable
origin, path and query restrictions. Credentials, fragments, repeated/unknown
query keys, invalid limits, oversized conversation identifiers and conflicting
cursor/offset aliases are rejected. Caller cursors remain opaque at this
boundary: conversations and legacy numeric message cursors use `offset`, while
the validated `msg1.<chat>.<message>` older-history message cursor uses `id`
with fixed `order=desc`. The public builder accepts only `limit` and `cursor`
and emits that order. The compatibility matcher allows `order=desc` on any
`message-page` wire form; when `id` is present, that order is required. It
retains legacy raw message URLs without `order`. The newer/ascending `lastId`
mode is outside this operation. Cursor/offset accepts the documented
512-character ASCII
domain without semantic conversion. The development-only
`matchesOperation` route classifier is retained for recorded artifacts; it does
not authorize execution.

Header dictionaries reject unknown names, case-insensitive duplicates, empty or
non-ASCII values, controls, outer whitespace and per-field/aggregate overflow.
Capture filters browser-owned fields before accounting and does not merge retained
duplicates. Malformed request or response headers settle capture and clean its
observers. Static config requires app-token, x-bc and x-of-rev; prepared requests
add sign, time and user-id. The standalone executor retains its minimum
required-header contract (time). Missing authentication cannot authorize proof.

The closure-free executor is organized in an internal source module and re-exported through
the Chrome host surface. Conformance tests serialize the
actual function into a separate VM, with no imported validator bindings.

Validation: full `node --test`, including independently packed/installed consumer
contracts; focused tests cover zero-side-effect rejection, mutation during storage,
wire conformance, controls, duplicate capture fields and exact header budgets.
Real-browser and live-platform qualification are separate gates.
