# Browser document context and identity

## Scope and compatibility

The reference Chrome host binds each logical read, refresh, or rollback to one selected tab and its top-level document.
An intentional refresh reload is the only supported document transition within
that operation. The subsequent capture, candidate, negative control, and requested
read must agree on the post-reload document.

The public `read({ operation, parameters, refreshMode, signal })` interface,
`expectedIdentity`, packaged rule, injected `{ load, save }` persistence, public
refresh/rollback result shapes, and canonical `{ items, continuation, boundary }`
page shape are unchanged. Proof-policy version remains **2**: this specification defines
browser-context fencing and identity enforcement, not a new differential classifier.
No account enrollment, account database, application account epoch, acquisition
scheduler, retry policy, or extra extension permission is introduced.

## Browser and proxy requirements

The reference host requires Chrome **106 or newer**, including these browser-owned
metadata fields:

- `chrome.scripting.InjectionTarget.documentIds` and
  `InjectionResult.documentId`, with `frameId: 0` for the top frame;
- `chrome.webRequest` event `documentId`, `frameId`, and `documentLifecycle`.

See the official [scripting API](https://developer.chrome.com/docs/extensions/reference/api/scripting)
and [webRequest API](https://developer.chrome.com/docs/extensions/reference/api/webRequest).
The existing `scripting`, `webRequest`, and OnlyFans host grants cover this work.
No `webNavigation`, `debugger`, or broad `tabs` grant is added. Custom persistence
continues to avoid global Chrome storage.

Document discovery uses a closure-free **ISOLATED-world** top-frame probe. The
probe returns only whether the frame has the allowed origin and is the top frame;
the document identifier comes from Chrome's result envelope, never from a
page-generated token. Sensitive request headers are not passed to this probe.
Typed reads, safe-refresh inspection, and cancellation still execute in **MAIN**.

After discovery, MAIN injections use exactly
`{ tabId, documentIds: [selectedDocumentId] }`, not a tab-only destination. A
`documentIds` target never also sets `frameIds`. Returned results must contain
exactly one top-frame result with the selected document ID. Missing, malformed,
ambiguous, or mismatched metadata fails closed with `context_lost`; there is no
compatibility fallback that silently weakens targeting to `tabId`.

The consumer's Promise-returning, callback-dropping Chrome proxy remains supported.
It must forward the target and world unchanged and retain Chrome's frame/document
metadata. The signer does not inspect `frozen`, wake tabs, or copy the consumer's
pre-signing/pre-dispatch frozen-tab policy. The installed-package fixture exercises
this API shape rather than reproducing acquisition or account policy.

## Logical operation binding

`ChromeMainWorldSigningHost.openOperation({ reload, signal })` returns a frozen,
in-memory adapter with `captureIdentity`, `executeTypedRead`, and `assertContext`.
Its tab/document selection is private to that operation. It is neither a stored
signing generation nor an acquisition generation or application account epoch.
The provider never exposes the adapter in a public result or persists it.

An ordinary healthy read selects an available tab once. A fresh refresh selects
an inactive tab once. An explicitly supplied host `tabId` is a hard pin: if it is
missing, the host reports context loss rather than choosing another tab. The
host does not rewrite a shared preferred tab as a side effect of another read
or status operation.

Unbound concurrent refresh callers may coalesce and adopt the same operation's
post-reload adapter. Cancellation of one waiter does not cancel surviving waiters;
cancellation of the last waiter retires the shared operation. A recovery read
already bound to a document does not join an unrelated refresh or select another
tab. If its selected tab cannot be safely refreshed, it fails with `refresh_unsafe`.
It still has the existing one-refresh budget; it does not start replacement work.

Rollback selects its own operation context after entering the existing lifecycle
queue, proves the exact previous generation there, and preserves the
conditional store transition. The context is checked before and after lifecycle
persistence. Ordinary reads retain their own detached generation snapshots.

Custom injected hosts that implement the original capture/read interface remain
usable. An optional `openOperation` implementation must return the three methods
above. Without that hook, browser-context stability remains the custom adapter's
responsibility; the reference Chrome host's document guarantee is not inferred
for arbitrary host implementations. Identity comparisons apply to both paths.

## Identity enforcement

Every semantically successful identity response must match the normalized identity
of the generation used to sign it. That generation must also match
`expectedIdentity` when the consumer supplies it. The comparison covers ordinary
reads, activation/rollback candidates, and an unexpectedly successful negative
control. It happens before an identity response can authorize revision recovery
or leave the provider as successful data.

Mismatch raises `account_mismatch` with a fixed message that contains neither
identity nor response content. It does not trigger capture, a compensating write,
or an inferred retry. Invalid/non-successful identity payloads retain the existing
typed failure/proof behavior; they are not mistaken for a verified identity.

### Native capture bootstrap and expected identity

When capturing page-native `GET /api2/v2/users/me` on reload, the browser emits
no `user-id` header. For such captures:

1. `expectedIdentity` is mandatory for absent-header bootstrap and establishes positive
   generation identity. It must be a safe positive integer or bounded positive decimal
   string up to `MAX_IDENTIFIER_LENGTH` (256 ASCII characters, no leading zero), rejecting
   `0`, negative values, floats, leading zeros, and opaque/invalid formats. An omitted or
   invalid `expectedIdentity` fails during refresh with `packaged_rule_mismatch` without
   candidate proof requests or activation. For positive-header captures, observed-header
   derivation and provider `account_mismatch` enforcement remain unchanged.
2. The packaged rule reproduces the observed signature using internal bootstrap
   signing identity `'0'` in the four-field signing input. An explicit capture header
   `user-id: '0'` remains strictly invalid and throws `TypeError`.
3. The derived generation context binds `userId` to `expectedIdentity`. Zero is
   never stored in signing state, emitted in outgoing request headers, or allowed in
   ordinary signing sessions.
4. Candidate proof verifies that the response `id` matches `expectedIdentity`. Any
   mismatch fails closed with `account_mismatch` before generation activation or
   negative control execution.

This does not add an HTTP identity preflight to every conversations/message-page
read. Those pages do not independently prove which current cookie account served
them. Document continuity and generation identity checks do not replace the
consumer's account authorization, consent, session gating, or durable commit fence.

## Capture, reload safety, and navigation

Before reload, the host checks the selected document, the same tab's inactive
state, and the existing hidden/draft-free MAIN-world safety result. It repeats the
check after registering capture observers and immediately before dispatching
`tabs.reload`. Unsafe results have an allowlisted reason; untrusted page text is
not copied into the error.

Observation is armed only for that deliberate reload. The old document's identity
requests and child-frame requests cannot be selected as the new capture. The
chosen request must be a top-frame identity GET in an active document. Its request,
response-header, completion, and error events are correlated by request, tab,
frame, document, and active lifecycle. Passive capture (`reload: false`) instead
requires the already-selected document throughout. Capture returns only after a
fresh browser-owned probe confirms that the current top document is the one that
provided the observed request. Candidate, control, and requested read target that
same document, with current-document checks around execution.

A disappeared tab, a different document, missing metadata, or loss of the ability
to inspect the selected context produces `context_lost`, not a successful page
from a replacement tab. A MAIN-world `pagehide` listener aborts active fetch/body
consumption and is removed on settlement. This complements, rather than replaces,
browser-owned document targeting and the finite transport ceiling.

**Reload is not atomic with safety inspection.** Chrome's `tabs.reload` API has no
expected-document precondition. Navigation, visibility, or draft state can change
between separate browser calls. The final recheck narrows that interval but cannot
eliminate it. Capture metadata proves which document supplied the request, not
which actor caused every overlapping navigation. The implementation does not claim
an atomic check-and-reload primitive or guaranteed absence of every reload race.

## Cancellation, cleanup, and persistence limits

Context discovery and verification use the existing finite transport machinery
and caller cancellation semantics. Cancellation injections remain pinned to the
original document; they never target a newly navigated document. Failed cleanup
injections are observed and contained. The existing absolute MAIN transport expiry
remains the fallback for undelivered cancellation, and late completion cannot
advance an abandoned operation.

Capture timeout, registration failure, cancellation, reload failure, and success
remove all registered observers. If capture ends while its second safety check
is pending, that check's continuation is canceled too: a late Chrome query response
cannot dispatch another safety injection or reload. Reload acknowledgement is
observed without retaining an extra abort listener after capture has settled.

A browser context check and a persistence write are separate operations. Context
can change after a check, and an already-started non-cancelable `save()` may commit
a generation that was fully proved in its selected context. The same is true if
cancellation arrives after save begins. There is no unsafe compensating write.
Observed context loss after save prevents successful operation/page delivery;
it cannot undo a write whose commit point has already been crossed. The
[single-writer store contract](signing-lifecycle-consistency.md) and
[cancellation commit-point contract](cancellation-and-resource-cleanup.md) continue
to apply.

MAIN is not a trusted enclave against a malicious same-origin page. Chrome calls
already dispatched cannot be retracted, frozen execution can delay timers and
lifecycle events, and separate final checks are not atomic with consumer ingestion.
No stronger guarantees are claimed for these boundaries.

## Regression and compatibility verification

The regression test suites cover tab replacement, navigation between lifecycle phases,
mismatch and missing metadata, wrong-account identity, passive capture, explicit
tab pinning, unsafe reload races, cancellation, post-save context loss, and late safety replies.
The synthetic browser fixtures serialize the actual injected functions into
separate VM contexts, keep browser-owned metadata separate from page results,
and exercise both callback and Promise Chrome APIs.

Older single-document Chrome doubles receive explicit test-only document
metadata through a shared adapter. Existing behavioral assertions remain, and
MAIN targets are checked for exact document IDs. The independent context-loss
fixtures do not use that adapter, so malformed metadata and navigation remain
negative cases rather than being repaired by the fixture.

Verification commands:

```sh
node --test test/*slice3.test.js test/*slice4.test.js test/*slice5.test.js test/browser-signing-provider.test.js
npm run test:contract
```

Public import snapshots, fixed signing vectors, one-page data shapes, injected storage,
and proxy behavior are exercised against the installed tarball, not package self-reference.
Publication, full CI, real Chrome, live platform, and service-worker termination tests
remain separate qualification gates.
