# Diagnostics and checked public types

## Scope and compatibility

This specification details the diagnostic boundaries, safe error projections, status reporting, and checked TypeScript declarations.
It operates alongside transport bounds, request validation, and lifecycle consistency.
No consumer, permissions, signing algorithm, acquisition policy, package version, release, or vendoring changes are included.
JavaScript runtime entry points and factory arguments remain supported;
`onDiagnostic` is optional. There are no new runtime dependencies.

The read envelope remains `browser-signing-read/v1`, with the same success/failure
and exception conventions. Canonical page `data` remains exactly
`{ items, continuation, boundary }`. Invalid pages have `data: null` and a safe
`response.validation_error`; diagnostics never add fields to canonical data.
Exceptions still reject rather than becoming artificial read results. In
particular, arbitrary caller cancellation reasons are rethrown unchanged.

`response.status`, `response.retry_after_ms`, `response.failure_code` and
`response.validation_error` remain available. Retry timing is reported only for
429, is a nonnegative safe integer capped at 3,600,000 milliseconds, and is not a
signer-owned retry schedule. Existing refresh/proof/request-count policy remains
unchanged. Consumers own scheduling and decide what to do with these facts.

## Safe diagnostic boundary

Three additive exports are available from `browser-signing`:

* `SIGNING_FAILURE_CODES`: frozen allowlisted failure vocabulary.
* `SIGNING_VALIDATION_CODES`: frozen allowlisted validation vocabulary.
* `publicSigningError(error: unknown)`: a frozen object containing only
  `failure_code` and `validation_error`.

The vocabulary distinguishes authorization failure, unsupported revision, invalid
response, oversized response, context loss, transport timeout, storage failure,
and lifecycle conflict, as well as existing activation/rollback failures.
Unknown exceptions map to `signing_failed`; recognized validation exceptions map
to `invalid_response` with their safe validation code. Recognized error codes are
facts reported by the relevant boundary, not an inference from arbitrary exception
messages. The allowlists include body and canonical-page validation failures,
including size limits and conflicting continuation/items evidence, matching
streaming limits and redirect refusal.

`publicSigningError` reads only guarded `code` and `name` properties. It never
reads messages, stacks, causes, headers, bodies or account/generation context.
Unknown values, circular causes, primitives and throwing property accessors cannot
make the projection throw or add arbitrary strings. The original exception may
still contain private information for its caller; it is **not** a safe log record.
The unsupported-revision exception has a fixed message without an
upstream revision value or workflow instruction. Existing exception codes remain.

Public response summaries normalize `content_type` to a small media-type
allowlist, strip parameters, collapse vendor `+json` types to `application/json`,
and use an empty string for unknown types. Inputs over 512 characters or containing
CR/LF/NUL are discarded. The fixed `response_class` is recomputed rather than
forwarded from a caller or upstream value. This intentionally corrects diagnostic
string content while preserving fields and their types. Raw parser summaries,
prepared headers/adapter metadata, generations and persistence documents remain
private working data, not safe logging interfaces.

## Optional completion callback

```js
import {
  createChromeBrowserSigningProvider,
  publicSigningError,
} from 'local-authenticated-read-connector/browser-signing';

const provider = await createChromeBrowserSigningProvider({
  chromeApi, packagedRule, expectedIdentity, persistence,
  onDiagnostic(event) {
    diagnosticSink(event); // Only fixed vocabulary and bounded numeric facts.
  },
});

try {
  const page = await provider.read({
    operation: 'conversations', parameters: { query: { limit: 50 } },
    refreshMode: 'never', signal,
  });
  // Acquisition policy and durable ingestion remain with this caller.
} catch (error) {
  diagnosticSink(publicSigningError(error));
  throw error;
}
```

Each factory invocation and public `read`, `refresh`, `rollback`, or `status` call
emits one completion event when its promise settles. A read's internal recovery
is not a second callback event, and candidate/control requests are not exposed.
The event is shallow-frozen and contains primitives only:

| Field | Allowed content |
| --- | --- |
| `schema` | `browser-signing-diagnostic/v1` |
| `event` | `initialize`, `read`, `refresh`, `rollback`, `status` |
| `operation` | `identity`, `conversations`, `message-page`, or `null` |
| `outcome` | `success`, `failure`, `aborted` |
| `failure_code`, `validation_error` | Allowlisted code or `null` |
| `status` | Observed read HTTP status (100–599), 0 for transport failure, or `null` |
| `retry_after_ms` | Bounded observed 429 timing, otherwise `null` |

Every string is fixed vocabulary and every number is bounded. Synthetic privacy
regressions require serialized events/projections under 2,048 characters with no
sensitive fixture markers. No timestamps, caller-provided reasons, generation IDs,
account identifiers, tab/document IDs, header values, response fragments or
exception text are included. Cancellation during an invocation emits `aborted`
even when its original reason is a private string, `false`, or `null`.

Callbacks are called synchronously at completion; their return values are ignored.
Returned promises/thenables are observed for rejection but never awaited. Throws,
rejections, hostile thenables and pending callback promises do not fail or delay
the signing result. A callback must nevertheless avoid blocking the JavaScript
thread or deliberately mutating consumer/application state; it is not sandboxed.
Direct `new BrowserSigningProvider(...)` construction remains synchronous and has
no initialization event. Invalid non-callable callback options throw `TypeError`.

## Status reports prerequisites, not live authentication

`status()` reads one coherent store snapshot and may query local tab metadata.
It performs no capture, reload, injection, proof, authenticated HTTP request,
persistence write or background scheduling. Injected hosts must honor the same
network-free contract for their optional `status()` method.

Existing `state_revision`, `active`, `previous` and `browser.tab_id` metadata are
retained. Active/previous metadata includes the existing generation ID, creation
time, stored proof outcome/policy and `requires_validation`. These local metadata
fields are not included in callbacks; applications that supply custom generation
IDs must not treat the full status document as a universally sanitized log record.

The additive `readiness` object reports independent facts:

| Field | Meaning |
| --- | --- |
| `tab_available` | Matching local tab is available; `null` for unknown injected-host status |
| `active_generation_available` | An active persisted generation exists |
| `supported_rule` | Active generation matches the packaged rule; `null` when missing |
| `current_proof` | Stored proof satisfies the current proof policy; `null` when missing |
| `current_proof_policy_version` | Version against which stored proof was checked |
| `expected_identity_matches` | Stored generation matches supplied expected identity; `null` when neither comparison nor generation is available |
| `authenticated` | Always `null`: no live authentication check was performed |
| `ready` | `false` if a known prerequisite fails; otherwise `null`, never `true` |

`browser` likewise exposes `tab_available` and `authenticated: null`.
`browser.ready` is `false` for known unavailability, otherwise `null`. A legacy injected host's
`ready: true` is accepted only as tab-availability evidence, never authentication.
Use `tab_available` for UI availability checks and an actual identity read for
verified identity. Stored current-policy proof is not a claim that a session is
still authenticated. Unknown, missing, obsolete and unsupported prerequisites
remain distinguishable and are never silently refreshed by a status query.
Storage/host failures still reject and produce a safe callback failure code.

## Checked package declarations

The root, `browser-signing`, and `renewable-adapter` exports have adjacent `.d.ts`
files selected by `types` export conditions before their unchanged JavaScript
`default` entry points. Declarations cover operations/parameters, canonical
entities, discriminated read results, safe diagnostics, errors, persistence,
generation transitions, packaged rules, portable adapters and browser hosts.
The root simulator and Node adapter surfaces are declared separately without
adding Node imports to the browser runtime graph.

Operation-specific `read()` results narrow on `success`; arbitrary-operation
results also narrow on `operation`. Message direction stays nullable. Continuation
is opaque and numeric limits, string bounds, identity checks and persisted-state
validation remain runtime responsibilities, not TypeScript security guarantees.
`load()` deliberately returns `unknown`, requiring validation by the store.
Structural Chrome interfaces accept callback APIs and Promise-based consumer
proxies without requiring a second Chrome wrapper or global Chrome typings.

`npm ci --ignore-scripts` installs the pinned development-only TypeScript 5.8.3.
`npm test` includes `test/public-types.test.js`; `npm run test:types` runs it alone.
The test packs and independently installs the actual tarball, compiles existing
consumer-style usage under strict NodeNext and Bundler resolution (including
exact optional properties and unchecked-index checks), removes negative-test
suppression to prove real compiler errors, and compares declared value exports to
all runtime exports. Declarations are checked with `skipLibCheck: false`.
No older TypeScript version is claimed qualified by these tests.

These gates do not replace real-browser qualification, live-platform
validation, actual-consumer adoption or release evidence. In particular,
no full message-history traversal or production-ready release is claimed.
