# Cancellation and resource cleanup

## Scope and stack

This specification details caller cancellation and resource cleanup policies.
For an overview of production capabilities, see the [production readiness guide](production-readiness.md).
The strict proof classifier and persisted proof-policy version remain at **2**.
No consumer source, permissions, workflows, package version, or signing rule change.

The signer owns one authenticated page read and its resources. The consumer still
owns run deadlines, replacement runs, authorization, durable ingestion, and coverage.
Existing imports, canonical `{ items, continuation, boundary }` data, response status
and retry timing, and injected account-scoped `{ load, save }` persistence are unchanged.

## Caller cancellation

`read`, `refresh`, `rollback`, and `prepareGenerationRequest` reject with the exact
caller's `AbortSignal.reason`, including non-Error values such as null, false, strings,
and objects. A normal `controller.abort()` yields an `AbortError`. The reason is not
serialized into MAIN-world script arguments or turned into a diagnostic string.
This follows the [DOM abort contract](https://dom.spec.whatwg.org/#aborting-ongoing-activities).

The internal async-operation helper observes both success and failure of abandoned
promises, removes abort listeners on settlement, and invokes work lazily behind an
abort check. Cleanup failures cannot replace the cancellation reason or become
unhandled rejections. Storage loads, digest computation, capture, candidate/control
proof requests, requested reads, and queued lifecycle transitions all have abort
boundaries. A late completion cannot dispatch the next stage or return a successful page.
Non-cancelable storage/crypto implementations may finish their own work; abandoning
an await does not claim to terminate those implementations. A completed shared
storage load may still initialize the store cache, but does not authorize new proof.

The Chrome factory also accepts an optional `signal` for storage initialization.
That construction signal is not a default signal for future reads: each operation
continues to receive its own caller signal.

### Coalesced refreshes

Each refresh waiter independently observes its caller signal. Canceling one does
not abort shared work needed by another. The final canceled waiter synchronously
removes the shared operation from the provider and aborts its internal controller.
A new caller creates a new operation rather than joining the abandoned one. Late
completion of the old operation cannot clear or restart the new operation.

Refresh/rollback retain the lifecycle serialization queue. Abandoned non-cooperative host or
crypto promises do not hold that queue. Ordinary reads use detached,
validated generation snapshots, not a global network lock.

## Transport ceiling, not an acquisition deadline

`BrowserSigningProvider`, `ChromeMainWorldSigningHost`, and
`createChromeBrowserSigningProvider` accept optional **`transportTimeoutMs`**.
The default is **30,000 milliseconds**. Values must be integers from 1 through
2,147,483,647; null, infinity, zero, negative, fractional, and overflowing values
are rejected. Callers may rely on the default or provide this optional transport
ceiling explicitly.

The provider bounds each host capture/read call, including custom host adapters.
The standalone Chrome host bounds tab lookup, injection, fetch, and body consumption
within one transport call. The factory forwards the same ceiling to both layers;
the earlier caller cancellation or transport expiry wins. The page receives an
absolute expiry, not a duration it can restart after delayed injection. Expiry is
checked at completion as well as by timers, so delayed timer callbacks cannot admit
late results. A ceiling expiry rejects with `name: 'TimeoutError'` and
`code: 'transport_timeout'` at the local operation boundary.

This is not a deadline for an entire acquisition or even the entire multi-step
refresh. It creates no retries, alarms, polling, keepalive, or replacement runs.
Storage and crypto awaits remain caller-cancelable but do not inherit a new total
run deadline. A caller requiring a total limit must supply its own signal.

The existing `captureTimeoutMs` default of 20,000 milliseconds still bounds the
observation window and is also validated as a finite positive integer. The
observation timeout does not wait for a hanging reload acknowledgement. The signed
request's separate 30-second freshness predicate is unchanged and is still a local
simulator-derived safety policy, not a verified upstream acceptance window.

## MAIN-world execution and cleanup

Injected functions remain closure-free because
[Chrome serializes their function bodies](https://developer.chrome.com/docs/extensions/reference/api/scripting).
A small closure-local abort race is consequently necessary in the page executor;
serialization tests run the actual functions in a separate VM context.

The executor registers its request controller before fetch. Cancellation during
fetch or JSON consumption aborts the controller and rejects the page operation;
body parsing propagates abort instead of treating it as an ordinary JSON failure. Normal completion,
errors, cancellation, and timeout remove the controller and its timer. Malformed
JSON still yields the established typed-response failure rather than exposing a body.

When cancellation reaches MAIN **before** the read injection, it reserves the
request ID with an aborted controller. The delayed executor consumes that reservation
and refuses to fetch. A reservation is intentionally retained only until consumption
or the original absolute expiry. Duplicate cancellation does not extend it. If an
injection never arrives, expiry removes the reservation and its timer; an injection
arriving after expiry is independently rejected before transmission. Custom request-ID
factories must supply unique IDs for overlapping or not-yet-expired operations.

Cancellation injection is best effort: Chrome calls already dispatched cannot be
retracted, and permission loss or a frozen document can delay cleanup. A page-local
ceiling provides a fallback when cancellation injection fails. Timers can only execute
when their context is scheduled; absolute expiry prevents a resumed, expired injection
from transmitting. Stable-document binding is separately documented in the
[browser context contract](browser-document-context.md). Frozen-tab policy remains
the existing consumer boundary.

Capture registers cleanup before observing Chrome callbacks. Partial listener
registration failure, abort during registration, capture error, timeout, reload
failure, and successful capture remove all registered listeners and timers. Capture
promises are observed immediately, even if reload acknowledgement never settles.
Late reload success/failure cannot resume an abandoned capture. The reload
acknowledgement has no separate abort listener that could outlive capture completion
or timeout; it is dispatched once behind an abort/settlement guard and its late
rejection is observed without awaiting it.

## Activation commit point

The store accepts optional `signal` on activation and rollback. Inside the serialized
mutation it checks cancellation before loading/reconciling state and again **immediately
before calling `persistence.save(document)`**, with no await between the final guard
and that invocation. Cancellation before this commit point performs no save.

Once `save()` has begun, the adapter is non-cancelable. The canceled caller still
receives no successful page, but a fully validated generation **may be committed**.
The store retains the write queue until save settles, updates the cache on success,
and invalidates/reloads after an ambiguous failure. It does not perform
a compensating rollback. A save that never settles can still block later store writes;
the adapter offers no safe way to cancel it or begin a competing write.
The [single-writer persistence contract](signing-lifecycle-consistency.md) remains mandatory.

## Verification and boundaries

Tests cover cancellation at storage load, signature preparation/reproduction,
capture, candidate/control proof, queued activation, save in progress, delayed injection,
fetch, and body consumption; exact reasons; coalesced waiter independence and retirement;
partial Chrome listener registration; Promise/callback API shapes; failed cancellation
injection; finite expiry; resource cleanup; and late rejections.

`test/cancellation-regressions-slice4.test.js` contains black-box regressions covering
these boundaries. The focused test command:

```sh
node --test test/*slice3.test.js test/*slice4.test.js
```

VM serialization and Chrome doubles are not real-Chrome qualification. Live
platform, service-worker termination, consumer-extension adoption, browser qualification,
and release readiness remain separate qualification gates.
