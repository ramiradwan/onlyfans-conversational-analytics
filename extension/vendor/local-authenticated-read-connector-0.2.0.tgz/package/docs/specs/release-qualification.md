# Evidence-bearing package qualification

## Scope

Package qualification establishes repository qualification, packaging audits,
release tooling, and documentation. It does not change runtime APIs, signing
algorithms, permissions or consumer source.

A successful report identifies the exact checks that passed for one source and
one tarball. Release-evidence policy v1 remains a deterministic
CI/prerelease report: it always emits `production_ready: false`, permits only
explicit prerelease tags, and does not include live-account or complete-history
evidence. No version bump, tag, release, registry publication or consumer
vendoring is implied by these gates.

The separate `signer-production-readiness/v1` policy evaluates an unpublished
stable signer `0.2.0` candidate from a fresh evidence bundle. It may establish
stable-promotion eligibility for owner review after exact package/source binding,
all eleven receipts and logs, provenance, sanitized live and consumer
inventories, and explicit technical review have passed. It does not set the
release-evidence policy's `production_ready` field, authorize publication,
approve a merge or deploy the original consumer. The signer and consumer retain
separate ownership: the signer validates typed pages and continuations; the
consumer proves traversal and coverage.
The existing version and TypeScript 5.8.3 lockfile are retained.

## Build once, qualify the same bytes

`.github/workflows/qualification.yml` is the read-only reusable workflow shared by
CI and manual releases. Node 22/Linux builds a single package with offline packing
and lifecycle scripts disabled. Every later job downloads and independently
audits that same tarball before installing or exercising it.

| Gate | Required environments and evidence |
| --- | --- |
| Source regressions | Node 22 and 24 on Ubuntu 24.04, macOS 14 and Windows Server 2022; Node 26 on Ubuntu 24.04 |
| Installed consumer contract | Independent existing consumer fixtures in a temporary directory outside the source tree, against the same tarball, in all seven Node environments |
| Checked declarations | Strict NodeNext and Bundler consumers, negative type controls, and existing declaration/runtime export-parity regressions |
| Package/import boundary | Actual gzip/tar audit, all three installed exports and the browser dependency graph; existing package-boundary tests remain intact |
| Focused coverage | Node 22/Linux; individual line, branch and function floors for ten critical modules |
| Real transport | Stable Chrome on Ubuntu 24.04, the existing 11-case controlled TLS/proxy fixture and the exact tarball |
| Real MV3 lifecycle | Chromium 106.0.5249.0 snapshot 1036745 and Chrome for Testing stable; native and consumer-shaped proxy modes, 38 cases per browser |

The Node engine field is an installation floor, not evidence for every future
major or every patch/platform combination. Receipts record actual Node version,
OS, architecture, runner image and workflow run/attempt. Chrome provisioning occurs
before fixture isolation. Browser reports record the actual binary/CDP version.
The transport runner installs the supplied tarball; an independent source repack
is only a byte-equality check, not a substitute qualification input.

The MV3 job uses the browser qualification harness in an actual loopback-only Linux
network namespace with no external interface or route. A configuration flag alone
does not create isolation. Chrome 106 is an isolated compatibility fixture, not a
recommendation for ordinary browsing. Each browser must exercise both modes and
all 19 cases per mode. Aggregation also requires four actual worker destructions
per mode with changed boot IDs and five retained-resource samples after 40
maximum-page reads per mode. It rechecks the 16 MiB heap-growth and four-node/
listener-growth budgets. Missing modes, measurements, worker destruction or the
baseline browser cannot be replaced by a successful newer-browser result.
See [browser qualification](browser-qualification.md) for exact scenarios and
remaining crash-phase, peak-RSS and live-platform limits.

## Coverage policy

`tools/lib/release-evidence.js` owns the required environment IDs and these
per-module floors. Values below are minimum percentages, not reported results.

| Module under `src/signing/` | Lines | Branches | Functions |
| --- | ---: | ---: | ---: |
| `request-freshness.js` | 90 | 80 | 90 |
| `operations.js` | 95 | 90 | 95 |
| `message-continuation.js` | 95 | 90 | 100 |
| `diagnostics.js` | 95 | 90 | 95 |
| `provider.js` | 95 | 90 | 95 |
| `generation-store.js` | 95 | 90 | 95 |
| `proof-policy.js` | 95 | 90 | 95 |
| `async-operation.js` | 95 | 85 | 95 |
| `chrome-host.js` | 90 | 80 | 90 |
| `response.js` | 95 | 85 | 95 |

The Node test reporter writes machine-readable measurements. Missing, duplicate,
empty, non-finite and below-floor measurements fail closed. A highly covered
module cannot dilute a failure in another module. The receipt retains actual
observed percentages. Floors were checked against the latest source suite;
changes to the floors require explicit review, not automatic relaxation.
Coverage is a regression gate, not proof of correctness or exhaustive security.

## Actual-artifact audit

`tools/lib/package-audit.js` bounds compressed/expanded size, per-file size and
entry count, checks tar checksums, and rejects truncation, duplicate paths,
traversal, symlinks, hardlinks, PAX path overrides and other special entries.
Only reviewed source/declaration, README/license and ADR/specification paths may
ship. The exact `adapters/README.md` that npm automatically includes is allowed;
this is not permission to include arbitrary development paths.

Executable JavaScript is parsed using the already locked TypeScript compiler.
The audit rejects runtime discovery signatures, remote executable imports,
computed dynamic imports, eval/Function construction, script-element loading,
known private-key/token patterns and literal session-header credentials. It also
rejects runtime dependencies, install/pack lifecycle scripts, alternate package
resolution, changed public exports and missing entry-point declarations.

The browser graph starts at `src/signing/index.js`, follows relative imports and
re-exports, and requires every module to exist in the tarball. Node imports,
Node globals, bare specifiers and escaping paths fail that graph. The separate
`renewable-adapter` entry intentionally uses Node crypto and is **not** a browser
entry; it remains inventoried and inspected, and becomes an audit failure if
reachable from the browser entry. The Node root export is similarly distinct.
All three entries are independently imported by installed-package tests.

The inventory records every file's size/SHA-256 and the visited browser graph.
These conservative checks are not a universal malicious-code or secret detector:
review actual diffs and inventory, and never add live captures or credentials to
CI. Tooling remains under `tools/`, outside the package's executable surface.

## Evidence schema and failure behavior

The successful `signer-qualified-package` artifact contains the versioned `.tgz`,
`package-info.json`, `source-revision.txt`, `qualification-report.json` and
`SHA256SUMS`. Package metadata schema 1 binds the inventory and tarball digest to
full Git source revision and tree. Report schema 1 uses policy
`signer-release-evidence-v1`; the report is only emitted after all eleven required
environment receipts pass for the same source and bytes.

Each `evidence/<id>/` contains a receipt plus command logs. Receipts identify
executed checks, exit codes, log digests, actual environments and source test/skip
counts. Platform-specific source skips remain visible in TAP logs and counts,
not relabeled as passes; the independent consumer suite permits no skips.
A command failure saves a failed receipt when possible. An interrupted job with
no receipt is missing evidence, never a pass. Aggregation verifies actual log
hashes and rejects missing, duplicate, unknown, failed, mislabeled, mixed-source
or mixed-package inputs. These are same-run CI records, not mutually distrustful
parties' independently signed statements.

Qualification refuses dirty or uncommitted inputs and stale output directories.
Every packed file must also match the exact Git blob bytes of the claimed source
revision. A clean Git status can hide normalized text line-ending differences;
the byte check rejects those archives before execution receipts can be produced.
Package comparisons report a bounded mismatch without rendering a binary diff.
Commands have finite execution/output limits. Generated artifacts are ignored by
Git. Local entry points include:

```sh
npm ci --ignore-scripts
npm run test:release
npm run qualify:pack
npm run qualify:node
npm run qualify:coverage
SIGNER_CHROME_BINARY=/path/to/google-chrome-stable npm run qualify:browser
```

`qualify:mv3` additionally requires the workflow-created network namespace, Xvfb,
an explicit `SIGNER_BROWSER_CHANNEL=baseline-106` or `stable`, and the matching
browser. One local host cannot satisfy the whole matrix. `qualify:report` rejects
partial collections; use CI for the complete report. Failed logs diagnose a gate,
but do not establish a qualified package.

## Production-readiness evidence bundle

The separate readiness workflow consumes one candidate bundle with these inputs:

- the exact Git-bound package, `package-info.json`, source revision/tree and
  checksum inventory;
- all eleven qualification receipts and their command logs, bound to the same
  source and package bytes;
- runner and source provenance, including the distinction between the signer
  source revision and the workflow revision that produced a receipt;
- fresh sanitized live-session and consumer inventories, with no credentials,
  account identifiers or message content; and
- an explicit technical review covering the fixed API boundary, migration and
  recovery behavior, MAIN-world trust assumptions, and resource/response limits.

Use the commands below against a disposable or archived bundle directory:

```sh
npm run production:generate -- <bundle>
npm run production:verify -- <bundle>
npm run production:release-check -- <bundle> v0.2.0
```

Generation and verification are evidence operations. The release check only
returns the readiness-policy result; it does not publish, merge, tag or modify
the original consumer. SHA-256 values provide content binding within the bundle,
not authenticity. Publication remains a separate owner-controlled operation
with integrated-source/tag checks, no-clobber asset handling, bounded retries,
downloaded-byte verification and final inventory checks. No owner or repository
administrative control is inferred from a passing local result.

The signer boundary remains fixed at typed `identity`, `conversations` and
`message-page` operations plus opaque continuation handling. Traversal,
durable cursor persistence, deduplication, migration/recovery orchestration and
account authorization remain consumer responsibilities. Readiness evidence may
qualify a scoped observed account snapshot, but it does not qualify universal
history behavior or extend the signer API.

The completed eleven-environment evidence for historical candidate `237039b` and
its workflow runner revision `8ec1ae45e661fbc598dc04caf675900ae4be1aaf` remains
separate provenance. It is retained for audit context and is not silently reused
as evidence for a later candidate.

## Release and provenance separation

`release.yml` is manually dispatched on an existing version tag and reruns the
same read-only qualification workflow. Before any publication it checks that the
tagged source is integrated into `origin/main`, that the prerelease tag exactly
matches `package.json`, and that all package bytes, inventory, report policy and
checksums agree. Stable tags remain ineligible to the release-evidence v1 path;
the separate readiness check is the only documented route to stable-promotion
eligibility. There is no automatic npm registry publication path.

Only the publish job receives `contents: write`. Its `signer-release` environment
must have owner-configured reviewers/tag restrictions where available; the name
alone does not guarantee an approval. Ordinary push/PR jobs have `contents: read`,
do not persist checkout credentials, and cannot publish. A readiness result does
not prove those owner controls exist or were exercised. There is no
`pull_request_target` or untrusted `workflow_run` write path.

Every action is pinned to a full upstream commit SHA in
`.github/ci-action-pins.json`, including all qualification workflows. The registry records
resolved official action v4/v3 refs and the existing reviewed browser-action
v2.2.0 commit. Review upstream source/release changes and update pins and registry
together; tests reject floating or unknown pins. Pinning is not a substitute for
reviewing the action implementation.

Publication creates a draft without replacing an existing release, uploads
without clobbering, downloads into a fresh directory, compares exact bytes and
checksums, then makes the prerelease visible. Each CLI operation is bounded.
Duplicate or ambiguous outcomes fail without blind upload retries. Interrupted
publication leaves a draft for operator inspection, not automatic asset deletion
or replacement. The private-rule publisher remains separate.


Optional provenance defaults off and uses a separate job with `id-token: write`
and `attestations: write`. Unsupported or failed attestation is warned and
recorded explicitly in `provenance-status.json` and release notes. Delivery does
not depend on an assumed private-repository entitlement. A successful attestation
covers the original qualified bundle; the later provenance-outcome record and
updated checksum manifest are not claimed as attested subjects. Consumers must
verify attestations, not infer safety from their presence. See GitHub's
[artifact attestations](https://docs.github.com/en/actions/concepts/security/artifact-attestations)
for current plan availability and verification requirements.

## Operational ownership and trust

A **signing generation** is validated packaged-rule/session signing state and
proof-policy evidence. An **acquisition generation** is the consumer's run and
cancellation/deadline/commit fence. An **application account epoch** is the
consumer's account-authorization boundary. None substitutes for another; the
signer does not create the latter two or own durable ingestion.

Injected account-scoped `{ load, save }` persistence requires **single-writer
ownership**. One store's serialized conditional transitions do not provide
cross-instance or cross-process compare-and-swap. Legacy `proof_outcome: 'strong'`
is not proof under current policy version **2**: it requires bounded revalidation.
Failed migration preserves last-known-good stored state. Corrupt/unsupported
storage must not silently become an empty store. See
[lifecycle consistency](signing-lifecycle-consistency.md).

Cancellation before activation prevents abandoned work starting activation.
Entry into non-cancelable `save()` is the activation commit point: a fully
validated generation may still commit after cancellation, while the canceled
caller receives no successful page. Cancellation does not promise to roll back
adapter writes. A canceled coalesced-refresh waiter must not cancel work another
waiter still needs; the final canceled waiter retires it. See
[cancellation and cleanup](cancellation-and-resource-cleanup.md).

MAIN-world execution assumes page-realm integrity. Browser-owned document
metadata fences accidental navigation/replacement; it does not authenticate
page-owned Fetch, body values or safety probes against a compromised page.
The consumer retains consent, application account authorization, its Promise-based
Chrome proxy, frozen-tab policy and durable commit fencing. Those consumer-owned
permissions and acquisition policies remain outside the signer qualification
boundary.

## Capability matrix

These labels are emitted only by a successful, complete qualification report.

| Operation/capability | Evidence | Explicit limit |
| --- | --- | --- |
| `identity` | Typed synthetic single-read and controlled browser fixtures | No live-account qualification |
| `conversations` | Typed synthetic single-page and controlled continuation round trips | No automatic history traversal or coverage claim |
| `message-page` | Explicit conversation intent, bounded single-page projection, nullable direction and controlled continuation round trips | No complete-history pagination contract |
| Full message-history traversal | **Unqualified in deterministic v1** | Separate artifact-bound consumer acceptance records terminal inventory and `history_start` for every observed chat, matching ID/material sets and RAM-backed cursor reconstruction. Controlled fixtures cover empty/terminal, exact-boundary and overlap/replay cases; the live snapshot does not establish IndexedDB crash durability or universal history. No runner attestation is implied. |
| Chrome 106/stable MV3 | Isolated native/proxy lifecycle and resource fixtures | Historical baseline is not recommended for normal browsing; tested phase boundaries are not all possible crashes |
| Private tools | Local-filesystem fault tests across the Node/platform matrix, with skips recorded | No network-filesystem, Windows ACL-configuration, privileged-attacker or universal power-loss guarantee |
| Live accounts | **Not run** by CI | Existing opt-in development probes remain separate |

Any complete-history result from this acceptance is scoped to the observed
account and acquisition snapshot. It must not be generalized to all accounts or
all native pagination behavior.

Canonical page data stays exactly `{ items, continuation, boundary }`.
`response.status`, `response.retry_after_ms` and safe diagnostics remain outside
`data`. There is no signer-owned completion flag, page digest, traversal scheduler,
coverage state, account database, runtime rule discovery or remote executable feed.
