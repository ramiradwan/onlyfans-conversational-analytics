# Private development state and publication

## Scope and compatibility

These policies govern Node-only development tools, their tests, and qualification.
Browser exports, production signing/proof policy, public declarations, package metadata,
and consumer acquisition responsibilities remain separate.

## Supported filesystem threat model

Use a local filesystem, a trusted repository and ancestors, and one OS account
running cooperating updated CLI processes. Keep `.local/` out of shared folders,
cloud synchronization, source control, and untrusted build workspaces. Network
filesystems and their exclusive-create/rename semantics are not qualified.

Private I/O checks every component from `.local/`, rejects symbolic links and
Windows junctions, and refuses nonregular files and hard-linked private files.
On POSIX, artifacts must belong to the effective user; directories are tightened
to `0700` and files to `0600`. Descriptor identity is checked around access and
`O_NOFOLLOW` is used where available. Windows alternate streams, device names,
and normalized-name aliases are rejected. Windows permissions still depend on
the containing directory's ACL: Node modes are not a portable ACL editor. Create
the checkout in a user-private location and inspect its inherited ACL.

This is **not** a sandbox against a malicious process with the same account,
a privileged attacker, or replacement of trusted repository ancestors. Node's
portable path APIs cannot provide an atomic, descriptor-relative traversal of
all ancestors. Component checks narrow accidental/hostile preexisting-link
exposure; they do not eliminate every check-to-use race with such an attacker.
Never manually replace a live owner's lock as a recovery technique.

Reads are bounded while consuming bytes, before JSON parsing. The default ceiling
is **8 MiB**; pointers use **16 KiB**, pointer journals **64 KiB**, lock records
**4 KiB**, and publication documents **256 KiB**. File size metadata is only an
early check; reading a growing file cannot bypass the byte ceiling. Invalid UTF-8
and JSON produce fixed errors without input fragments. Private paths are guarded
also when callers omit `privateOnly`.

Writes use an exclusive, unpredictable same-directory temporary file, owner-only
mode, file flush, and atomic rename. An ownership guard runs synchronously
immediately before rename. Failed writes clean up only their own temporary file;
unrelated files are not swept. Synchronous bounded filesystem sections are
intentional for these standalone CLI tools, not a browser or server interface.
POSIX directory flushes follow commits/removals; Windows directory flushing is
not portably exposed by Node. Process-interruption recovery is tested; universal
power-loss durability across filesystems/hardware is not claimed.

## Ownership, concurrency, and recovery

`refresh.lock` is a directory containing one unique
`owner-<UUID>.json` record with schema, random token, PID, and hostname. Ownership
is acquired with exclusive directory creation. The lock covers refresh, rollback
including its browser proof, direct activation, pointer reads/recovery, and
pruning. Sibling state operations inside a command are serialized. A fresh
independent command must acquire ownership; a detached continuation cannot reuse
a lease once its command releases it.

There is **no age-based takeover** and no heartbeat expiry. A paused but live
owner remains the owner. Recovery is automatic only for a structurally valid
same-host record whose PID is demonstrably absent (`ESRCH`). PID reuse, permission
uncertainty, foreign hostnames, incomplete acquisition, malformed records, and
legacy file locks fail closed. Waiting uses a monotonic deadline (30 seconds by
default, configurable to at most 300 seconds), not the signing clock. The old
`staleMs` option cannot authorize deletion.

On Windows, an `EPERM` encountered while enumerating the lock directory
revalidates the directory path and retries within that existing deadline. An
incomplete listing never authorizes owner reaping; persistent enumeration
failure ends with `lock_timeout` and leaves the recorded owner unchanged.
Unsafe replacements and other filesystem errors still fail closed.

Release and recovery remove only the exact unique owner marker whose identity was
read. Only the participant that successfully removes that marker may remove the
empty lock directory. Missing markers are not permission to delete a directory;
an old owner cannot remove a replacement. Each state write/removal is fenced by
ownership. Losing ownership terminates the lifecycle before another probe or
state commit; client cleanup still runs.

For a legacy, malformed, or empty lock, stop **all** processes using that state
root, inspect the directory and marker, and move the stale lock aside only after
confirming exclusive offline access. Do not delete generations or pointer files
to clear a lock. A crash before its ownership record is fully written may require
this offline procedure. Crashes during generation staging can leave unreferenced
generation directories, which a later successful mutation prunes. Crash-left
`.tmp-*` files are never treated as state or indiscriminately swept; inspect and
remove them only offline. Do not mix old and updated CLIs against one state root.

## Pointer transaction semantics

Generation files are staged sequentially, avoiding cleanup racing outstanding
writers. All referenced files, manifest identity, revision fingerprints, config,
context, artifacts, and strong-proof outcome are validated before a pointer
transition or journal recovery. Corrupt/null pointers and corrupt/incomplete
journals are not treated as empty state. Both journal targets are validated
before either pointer is changed. A failed initialization can be retried after
repair without recreating the store object.

The durable `pending.json` journal is the **authorized commit intent**. A failure
before it is written leaves the active/previous pointers unchanged. A failure
afterward can leave a fully validated transition for the next owner to finish.
The command therefore cannot promise that every thrown error means nothing was
committed. No unsafe compensating write resets state after a late failure.

Rollback holds the same ownership through selection, proof, and transition and
checks `expectedGeneration` inside the serialized swap. It returns the exact
committed generation, not a later reread of whichever generation became active.
Pruning retains active/previous, ignores unrelated names and directory links,
and never follows links while recursively removing an unreferenced generation.

## Bounded, byte-verified release publication

The [publication command](signing-rule-publication.md) retains the reviewed
schema-order, two-space, newline-terminated JSON representation. It validates
and snapshots the exact bytes before network access. The emitter writes those
bytes atomically. CLI failures do not print raw JSON fragments or exception
stacks; API failures expose only fixed codes/messages and numeric status.
`gh auth token` fallback is capped at 5 seconds and 16 KiB output.

The network phase defaults to **120 seconds total**, with **15 seconds per
request including body consumption**, **1 MiB per API JSON body**, and **10 asset
pages of 100 entries**. Library overrides are finite and capped (300 seconds
total, 120 seconds per request, 20 pages). The CLI exposes `--timeout-ms` for the
total budget. Even an injected fetch that ignores abort cannot prevent local
settlement. Timers, abort listeners, readers, and late promises are cleaned up
or observed. This does not retract an HTTP request already sent to GitHub.

The release is resolved once by tag and thereafter pinned by its numeric release
ID. The complete bounded listing must establish absence of the name before an
upload. A preexisting same-name asset always blocks normal publication. There
is at most **one POST per invocation** and no DELETE, PATCH, replacement, or
compensating upload. Redirects for API lookup/list/upload are not followed.

Before success, the publisher downloads using the immutable numeric asset ID,
checks the entire body against the snapshot, and reports its full SHA-256, release
ID, asset ID, `verified: true`, and whether the outcome was reconciled. Same-size
content is not sufficient. Download redirects are limited to two transitions to
HTTPS `release-assets.githubusercontent.com` or `objects.githubusercontent.com`,
without credentials, nondefault ports, fragments, or GitHub token forwarding.
A new CDN host requires review, not silent broadening of the allowlist.

An interrupted/failed upload, duplicate-name race, or malformed acknowledgement
triggers at most one bounded read-only reconciliation of the original release.
Exactly one matching uploaded asset with identical bytes can confirm success.
Missing/ambiguous assets, starter assets, failed listing, and mismatched content
fail closed. A verified matching concurrent upload may be accepted without
claiming which invocation created it. No existing asset is replaced.

After an unconfirmed result (or a process interruption), run:

```text
npm run dev:publish-rule -- --rule .local/packaged-signing-rule.json --repo owner/name --tag <release-tag> --verify-existing
```

Verification-only mode **never POSTs**, even when no matching asset is visible.
Do not blindly rerun the ordinary upload command after an ambiguous outcome.
No listing/verification can make remote deletion or a moving tag atomic; consumers
must continue pinning the numeric asset ID and independently checking the digest.
There is no live rule feed and no consumer dependency update.

Protocol references: [GitHub release assets](https://docs.github.com/en/rest/releases/assets)
(200/302 downloads, duplicate names, and 502/starter outcomes) and
[Node filesystem APIs](https://nodejs.org/docs/latest-v22.x/api/fs.html)
(platform-specific modes, exclusive opens, and flushing). Unlike GitHub's generic
starter-cleanup advice, this publisher deliberately does not delete such assets.

## Evidence and platform qualification

Test suites cover filesystem, ownership, actual multi-process,
process-interruption, rotation, CLI, and mocked-network regressions.
No live credentials or live publication are used in these tests.

Run `npm test`, `npm run audit:package`, and `npm run test:contract`. The latter
packs and installs the actual consumer-facing package in a separate workspace;
its child tests are separate from the outer test count. The dedicated
`.github/workflows/slice8.yml` runs the focused cases on Ubuntu, Windows, and macOS,
and the full suite/package audit/installed contract on Ubuntu. POSIX mode/FIFO
checks are platform-specific; link tests explicitly skip when the OS denies the
required privilege rather than pretending they ran. Adding a matrix does not
itself claim those remote environments passed. Results do not qualify
Windows ACLs, network filesystems, power-loss behavior, or live GitHub publication.
