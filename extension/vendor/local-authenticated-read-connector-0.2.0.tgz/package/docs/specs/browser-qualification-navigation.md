# Navigation refusal and browser error envelopes

The [browser qualification](browser-qualification.md) navigates the actual tab
while its authenticated response body is still open. It must never return a
successful or partial page, mutate the stored generation, or silently complete
against the replacement document. A subsequent independent read must succeed in
the new document using the preserved generation.

The assertion does not pretend that navigation and a document probe are atomic.
If the host sees the replacement document, it reports `context_lost`. If MAIN
aborts before that replacement is observable and Chrome supplies no usable
execution result, the host can instead report its exact fixed error envelope:
`Chrome MAIN-world typed read returned an invalid result.` The qualification test accepts
only that exact `Error` envelope as a safe refusal alternative, not arbitrary exceptions,
timeouts, or errors accompanied by page data. Independent assertion tests reject
these false-positive cases.

The browser report records the actual navigation failure envelope and class for
each mode. This distinguishes safe refusal from a stronger claim about diagnostic
classification across browser versions. No package error is normalized or rewritten
by the fixture, and no production runtime change is made. All document, storage,
stream-closure, task, and listener checks remain mandatory.

Across browser versions, stable browser and Chrome 106 refuse the navigated read
safely. Chrome 106 may complete with the fixed invalid-result error envelope when
navigation aborts execution before replacement document observation. Test assertions
verify safe refusal without weakening document, storage, or stream-closure checks.
