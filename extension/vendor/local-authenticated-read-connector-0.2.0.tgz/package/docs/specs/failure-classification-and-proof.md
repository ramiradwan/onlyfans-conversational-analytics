# Failure classification and differential proof

## Boundary and release status

This policy applies to the browser provider and the development CLI proof/read
paths. It changes failure decisions, not the consumer's acquisition system.
Public imports, factory options, injected `{ load, save }` persistence, the
`read({ operation, parameters, refreshMode, signal })` interface, and exact
canonical `data` shapes remain unchanged. The consumer still owns consent,
account epochs, scheduling, retry budgets, deadlines, cursors and ingestion.

This document specifies failure decisions and differential proof classification.
Stored generations and lifecycle management are detailed in [signing lifecycle consistency](signing-lifecycle-consistency.md);
document binding and real-browser qualification are detailed in their respective specifications
([browser document context](browser-document-context.md) and [browser qualification](browser-qualification.md)).

## Read decisions

`src/signing/read-policy.js` is shared by the browser provider and CLI runner.
Only a semantically successful response with absent or different revision
metadata establishes a need to refresh signing state. An unsuccessful response
cannot establish signing drift merely by omitting or changing that header.

| Observation | Decision |
| --- | --- |
| Missing or non-packaged active generation | Bootstrap once when allowed; otherwise `refresh_required` |
| Successful typed page, matching revision | Return the page |
| Successful typed page, missing/different revision | Refresh once when allowed and budget remains; never return that unverified page |
| Still-successful revision mismatch after bootstrap/retry | `unsupported_revision`; no further refresh |
| 400/401/403 or other unclassified rejection | Return failure; no inferred signing refresh |
| 429 | Return rate-limit metadata; no signing refresh |
| 5xx | Return upstream failure; no signing refresh |
| Semantically invalid successful HTTP response | Return `data: null` and safe validation detail; do not rotate |
| Transport exception | Preserve the exception path; do not rotate |

There is no evidence-backed production error-body classifier for distinguishing
stale signing headers from logout, permission denial or challenges. In particular,
401/403 alone is not enough. Explicit `refresh()` / `dev:refresh` remains available
for caller-directed setup/recovery; no new UI, reconnect workflow or retry
scheduler is implemented in this package.

`refreshMode: 'never'` never captures/reloads. On ordinary upstream failures it
returns the original failure, not `refresh_required`. Retry timing remains advisory
metadata: the package does not wait for it or create a persistent retry job.

## One refresh budget per call

Bootstrap and recovery consume the same budget. The following counts are
provider-directed typed executions, excluding page-native capture/reload traffic
and later independent consumer calls:

| Path | Captures/refreshes | Typed executions |
| --- | --- | --- |
| Healthy established generation or ordinary upstream failure | 0 | 1 requested read |
| Successful bootstrap | 1 | candidate + control + requested read (3) |
| Established generation with successful revision drift recovery | 1 | requested read + candidate + control + retry (4) |
| Candidate proof fails or has wrong revision | At most 1 | candidate only; no control or requested-read retry |
| Bootstrap followed by revision drift | 1 | 3, then fail closed; not a second refresh |

Proof failure prevents activation and stops the read. Recovery never becomes a
loop. The consumer decides whether and when another call is appropriate.

## Differential proof

The provider retains independent captured-signature reproduction and identity
comparison with the signing generation. The CLI extraction path retains its
independent reproduction. The CLI probe serializes the same
closure-free identifier validator used by the typed parser; an identity candidate
must also match its signed `user-id` when that header is present. Raw identities
are not included in the diagnostic result.

The classifier requires explicit context: the expected revision, both response
revisions, the control header, the original signed timestamp, and the current
clock. Omitting context cannot produce `strong` proof. Browser and CLI orchestration
send at most one control and use the original prepared request, changing only
`sign`. A failed, wrong-revision or stale candidate skips that control entirely.

A control is accepted only when all of the following hold:

- the candidate is a successful JSON response with the expected semantic shape;
- the candidate revision is the expected revision, and the control changes `sign`;
- the original timestamp passes the existing local freshness policy before the
  control and when its result is classified;
- the control returns HTTP 400, a parsed JSON object without the expected payload
  key, and the same expected revision.

Other statuses, malformed/non-JSON bodies, expected payloads on an error response,
missing/different revisions and expired comparisons are not strong evidence.
429, 5xx and generic 401/403 controls are inconclusive, not successful validation.
An unsuccessful candidate produces `failed`; a valid context without a completed
comparison can produce `partial`; neither may activate a generation.

### Evidence and trust limitations

The [renewable signing verification procedure](renewable-signing-adapter.md#verification-procedure-and-evidence-limits)
and [ADR 0002](../adr/0002-runtime-derived-renewable-signing.md#validation)
require a fresh candidate/control comparison. A control returning HTTP 400
without the expected shape is classified as the bounded differential rejection
class (`observed_bad_request`); this does not establish a stable
signature-specific error code or body schema. Synthetic strings in tests are
never recognized as production error codes.

JSON and revision agreement are local acceptance conditions. Even a same-revision
HTTP 400 cannot conclusively exclude an unrelated bad-request cause.
`strong` is the package's differential-evidence label, not cryptographic proof of
causality or fresh live qualification. More precise rejection evidence and real
browser qualification remain release requirements. No current live behavior is
asserted by these synthetic tests.

The 30-second freshness value is the existing simulator-derived safety policy,
not a measured upstream acceptance window. `ChromeMainWorldSigningHost.openOperation`
binds one logical operation to one selected tab and top-level document. It uses
the browser-owned document identifier from `executeScript` results, targets MAIN
injections with `documentIds`, and checks the returned document identifier before
and after execution. Missing or mismatched document metadata fails closed with
`context_lost`. The development CLI still trusts its connected browser client
and artifact within its own workflow, and MAIN-world globals are not an
intrinsic-hardened enclave. These limits are not silently solved by stricter
status classification.

## Public failure metadata

`response` retains `status`, `content_type`, `response_class` and `retry_after_ms`.
Two additive fields describe facts rather than application recovery actions:

| Field | Values |
| --- | --- |
| `failure_code` | `null` on success; `rate_limited`, `authorization_failed`, `upstream_unavailable`, `invalid_response`, or `upstream_rejected` |
| `validation_error` | An allowlisted typed-parser code, such as `missing_page_continuation`; otherwise `null` |

Retry timing is published only for 429, as a nonnegative safe integer clamped to
3,600,000 milliseconds or `null`. Unknown diagnostic strings are not copied into
`validation_error`. No raw body, error-body string, signing header or inferred
continuation is added. Broader error/status sanitization and public type definitions
are specified in [diagnostics and public types](diagnostics-and-public-types.md).

For example, a nonterminal message page with no explicit/reduced continuation
and an empty or unusable ID list returns `success: false`, `data: null`,
`failure_code: 'invalid_response'` and `validation_error:
'missing_page_continuation'`. A nonempty page with bounded positive decimal IDs
that are unique and strictly descending may instead derive the opaque
older-history `msg1` cursor bound to the requested conversation; the consumer
passes it unchanged and the builder emits it as `id` with fixed `order=desc`.
No `lastId` newer/ascending cursor is derived here. The
signer does not assert coverage. The existing consumer may still collapse these
details to `read_failed`; changing that interpretation belongs in the consumer
repository.

## Tests

`test/browser-signing-failures.test.js` covers the status/revision/refresh-mode
matrix, state preservation, recovery count and proof freshness. The shared proof
suite exercises malformed controls, public metadata, serialized CLI parity and
rollback rejection. Browser, development-harness and rotation tests
cover failure behaviors; CLI rotation tests also cover bootstrap and failure-state
preservation. The installed-package suite exercises these behaviors through the real
factory, proxied Chrome interface and custom persistence.

All tests use synthetic input and controlled test doubles. No fixture asserts a
live rejection-body schema, no scheduling/ingestion subsystem is copied, and no
consumer source is changed. See the [production readiness guide](production-readiness.md)
for qualification gates and evidence limits.
