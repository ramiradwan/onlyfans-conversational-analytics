# Packed-package real-browser qualification

## Scope and baseline

Packed-package real-browser qualification verifies the signer in an isolated browser environment.
All fixtures, extension code, runner code, and workflows live in this repository.
Production signing code, public exports, canonical page shapes, and the consumer contract remain normative.

`npm run test:browser` loads a minimal Manifest V3 extension built from a real,
independently installed npm tarball. The service worker imports that installed
package, not a source replacement or copied executor. It uses the public Chrome
factory, packaged-rule injection and account-scoped `{ load, save }` adapter.
Injected functions cross **real** `chrome.scripting.executeScript` serialization;
the fixture never replaces page Fetch, document IDs, webRequest events or Chrome's
MAIN-world result envelopes. Node's CDP pipe controls the browser externally;
there is no extension `debugger` permission or production test hook.

The synthetic rule is the existing independently checked consumer-contract rule.
A separate Node SHA-1 oracle verifies requests, and the controlled upstream page
independently signs the identity request observed during reload. Fixed signature
vectors check this fixture implementation. Synthetic rejection is only a means of
exercising the existing proof classifier; it is not new live-platform evidence.

## Running and interpreting the gates

```sh
npm test                         # source + installed contract + harness unit tests
npm run test:browser:harness      # runner/fixture checks without Chrome
SIGNER_CHROME_BINARY=/path/to/chrome xvfb-run -a npm run test:browser
```

Use an unmanaged, disposable browser installation. The runner creates fresh
profiles, a temporary TLS certificate, and a temporary extension public key, then
removes all of them. It accepts no profile or personal-credential input. Managed
extension or navigation restrictions are respected: an unavailable extension,
unsupported browser or failed fixture navigation is a failing gate, not a skip.
Chrome 106 must run headed (Xvfb on Linux); the same mode is used for current
stable. `SIGNER_BROWSER_HEADLESS=1` is a convenience for modern local Chromium,
not a substitute for the supported-baseline CI job.

Optional harness-only environment variables:

| Variable | Meaning |
| --- | --- |
| `SIGNER_CHROME_BINARY` | Browser executable; defaults to `chromium` |
| `SIGNER_QUALIFICATION_PACKAGE` | Existing tarball; otherwise pack once, offline |
| `SIGNER_BROWSER_REPORT` | JSON report path; default `qualification/browser-report.json` |
| `SIGNER_BROWSER_MODES` | `native,proxy` by default; a subset is partial local evidence only |
| `SIGNER_EXPECT_BROWSER_MAJOR` | Require the baseline's exact major, with no newer-browser fallback |
| `SIGNER_BROWSER_NO_SANDBOX=1` | Explicit opt-in for the root, network-isolated disposable CI process |
| `SIGNER_BROWSER_NETWORK_ISOLATED=1` | Record that the invoking workflow established a network namespace; does not create one |

The browser qualification workflow (`slice9.yml`) packs **one** tarball, checks source and installed
consumer compatibility against those exact bytes, and downloads that same
SHA-256-checked artifact into both browser jobs. Repacking inside the consumer
contract is an independent byte-equality check, never a replacement for the
supplied artifact. The extension builder also compares every installed runtime
file with the source checkout and rejects development tools or fixtures in the
package. The qualification job uses the repository's existing runtime and
development dependencies.

The matrix tests the declared Chrome-106 API baseline using Chromium
**106.0.5249.0**, snapshot **1036745**, and **Chrome for Testing stable resolved
at job execution**. The required snapshot is pinned by Puppeteer 17.1.0
([revisions](https://github.com/puppeteer/puppeteer/blob/v17.1.0/src/revisions.ts)
and [version mapping](https://github.com/puppeteer/puppeteer/blob/v17.1.0/docs/chromium-support.md)).
It is never recommended for normal browsing. Both actual binary and protocol
versions are written to the report; an older baseline job cannot silently run a
newer browser. Setup and artifact actions are pinned to immutable commits.

Each browser tests native Chrome and a separate Promise-only, callback-dropping
consumer-shaped proxy. The proxy forwards real APIs and preserves document/world
metadata. It does **not** reproduce account, acquisition, frozen-tab or retry
policy. The package's Chrome-106 baseline is not a claim about the consumer
wrapper's stronger frozen-state requirements.

## Isolation and the production origin

Browser requests still use `https://onlyfans.com`. No arbitrary-origin option,
HTTP downgrade, broad production permission or relaxed request validator is added.
An ephemeral certificate's SPKI alone is trusted by the disposable browser. There
is no global `--ignore-certificate-errors`. A closed CONNECT proxy maps only the
fixture origin and a redirect trap to a loopback TLS server. Unknown hosts, literal
IPs, non-approved ports and plain HTTP are denied, with **no upstream forwarding
or DNS fallback**. Both allowed destinations are local synthetic servers.

CI downloads tools before launching the test in a fresh Linux network namespace
containing only loopback, no external interfaces and no default route. This
kernel boundary prevents external egress even from browser subsystems that might
ignore a proxy. The baseline browser runs as root without its sandbox only inside
this disposable namespace with synthetic input; it must not open live accounts.
A standalone command uses the closed proxy and disables external DNS but does not
claim kernel-level isolation unless its caller establishes that namespace. The
report distinguishes these conditions. Deterministic CI contains no platform or
personal credentials, live traffic, remote rules or external executable code.

## Executed scenarios and assertions

There are **19 cases per API mode**, including grouped exact-boundary and repeated
operation checks. Missing cases, timeouts and unsupported required capabilities
fail the process. A failed run always attempts to write a report, including zero
executed cases when browser startup was blocked.

| Area | Browser assertion |
| --- | --- |
| Capture, proof, execution | Real hidden-tab reload and webRequest capture; valid captured request/candidate, sign-only rejected control, then requested read; exact four-request bootstrap sequence; strong current-policy state and matching generation |
| Worlds and serialization | Actual MAIN registry and browser document IDs, ISOLATED-world separation, actual injected function serialization; proxy forwarding preserves the result envelope |
| Page contract | Canonical three-field page shape; maximum numeric continuation round-trips through both page operations |
| Cancellation | Deferred **real** executeScript dispatch is released after cancellation without transmission; cancellation during real streamed body consumption preserves the caller's exact reason; finite transport ceiling closes a hanging stream |
| Navigation | Navigate the real document during execution; context loss cannot return a successful page, and a fresh operation can use the new document |
| Permission loss | Remove the extension's actual optional `scripting` grant, verify removal, fail closed without network or storage mutation, then restore with a user gesture |
| Redirects | Same- and cross-origin redirect traps are never reached |
| Response sizes | Real chunked HTTP, no Content-Length; response budget minus one/exact/plus one, with original 429 and retry timing retained on overflow |
| Canonical sizes | Independently constructed 100-item page at exactly 2 MiB; one byte above fails without a partial page |
| Resource retention | 40 maximum-page reads per mode; five post-GC page/worker heap samples, latency and DOM counters; exact zero pending task/capture listener/stream/MAIN-registry gates between operations |
| Persistence restart | Destroy and restart the actual extension worker; persisted generation remains usable without another refresh |
| Interrupted activation | Destroy the worker during candidate proof, immediately before persistent save, and after the real storage write while save is still unresolved; verify no unproved state or wrong-generation recovery |
| Egress canary | Unknown hostname and literal-IP requests fail through the closed proxy |

Only the fixture extension declares `scripting` optional so its grant can actually
be revoked and restored. Production consumers still need their normal grant; no
additional extension permission is required by the signer.

Resource growth is measured after explicit garbage collection, relative to the
first warm-up batch. Each page/worker heap has a **16 MiB retained-growth ceiling**;
DOM nodes/listeners may grow by at most four. This is a bounded synthetic retention
gate, not proof of constant memory for every page or a peak-RSS measurement. All
100 canonical items and the 2 MiB page budget are exercised repeatedly. The report
records raw samples, operations, byte counts and p95 latency; latency is evidence,
not an invented upstream service-level requirement.

## Worker termination and persistence limits

The runner uses CDP `Target.closeTarget` on the **actual service-worker target**,
requires `Target.targetDestroyed`, then sends an extension message that wakes a
new worker. A newly generated boot UUID must differ and old task IDs must be lost.
No provider reconstruction is accepted as a substitute. Memory sampling attaches
to a worker only temporarily and detaches before termination scenarios. See
Chrome's [termination testing guidance](https://developer.chrome.com/docs/extensions/how-to/test/test-serviceworker-termination-with-puppeteer)
and [worker lifecycle](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle).

The fixture gates use the supported injected persistence adapter, with real
`chrome.storage.local`. Before-save termination must preserve the previous
document. After-write termination must recover the **exact fully validated new
generation** and previous generation, although the original read never returns
success. Terminating during candidate proof must not commit any candidate.

These checks cover observed phase boundaries, not every instruction-level power
failure inside Chrome storage. They do not manufacture transactional CAS across
independent writers or cancel a non-cancelable save after its commit point. MAIN
work may outlive the worker until its existing finite transport deadline; the
harness checks eventual stream/registry cleanup before proceeding. Same-origin
MAIN execution remains subject to the package's documented page trust assumptions.

## Evidence, live qualification and exclusions

Artifacts identify the source revision, package digest, actual browser, API modes,
case results, resource samples, real worker restarts and isolation configuration.
A browser pass is only established by a completed successful report for that
revision; adding a workflow is not itself qualification. The local development
environment's managed browser restrictions can prevent any browser assertions,
which must be reported separately from passing Node/harness tests.

Live-account qualification remains **explicitly opt-in** through the existing
[development validation harness](development-validation-harness.md), outside this
runner and CI. No opt-in can switch the deterministic proxy into a live forwarder.
The synthetic suite does not qualify live-platform proof evidence, full history
traversal, acquisition coverage, real consumer frozen-tab behavior or a release.
Missing or unstable upstream continuation must still fail closed.
