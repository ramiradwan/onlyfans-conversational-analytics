# Transport and request/response validation

This specification establishes measured internal limits and contracts for transport,
request, and response handling. Public exports, provider construction,
`read({ operation, parameters, refreshMode, signal })`, and canonical `{ items, continuation, boundary }`
remain unchanged. No consumer scheduler, account epoch, pagination traversal,
remote rule discovery, or required configuration is introduced.

## Contract and measured internal limits

The limits below are local safety policies, not claims of upstream maxima. Byte
budgets accept equality and reject one byte over. Field limits and aggregate limits
are independent: a page of individually valid fields can exceed the aggregate cap.

| Resource | Limit | Measurement |
| --- | ---: | --- |
| Response body | 8,388,608 | Bytes consumed from the Fetch body stream, before JSON parsing |
| Canonical page | 2,097,152 | UTF-8 bytes of JSON-serialized canonical data, including escaping and structure |
| Message text | 350,000 | UTF-8 bytes, preserving the existing field limit |
| Display name | 512 | UTF-16 code units, preserving the existing field limit |
| Canonical identifier | 256 | ASCII characters, preserving the existing field limit |
| Requested conversation ID | 128 | `[A-Za-z0-9_-]` characters |
| Retained captured headers | 7 | Allowlisted header entries, duplicates rejected before normalization |
| Header name / value | 64 / 4,096 | UTF-8 bytes; values must also satisfy the wire header character rules |
| Retained header aggregate | 16,384 | Sum of name and value bytes, excluding framing and discarded browser headers |
| Signing revision / prefix / suffix | 128 each | Characters, with controls prohibited |
| Static signing parameter | 4,096 | Characters, with controls prohibited |
| Checksum index count | 256 | Indices into the normalized 40-character SHA-1 digest |

`test/fixtures/slice6-size-corpus.js` is a reproducible, credential-free **synthetic**
stress corpus. It follows the existing reduced and full-object parser forms; it is
not a collection of live platform captures. Baseline measurements are committed in
`test/fixtures/slice6-size-measurements.json`:

| Fixture | Response bytes | Canonical bytes |
| --- | ---: | ---: |
| Identity/proof | 51 | 11 |
| 100 conversations with 512-character names | 57,826 | 58,432 |
| 100 messages with 4 KiB text each | 422,118 | 421,750 |
| One maximum-text message | 350,150 | 350,178 |
| One maximum-text message requiring JSON escaping | 2,100,150 | 2,100,178 |
| Rate-limit error | 44 | not applicable |

The canonical cap leaves nearly five times the ordinary synthetic 100-message page
size, while deliberately rejecting the escaped maximum-text example. The response
cap provides four times the canonical budget for full-object metadata. Captured
fixture headers total 185 bytes; the header limits allow longer session material
but are finite and separately enforced. These choices need live-account evidence
before being described as live-platform capacity qualification.

### Intent and wire contract

| Operation | Caller parameters | GET path | Wire query |
| --- | --- | --- | --- |
| `identity` | `{}` | `/api2/v2/users/me` | none |
| `conversations` | optional `query: { limit, cursor }` | `/api2/v2/chats` | optional `limit`, `offset` |
| `message-page` | `conversationId`, optional `query: { limit, cursor }` | `/api2/v2/chats/{id}/messages` | optional `limit`, `offset`, older-history `id`; `order=desc` with `id` |

All destinations use exactly `https://onlyfans.com`, without URL credentials or a
fragment. Optional trailing path slashes remain supported on wire input. Query
keys cannot repeat or be unknown. `limit` is an integer 1–100; its wire spelling
is canonical positive decimal. Caller `query.cursor` is absent, null, or a
nonempty `[A-Za-z0-9._~-]` token of at most 512 characters and maps unchanged to
wire `offset`. A validated opaque message-history cursor in the
`msg1.<chat>.<message>` form maps only on `message-page` to older-history wire
`id` with fixed `order=desc`. The public builder accepts only `limit` and
`cursor`; the compatibility matcher allows `order=desc` on any `message-page`
wire form and requires it when `id` is present, while retaining legacy raw
message URLs without `order`. The native `lastId` query is newer/ascending and
is outside this older-history operation. A wire `cursor` alias remains accepted for existing
typed callers, but it cannot coexist with `offset`. Percent-encoding must
decode to this same supported token domain; no broader opaque-token syntax is
claimed.

Undefined optional query/limit/cursor values are absent; null cursor means absent.
Null parameters, null query, null limit, empty cursor, noninteger limit, and unknown
keys are invalid. Parameters and query must be ordinary or null-prototype records,
not arrays or class instances. Operation names must be own supported string keys.
Caller intent is validated and snapshotted before storage, capture, or reload.

Static request headers are `accept` (optional), `app-token`, `x-bc`, and `x-of-rev`.
Dynamic headers are `sign`, `time`, and `user-id`. Requiredness on executable input
is documented in [request validation](request-validation.md); proof/capture paths retain their required evidence. Names
are compared case-insensitively before duplicates are lost. Header values are
nonempty visible ASCII without leading/trailing whitespace: no controls, DEL,
line breaks, implicit coercion, or browser-managed credentials are allowed.

Timestamps are canonical positive safe-integer decimal strings. The final dispatch
check preserves the simulator-derived absolute 30,000 ms window, including its
future-clock symmetry; this is **not** a verified upstream acceptance window.

### Verification and testing

Testing covers definitions, measurements, and exact UTF-8 accounting.
Enforcement covers parameter validation, stream bounds, and canonical limits,
with cross-layer transport qualification running in continuous integration.
Verification runs complete repository tests on branch pushes and verifies
package boundaries with read-only permissions without publishing a release.
