# Renewable signing adapter

## Purpose

The renewable adapter prepares fresh signed headers locally for the account owner's typed read requests. It does not copy cookies, automate sign-in, store API response bodies, accept arbitrary destinations, or provide mutation operations.

Revision-specific values and account context are private runtime artifacts. They must remain beneath gitignored `.local/` and must be regenerated when the authenticated browser profile or upstream revision changes.

## Components

### Browser runtime extraction

`dev:extract-config` connects to the loopback-only debugging endpoint and inspects the already loaded signing code in the authenticated OnlyFans tab. It:

1. discovers the loaded webpack runtime and SHA-1 implementation;
2. locates the request-signing module that depends on that implementation;
3. instruments fresh in-memory module instances without modifying the page's cached module;
4. observes the four-field digest input;
5. derives checksum index multiplicity and the checksum constant with synthetic digest values;
6. independently recomputes the observed signature;
7. writes the resulting rule configuration and session context beneath `.local/`.

The command does not inspect cookies, local storage, saved passwords, or API response bodies. Raw rule values and the user ID are not printed to stdout.

### Local preparation

`adapters/renewable-signing.js` accepts the private rule configuration plus a separate session context. For each request it:

- verifies that the method and URL match a supported typed read operation;
- serializes the exact pathname and query;
- obtains a fresh millisecond timestamp from the injected clock;
- computes the digest over static parameter, timestamp, path/query, and authenticated user ID;
- applies the runtime-derived checksum rule and framing;
- returns stable private headers plus fresh `user-id`, `time`, and `sign` values;
- selects `sign` for the invalid comparison request.

Browser-managed cookies and transport headers are added by the authenticated browser during `dev:probe` and are never returned by the adapter.

## Private artifacts

Rule configuration:

```json
{
  "schema": "local-renewable-signing-config/v1",
  "source_revision": "private revision value",
  "static_param": "private static parameter",
  "format": {
    "prefix": "private framing value",
    "suffix": "private framing value",
    "checksum_indexes": [0],
    "checksum_constant": 0
  },
  "headers": {
    "app-token": "private value",
    "x-bc": "profile-bound private value",
    "x-of-rev": "private revision value"
  }
}
```

Separate session context:

```json
{
  "session": {
    "userId": "private authenticated account identifier"
  }
}
```

The examples describe shape only. Never place real values in documentation, fixtures, tests, or tracked source.

## Workflow

Start from a fresh authenticated identity capture, then extract the current private configuration:

```powershell
npm run dev:extract-config -- `
  --capture .local/captures/identity-baseline.private.json `
  --config-out .local/renewable-signing-config.json `
  --context-out .local/renewable-session-context.json
```

Prepare a fresh candidate:

```powershell
npm run dev:prepare -- --operation identity `
  --adapter adapters/renewable-signing.js `
  --config .local/renewable-signing-config.json `
  --context .local/renewable-session-context.json `
  --private-out .local/candidates/renewable-identity.private.json `
  --summary-out .local/candidates/renewable-identity.summary.json
```

Run the differential proof:

```powershell
npm run dev:probe -- `
  --candidate .local/candidates/renewable-identity.private.json `
  --out .local/proofs/renewable-identity.json
```

Repeating `dev:prepare` must change only the timestamp-dependent headers when the configuration, session, operation, and query are unchanged.

## Refresh conditions

`dev:read` runs the capture/extraction/proof transaction when state is missing
or a successful response lacks revision agreement. Bootstrap and recovery share
one refresh budget. An unsuccessful 400/401/403, rate limit or upstream outage
is not evidence of stale signing rules and does not trigger automatic refresh.
Use `dev:refresh` for explicit setup/recovery after a known profile, account or
context change. The [failure and proof policy](failure-classification-and-proof.md)
describes the bounded control and the limitations of historical evidence.

Never work around extraction or proof failure by accepting arbitrary headers or
destinations. The active generation remains unchanged, and a major upstream
implementation change requires a reviewed extractor update.

## Verification procedure and evidence limits

Use the [development validation harness](development-validation-harness.md) to
reproduce a captured signature independently, prepare a fresh candidate, and
verify the candidate/control differential result before activating a private
generation. Verify each supported typed path, including query binding, with
synthetic and controlled browser evidence. The [release qualification
specification](release-qualification.md) defines the evidence required for a
packaged release.

The identity and conversations procedures provide bounded single-page evidence.
Message-page signing uses the same typed path/query contract, but live message
continuation and complete message-history traversal remain **unqualified**.
Neither a successful candidate nor a single page establishes full history.
