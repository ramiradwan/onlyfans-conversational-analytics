# Browser signing lifecycle consistency

This specification covers the browser generation store, provider lifecycle, and
Chrome persistence adapter. It does not introduce acquisition scheduling,
account enrollment, an account database, an application account epoch, or a
transactional persistence requirement.

## State and proof versioning

The document schema remains `browser-signing-state/v1`, the generation schema
remains `browser-signing-generation/v1`, and the default Chrome key remains
`browser_signing_state_v1`. The existing account-scoped `{ load, save }` adapter
and provider factory configuration continue to work.

Every committed document has a non-negative safe-integer `state_revision`.
Each successful activation or rollback increments it by one. A legacy v1
state without this field starts at revision zero **in memory only**. No storage
write occurs during loading, status inspection, or validation failure.

Each newly validated generation records `proof_policy_version`. A strong proof
object supplied to `activate()` must include both `outcome: 'strong'` and
`policy_version: CURRENT_PROOF_POLICY_VERSION`. The constant and predicates live
in the internal `src/signing/proof-policy.js` module. A caller cannot upgrade an
old generation merely by loading it or reading its `proof_outcome` field.

The proof policy implementation uses version 2. It enforces candidate-first, fresh
sign-only, same-revision comparison and recorded rejection-class checks.
`proof-policy.js` owns both those decisions and the version/predicates; the provider
attaches the current version to the result of a newly executed proof. Existing
stored proof is never promoted by metadata alone.

The policy number describes the implemented classifier, not an upstream
attestation. Documented evidence limits remain applicable. This
specification does not establish real-browser or production readiness.

Loaded generations with missing, older, or newer-than-current proof versions
remain available as stored documents but have `requires_validation: true` in
`status().active` or `status().previous`. Their `proof_policy_version` is exposed
as its stored number, or `null` when absent. A malformed version field is corrupt
state, not obsolete proof. The `requires_validation` field is derived, not stored.

| Condition | Behavior |
| --- | --- |
| Missing document (`null` or `undefined` from the injected adapter) | Empty in-memory store; no automatic save. |
| Unsupported document schema | `storage_schema_unsupported`; no overwrite. |
| Corrupt document or invalid generation | `storage_corrupt`; no overwrite. |
| Valid document with obsolete proof | Retain it; report `requires_validation`. |
| Transient load failure | `storage_load_failed`; a later attempt retries loading. |

Chrome's adapter additionally distinguishes an absent key from a malformed
storage response envelope. A null, array, scalar, undefined envelope, or an
explicitly undefined present value is not silently converted to missing state.
A missing key or a null stored document still represents no state.

## Conditional transitions

A lifecycle operation obtains a detached `store.readState()` snapshot **before**
starting capture or proof. Its precondition is:

```js
{
  state_revision: state.state_revision,
  active_id: state.active?.id ?? null,
  previous_id: state.previous?.id ?? null,
}
```

`transitionPrecondition(state)` constructs this token. The provider supplies it
as `expected` to `store.activate(...)` or `store.rollback(...)`. The store checks
all three fields **inside its serialized mutation**, against the state that is
actually about to change. A stale revision or either mismatched generation ID
throws `lifecycle_conflict`, without saving anything. There is no automatic retry
of a stale proof. The revision also catches an ABA sequence where both pointers
return to the same IDs after two intervening rollbacks.

The result is cloned from the committed state's `active` field after `save()`
resolves, never from a pointer selected before the queued mutation ran. Candidate
IDs must not collide with either retained generation. Revision exhaustion fails
closed rather than overflowing JavaScript's safe integer range.

Low-level store calls without `expected` remain available. They take a call-time
snapshot and are conditional too. Such a default does **not** cover network work
performed before the call; callers performing their own proof must supply their
pre-proof token. Low-level `rollback()` without a new proof only swaps a target
whose stored proof satisfies the current policy. The provider always re-proves
its rollback target and supplies both `expected` and the resulting proof.

## Provider lifecycle and ordinary reads

Refresh and rollback share one provider-local lifecycle queue. Capture, proof,
and conditional commit complete before the next lifecycle starts. Coalesced
refresh callers still share a single refresh. A failed lifecycle does not poison
the queue. A queued operation canceled before its turn does not start proof.

Rollback selects its target when its lifecycle starts, not when a caller first
queues it. Consequently, two explicitly queued provider rollbacks can each
succeed and swap back in sequence: each proves and returns its own exact target.
Concurrent store rollbacks using the same snapshot instead produce one commit
and one conflict. An intervening direct store activation during provider proof
also produces a conflict, never activation of a different previous generation.

Ordinary reads do not acquire this network lifecycle queue. They retain detached
snapshots of generations with current-policy proof. A read already using a valid
snapshot may finish while a lifecycle validates a replacement; its result keeps
the generation ID actually used for that read. Short serialized persistence
writes can still delay store reads. This is not a broad global network lock.

If active proof is obsolete, `read({ refreshMode: 'never', ... })` fails with
`refresh_required` before capture or page execution. With `refreshMode: 'allow'`,
the provider uses the existing capture/reproduce/prove/activate path. Failed
revalidation leaves the exact saved last-known-good document untouched. On
successful refresh the former active generation remains `previous`; its old
proof is not relabeled. Successful rollback proof upgrades only the exact
selected target's proof version, retaining its ID and creation time.

Bootstrap, obsolete-proof validation, and read-failure recovery share one refresh
budget per `read()`. Bootstrap/migration can perform one capture, candidate and
control comparison, then one requested page. A read starting with a usable
generation can perform the initial page, one refresh sequence, and one retried
page. A subsequent failure cannot start a second refresh. A typed success with a
mismatched revision still cannot be returned as a successful page.

Failure classification and differential proof decisions remain in place as documented
in [failure classification and differential proof](failure-classification-and-proof.md).
Unsuccessful 429/5xx/unclassified authorization responses are not revision drift;
safe failure and validation codes remain outside canonical `data`. Complete
cancellation and resource cleanup policies are documented in [cancellation and resource cleanup](cancellation-and-resource-cleanup.md).
This queue is not a claim that an uncooperative host request can always be canceled promptly.

## Persistence ownership and failure boundaries

**Single writer:** exactly one store owns each account-scoped persistence
document at a time. Multiple consumers may use that store. Its mutation queue and
revision tokens do not coordinate independent store instances, service workers,
processes, or an external writer. An application needing those guarantees must
provide external ownership coordination or a stronger persistence primitive;
plain `{ load, save }` cannot manufacture cross-instance compare-and-swap.

An adapter must load and replace complete documents. Successful `save()` means
that the supplied complete document has been accepted by the adapter. The store
passes detached copies to load/save callers and publishes a new cached state
only after a successful save. Its private state is not aliased by snapshots,
results, caller inputs, or persistence arguments.

A rejected save is reported as `storage_save_failed`. No compensating write is
attempted. A save may commit and then lose its acknowledgement, so the store
invalidates its cache and reloads before any subsequent mutation. That reload
may recover the old document or the newly committed document; a queued token
must match whichever complete state was recovered. Corruption or another load
failure remains an error and is never turned into an empty store. A failed
initialization is not cached forever.

There is no promise that cancellation or a rejected save means “nothing was
committed.” With a non-cancelable adapter, persistence may complete after the
caller abandons the operation. A committed generation must have passed the
shipped proof policy before persistence began. This specification does not claim that
cancellation can interrupt an already committed persistence write, or stronger
upstream proof evidence than the bounded differential classifier documents.

The state revision is a signing-document mutation counter, not an acquisition
generation or an application account epoch. Consumer authorization, durable
page ingestion, coverage, and vendored-package adoption remain consumer-owned.

## Regression coverage

Run:

```sh
node --test test/browser-signing-failures.test.js test/*slice3.test.js
```

The suites cover serialized rollback results, proof-time activation conflicts,
exact generation identity checks, ABA, delayed and failed saves, ambiguous save
acknowledgements, corrupted storage, initialization retry, detached snapshots,
proof migration and restart, concurrent provider lifecycles, read independence,
Chrome callback and Promise adapters, and the one-refresh migration budget.

`test/baseline-regressions-slice3.test.js` exercises public lifecycle entry
points to verify deterministic state-transition invariants, proof version 1 to
version 2 migration, and failure containment against synthetic host doubles. These
are deterministic unit/host-double tests, not real-browser worker-termination or
live-account qualification.

Verification requires running full repository tests, installed-package consumer contract,
and package audit on the actual checkout before release qualification. Focused runtime/host-double
results are not substitutes for those gates.
