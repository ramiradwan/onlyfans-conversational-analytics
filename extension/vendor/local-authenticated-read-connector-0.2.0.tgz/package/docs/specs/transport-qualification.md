# Transport qualification and cross-layer verification

Transport qualification establishes tests, a browser CI gate, and qualification records for the transport and validation layer.

## Reproduce the gates

```sh
npm test
npm run test:slice6
npm run test:contract
SIGNER_CHROME_BINARY=chromium npm run test:browser:transport
```

The installed contract packs the actual repository, installs it in a separate
consumer directory offline, and runs through public package imports. The shared
`conformance.mjs.txt` fixture is copied as `.mjs` into that consumer; the source
wrapper registers exactly the same suite against source exports. No production
validator is mocked and no module-scope helpers are available to the serialized
MAIN executor. Fetch is a controlled response fixture in the Node suite, not a
claim about real Chrome or upstream authentication.

Four fixed seeds (`0x6f000001` through `0x6f000004`) each drive 64 iterations of
three properties: usable continuation round trips, malformed continuation
rejection before fetch, and Unicode projection/conflicting-alias handling.
That is **768 seeded iterations per source or installed run**, plus deterministic
boundary tables. Grouped tests, iterations, and nested installed cases are
reported separately. Each assertion identifies its seed and case index.

```sh
node --test --test-name-pattern='6F seed 1862270977' test/qualification-properties-slice6.test.js
SIGNER_REGRESSION_ENTRY=/absolute/reference/src/signing/index.js node --test test/qualification-regressions-slice6.test.js
```

The second command is an intentional negative-control run:
canonical aggregate overflow, overwritten explicit direction, ignored conflicting
continuation and item aliases, and sparse successful pages. All five pass against
the current implementation. The optional entry affects only the test's import;
it is not an arbitrary-origin or runtime configuration feature.

## Coverage and verification

The transport test suites cover: invalid intent before side effects;
portable/standalone request parity; header budgets/controls/duplicates; independent
signature vectors and arithmetic bounds; final freshness; redirect options;
actual streamed byte boundaries, misleading Content-Length and cleanup; canonical
JSON/field boundaries; full projection, aliases, and continuation round trips.

The qualification suite includes shared source/installed seeded checks, percent-encoded wire equivalence,
independent canonical JSON byte oracles, numeric/origin/timestamp boundaries and
three consumer-shaped tests through the proxy plus actual serialized executor:
maximum numeric continuation through `read()`, no refresh/save on canonical
failure with missing revision, and invalid read intent with no additional storage,
capture or request side effects after factory initialization.

## Environment requirements and qualification gates

Qualification requires verifiable, fail-closed execution across separate gates:

| Gate | Requirement | Evidence artifact |
| --- | --- | --- |
| Repository test suite | Complete `npm test` run with zero failures/unjustified skips | Unit and integration TAP output |
| Installed consumer contract | Tarball packed and installed in an isolated temporary consumer | `npm run test:contract` TAP output |
| Seeded qualification suites | Deterministic pseudorandom properties and wire encodings | Seeded suite run output |
| Controlled browser runner | Browser transport executor under local HTTPS proxy | Browser runner TAP log and receipts |
| Extension qualification | Packed MV3 extension under managed browser instance | Qualification report JSON and receipts |

Neither successful upload nor a Node VM execution substitutes for browser CI.

## Browser gate, not a browser qualification claim

`tools/check-transport-browser.mjs` independently installs the tarball, serializes
the actual executor into a real browser page, and uses local HTTPS plus a closed
proxy. It retains same/cross-origin redirect-target checks, streaming limit minus
one/equality/plus one, status/retry preservation and cancellation. It includes
maximum-numeric continuation round trips, explicit direction preservation,
canonical overflow and conflicting-continuation checks.
Response interpretation uses the same installed package's parser. No personal
credentials or external platform response is used.

The runner enforces fail-closed execution: if the browser binary is unavailable,
blocked by environment policy, or encounters navigation failure before assertions,
the runner fails rather than skipping. `.github/workflows/slice6.yml` runs this runner as an
independent job and archives its log and source revision separately from Node results.

This runner is not an MV3/real executeScript/worker-termination or supported
Chrome-baseline matrix. Those remain separate browser qualification gates. Live-account and complete
history traversal remain unqualified. The existing fixtures demonstrating missing
continuation, skipped records with guessed strides and repeated windows remain.

## Transport contracts and diagnostic policy

Production documentation is split by concern:
[measured budgets](transport-validation.md), [request contract](request-validation.md),
[signing inputs/freshness](signing-input-validation.md),
[stream transport](transport-bounds.md), and
[projection/continuations](response-validation.md).

The four size domains stay distinct: 8 MiB consumed response bytes, 2 MiB canonical
JSON page bytes, per-field bounds, and captured-header bounds. Equality succeeds;
overflow returns no successful data. No browser-process absolute heap claim.

Before a response exists, native fetch/redirect errors, context loss, cancellation,
and timeout retain existing exception conventions. After headers, bounded body
failures retain observed status and bounded 429 retry timing, with an allowlisted
validation code. Canonical/page failures are unsuccessful reads, not signing-drift
or negative-control evidence; they never authorize extra recovery work.

Public responses retain `response.status`, `response.retry_after_ms`, `failure_code`
and `validation_error`, keep all diagnostics outside `data`, and cover
`canonical_page_too_large`, `conflicting_page_continuation`, `conflicting_page_items`
and `invalid_page_has_more` codes in checked declarations. Keep values bounded and
sanitized; no upstream text, headers, account identifiers or exception causes in
public hooks.
