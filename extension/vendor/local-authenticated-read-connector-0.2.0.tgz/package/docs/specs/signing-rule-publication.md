# Signing-rule publication

## Purpose

A packaged signing rule is a release input for the consuming extension. It is emitted from private
renewable signing state, published as a GitHub release asset, retrieved by immutable asset id, and
then bundled into the extension. The rule is never committed to this repository and is not a
runtime rule feed.

## Publication bytes

The consuming package names the SHA-256 of the exact bytes it ships, so signer publication uses the
same JSON representation the package writes:

1. top-level members in `schema`, `source_revision`, `static_param`, `format` order;
2. `format` members in `prefix`, `suffix`, `checksum_indexes`, `checksum_constant` order;
3. two-space JSON indentation;
4. exactly one trailing newline.

`canonicalJsonText` remains the compact, sorted representation for internal equality. It is not the
release-asset representation.

Generate the private asset with:

```text
npm run dev:emit-rule -- --config .local/<renewable-config>.private.json --out .local/packaged-signing-rule.json
```

The emitter reports both a short log correlator and the full 64-hex SHA-256. Sensitive rule members,
including `checksum_constant`, are fingerprinted in the emit summary.

## Publishing

Create the GitHub release/tag that will locate this rule. When the release is created remotely, sync
the local checkout's tag view before continuing:

```text
git fetch --tags
```

Then publish the private rule:

```text
npm run dev:publish-rule -- --rule .local/packaged-signing-rule.json --repo ramiradwan/local-of-signer --tag <release-tag>
```

The command accepts `GH_TOKEN` or `GITHUB_TOKEN`, and otherwise uses `gh auth token`. The credential
must be able to read the private repository and upload release assets. If GitHub cannot resolve the
requested release tag, the publisher reports an actionable error that directs the operator to create
the release first and verify token access.

Publication fails unless the input remains beneath `.local/` and its bytes exactly match the
publication serialization. Before uploading, it paginates the release's asset list and refuses to
replace a same-name asset on any page. A successful publish reports the coordinates the consuming
build must pin:

- `release_tag`: the release locator;
- `release_asset_id`: the numeric immutable asset identifier;
- `document_sha256`: the bare lowercase SHA-256 of the published bytes;
- `source_revision`: the platform revision reproduced by the rule.

The consuming gate should resolve the release under `release_tag` and require that it publishes
exactly `release_asset_id`. The tag is only a locator and may move; the asset id and digest are the
identity of the selected bytes.

As specified in ADR 0005, production receives one reviewed rule as a build input
and does not consume a runtime rule feed.

## Verification and interrupted publication

Success requires downloading the numeric asset ID and comparing every byte,
not merely checking the uploaded name and size. Reports additionally include
`release_id`, `verified`, and `reconciled`. Network requests, body reads, and asset
pagination are bounded; errors never echo GitHub response bodies or token-bearing
URLs. At most one upload POST is attempted, and no existing asset is deleted or
replaced. A duplicate-name race or lost acknowledgement is reconciled read-only.

After an interrupted or unconfirmed upload, use verification-only mode:

```text
npm run dev:publish-rule -- --rule .local/packaged-signing-rule.json --repo ramiradwan/local-of-signer --tag <release-tag> --verify-existing
```

This mode never uploads, including when the asset is not yet visible. See
[Private development state and publication](private-development-state.md) for
exact limits, credential-safe redirect policy, recovery outcomes, and filesystem
assumptions. Use `--timeout-ms` to lower or raise the finite total network budget
(default 120000, maximum 300000 milliseconds).
