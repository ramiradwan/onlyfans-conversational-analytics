# Signing inputs and final dispatch freshness

## Signature algorithm and normalization

The signing input remains four newline-separated fields: the packaged static
parameter, the minted timestamp, the exact path plus query, and the session user
ID. The algorithm remains SHA-1 followed by the absolute checksum of selected
hexadecimal character codes plus the rule constant. Duplicate checksum indexes
still contribute repeatedly. The signature retains `prefix:digest:checksum:suffix`.
The connector signs locally with the supplied rule. It does not fetch remote
executable rules or infer fallback algorithms.

A digest provider may return exactly 40 lowercase, uppercase, or mixed-case hex
characters. The digest is canonicalized to lowercase ASCII **before** both checksum
calculation and signature emission to ensure deterministic signature generation.
Prefix and suffix are opaque rule fields: their capitalization is preserved.
Malformed digests are rejected without trimming or coercion. Observed signatures
must still match the reproduced complete signature exactly; this is not a relaxed
comparison of captured signature strings.

## Shared metadata contract

Packaged rules and renewable configurations use one internal format validator.
Format records contain only plain data fields; reject unknown keys, symbols and
accessors. Checksum indexes must be a dense array of 1–256 own numeric entries,
each an integer from 0 through 39. Sparse or accessor-backed indexes cannot be
silently skipped by `map`/`reduce`. Validated metadata is copied and frozen before
asynchronous hashing, so caller mutation cannot change the resulting signature.

Prefix and suffix contain 1–128 visible ASCII characters, excluding whitespace
and `:`. Revision length is 1–128 visible ASCII characters. The static parameter
contains 1–4,096 UTF-16 code units and no ASCII controls or DEL; non-ASCII static
parameters retain their existing UTF-8 hashing behavior. These are local bounds,
not assertions about upstream maxima. These limits align with transport validation budgets.

For `n` checksum indexes, the checksum constant must be a safe integer satisfying:

```text
Number.MIN_SAFE_INTEGER <= constant <= Number.MAX_SAFE_INTEGER - 102 * n
```

The largest lowercase hex character code is `f` = 102. Each contribution is
positive, so this bound makes every intermediate sum and the final absolute value
exact under JavaScript Number arithmetic for **every** accepted digest. Equality
is accepted. A larger constant is rejected during metadata validation, even when
a particular digest might happen to fit; values are not clamped, wrapped or
rounded. The public `createSignatureFromDigest` helper also enforces this contract
when passed a manually constructed normalized configuration.

## Signing inputs and timestamp representation

Minted and captured timestamps share one representation check: canonical positive
safe-integer decimal strings, without leading zeros, signs, decimals, whitespace
or alternate numeric spellings. Numeric values are not coerced into header strings.
Session IDs are canonical positive decimal **strings**, at most 256 digits. They
are not converted to Number; large exact identifiers remain supported. Captured
IDs and supplied executor `user-id` headers use the same domain. The executor's
existing minimum-required-header contract is unchanged; this does not newly
require `user-id` for every direct low-level invocation.

The public signing-input helper validates its static parameter, timestamp, user
ID, and typed path/query. It rejects inputs whose URL parsing would normalize the
path after signing. Existing builder-generated inputs and fixed signature vectors
are unchanged. Invalid captured timestamps/IDs are rejected before the digest
provider runs.

For older message history, the validated opaque `msg1.<chat>.<message>` cursor
is carried unchanged by the consumer and encoded as the message request's
`id` query with fixed `order=desc` before signing. The native
`lastId` query is the separate newer/ascending mode and is not emitted by this
operation. The exact resulting path and query remain part of the signed input.

## Decisive check at transmission

The final freshness check remains inside the closure-free MAIN executor's actual
fetch callback, after asynchronous preparation and dispatch delays. It uses one
clock sample for both the absolute transport deadline and signed-request freshness.
The URL string is prepared before this check, and no asynchronous step separates
the check from fetch. An expired request is rejected without fetching or minting
a replacement timestamp. Existing cancellation, document binding, cleanup and
retry budgets are preserved.

The **30,000 ms absolute-age window is a local safety policy derived from the
repository simulator, not verified upstream acceptance behavior**. Equality is
accepted on both sides: requests 30,000 ms old or 30,000 ms in the future retain
the existing behavior; 30,001 ms in either direction fails. The independent
transport expiry still fails at equality and cannot be renewed by a delayed
injection. Custom host adapters remain responsible for freshness at their own
actual transport boundary. MAIN is not a trusted enclave against page tampering.

## Focused regression evidence

`test/signing-inputs-slice6.test.js` includes independent committed signature
vectors, accepted capitalization, malformed digests, exact arithmetic limits,
repeated indexes, negative/zero checksums, format and field boundaries, metadata
mutation, captured-input rejection before hashing, timestamp/ID parity, and
serialized executor delay/cleanup cases. It serializes the production function
into a separate VM rather than importing its closure bindings. The arithmetic
oracles are fixed from ASCII values, not generated by the signer implementation.

The separately packed and installed consumer fixture adds digest-capitalization,
checksum-bound, and serialized dispatch-delay cases through the public package
import. The harness discovers installed `.test.mjs` suites so these cases cannot
silently run against source self-reference.

Verification commands:

```sh
node --test test/signing-inputs-slice6.test.js
npm run test:contract
```

This is focused Node and serialized-executor verification. Real Chrome,
live-account, full-history, and platform qualification remain separate gates.
