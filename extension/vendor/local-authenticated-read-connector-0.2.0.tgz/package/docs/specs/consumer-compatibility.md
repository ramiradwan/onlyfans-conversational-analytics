# Consumer compatibility contract

## Scope and consumer architecture

This specification defines the contract between `local-authenticated-read-connector` and its consuming applications, specifically the `ramiradwan/onlyfans-conversational-analytics` extension.

The production consumer builds `extension/background-read-only.js`, not the nearby authoring `background.js`. Its architecture is:

```text
build.mjs: packaged signer wrapper
  -> background-read-only.js
  -> transport/read-only-agent-runtime.mjs: lazy signer
  -> transport/read-only-history-coordinator.mjs: read()
  -> transport/read-only-signer-normalization.mjs
  -> transport/read-only-durable-outbox.mjs: commitPage()
```

The build injects one packaged rule. The runtime supplies `expectedIdentity`, an
account-partitioned persistence adapter, and a Promise-returning Chrome proxy.
The coordinator uses only `read()`. Its account epoch, consent checks, job leases,
deadline, rate-limit deferral, and commit transaction are not signer features.
See the consumer's ADR 0010 and the architecture paths above when changing this
boundary. The read-only coordinator has a parity test with its authoring twin;
this repository must not copy either coordinator into a test or runtime module.

Implementation capabilities and verification gates are tracked in
the [production readiness guide](production-readiness.md). Failure and proof
decisions are described in [failure classification and proof](failure-classification-and-proof.md).

## Ownership

| Signer | Consumer Agent | Brain |
| --- | --- | --- |
| Validate one typed request and one response page | Select/authorize the account; consent/session gates | Canonical persistence and conflict rules |
| Sign locally with a build-packaged rule | Scheduling, page budgets, spacing, retry limits | Derive completeness from evidence |
| Capture/prove/manage private signing generations | Own storage partition, encryption and account epoch | Projections and analytics |
| Use injected persistence for signing state only | Normalize into application facts and deduplicate | Application authorization |
| Honor cancellation and return page evidence | Atomically commit entities, evidence, cursors and outbox | Coverage presentation semantics |

A signing generation is not an acquisition generation or an account epoch.
The signer must not add alarms, durable retry queues, history cursors, outboxes,
account enrollment, completion flags, page digests, or a second direction mapper.
Browser-context checks can protect a read without taking over application commit
authority. The existing consumer frozen-tab wrapper remains consumer-owned until
an explicitly coordinated migration; the compatibility fixture models only its
async Chrome API shape, not its policy.

## Public imports and construction

The checked-in `test/fixtures/consumer-compatibility/public-api.json` records all
named export types at the baseline for:

- `local-authenticated-read-connector` (simulator/general connector entry);
- `local-authenticated-read-connector/browser-signing` (production-facing entry);
- `local-authenticated-read-connector/renewable-adapter` (Node adapter entry).

Tests require these exports to remain importable from an installed tarball.
Additive exports are permitted. The snapshot records the historical package
version and entry filenames; neither a version bump nor moving implementation
files is intrinsically an API break. The public subpaths are the contract.

Consumer-style construction remains:

```js
const signer = await createChromeBrowserSigningProvider({
  chromeApi: guardedChromeApi,
  persistence: accountSigningPersistence,
  expectedIdentity: authorizedPlatformCreatorId,
  packagedRule: buildPackagedRule,
});
```

`packagedRule` is mandatory at the package boundary, even though the extension's
build wrapper supplies it rather than its background source. No runtime rule
feed or page-runtime discovery is implied. The `{ load, save }` adapter loads
`null` or a signing-state document and saves whole replacement documents. Its
account routing and transactional guarantees belong to its owner. This baseline
does not claim cross-instance compare-and-swap from that interface.

With custom persistence, the provider must not fall back to global
`chrome.storage.local`. Tests make such access fail. A newly constructed provider
can reuse saved signing state without recapturing for a healthy read; this is a
reconstruction test, not a real service-worker termination test.

## Read contract

```js
await signer.read({
  operation: 'conversations',
  parameters: { query: { limit: 2, cursor: null } },
  refreshMode: 'allow',
  signal: controller.signal,
});
```

| Operation | Parameters | Canonical data |
| --- | --- | --- |
| `identity` | `{}` | `{ id }` |
| `conversations` | optional `query: { limit, cursor }` | One page of conversations |
| `message-page` | `conversationId`, optional `query: { limit, cursor }` | One page of messages |

Methods and destinations are package-owned typed GETs. `limit` is an integer
from 1 through 100. A cursor is consumer-opaque: the consumer passes it unchanged.
Conversation cursors and other supported message cursors map to the upstream
wire `offset`. An opaque message-history cursor in the `msg1.<chat>.<message>`
form maps to the message endpoint's older-history `id` query with fixed
`order=desc`; the consumer does not decode or rewrite that token. The public
builder accepts only `limit` and `cursor` from callers and emits that fixed
wire order. A legacy raw message URL without `order` remains accepted by the
compatibility matcher, but is not emitted by the builder. The matcher also
allows `order=desc` on other `message-page` wire forms; when `id` is present,
that order is required. The
native `lastId` query is the separate newer/ascending mode and is outside this
older-history operation.

Native pages with `hasMore` use `nextOffset` when supplied. Reduced pages use
their explicit `next_cursor` and `boundary`. For native message pages without
`nextOffset`, the signer derives the opaque older-history cursor only from a nonempty list whose
message IDs are bounded positive decimal strings, unique within the page, and
strictly descending, bound to the requested conversation. Empty or unusable
lists fail closed. A `next_cursor` alias on a native page must agree with the
derived or explicit continuation. This validates one page and its continuation; it does not
qualify full-history traversal.

`refreshMode` accepts `allow` (default) or `never`. `never` does not capture or
reload to repair missing state; it reports `refresh_required`. One call returns
one page and must never follow its continuation. Caller-driven cancellation
preserves the supplied `AbortSignal.reason` exactly, including non-`Error`
values. Calling `AbortController.abort()` without an argument supplies the
platform's default `AbortError`, which is preserved too. If an aborted signal's
reason is unavailable, the signer uses a `DOMException` named `AbortError`.
The caller decides whether and when to schedule more work. The
signature timestamp and request freshness policy are distinct from the
consumer's acquisition-run deadline.

The result envelope retains these fields:

```text
schema: browser-signing-read/v1
operation, generation_id, refreshed, refresh_reason, success
response: { status, content_type, response_class, retry_after_ms }
data: canonical identity/page on success; null on failure
```

Safe additive diagnostics may be introduced in the envelope or response summary.
They must not expose raw bodies, signing material, arbitrary upstream messages,
or private browser values. Tests deliberately do not require an exact envelope
key set, exact exception text, or the continued absence of useful diagnostics.
For 429, consumers already read `response.status` and `response.retry_after_ms`.
They own retry timing and retry budgets; changing that interface requires a
coordinated migration.

Successful canonical shapes are exact:

```text
page:         { items, continuation, boundary }
conversation: { id, platform_user_id, display_name, updated_at }
message:      { id, chat_id, sender_platform_user_id, text, sent_at, direction }
```

Identifiers are normalized strings. Conversation `updated_at` and `display_name`
can be null. Message `chat_id` is request-derived when that context is supplied;
`direction` can be null. The consumer performs account-relative interpretation.
A continuation and a terminal boundary are mutually exclusive. Boundaries are
operation-specific: `inventory_end` or `history_start`. A terminal page may have
items. No page asserts that an entire acquisition is complete.

Full upstream objects are projected into these shapes. Unknown discarded fields
must not cross the boundary; conflicting authoritative aliases must not be
silently accepted. Semantically invalid pages have `data: null`. A nonterminal
message page without trustworthy continuation remains invalid rather than
inventing a stride.

## Error handling and lifecycle contracts

Error handling and lifecycle contracts follow strict invariants:

- **Structured errors**: Construction and parameter validation errors throw typed exceptions (`IntentValidationError`, `TypeError`). Expected operational failures reject with `BrowserSigningError` carrying a fixed `code` from `SIGNING_FAILURE_CODES`. Unsuccessful HTTP or semantic reads report `success: false` with structured `response.failure_code`. Cancellation rejects with `AbortError`.
- **Identity enforcement**: Stored state and candidate responses are verified against `expectedIdentity`. Mismatched identities fail closed with `account_mismatch` and prevent state activation.
- **Differential proof**: Credential recovery validates a candidate read and requires a corrupted-sign comparison to return HTTP 400 without the expected shape before activation.
- **Refresh budget**: A single-refresh budget per `read()` call prevents unbounded reload loops during failure conditions.
- **Metadata status**: `status()` reports tab availability and provider readiness metadata. It confirms whether a matching tab exists without asserting that the session is authenticated.

## Verification suite

The compatibility test suite (`npm run test:contract`) verifies package behavior against an independently installed tarball:

1. Performs a real `npm pack` into an OS temporary directory.
2. Verifies that development tools, tests, and private files are excluded from the manifest.
3. Installs that tarball offline into an isolated temporary consumer project.
4. Runs contract tests using public-package imports, verifying resolved entry paths.
5. Asserts export types, independently fixed signature vectors, cold activation, injected persistence, factory reconstruction, single-page behavior, failure privacy, identity binding, and metadata-only status.

All data and rule material in the test suite are synthetic. Expected signature vectors are fixed literals generated with independent SHA-1 and checksum arithmetic, never recalculated from runtime signing functions. The installed compatibility fixture validates the package boundary and does not run the actual analytics extension; real browser qualification is documented in [browser qualification](browser-qualification.md).

## Consumer adoption

Adopting a new signer package requires updating the consumer's vendored tarball, lockfile entries, and build pins, followed by running consumer module-graph, normalization, coordinator, and package audit suites. New diagnostics remain additive to maintain compatibility with existing consumer error handlers.
