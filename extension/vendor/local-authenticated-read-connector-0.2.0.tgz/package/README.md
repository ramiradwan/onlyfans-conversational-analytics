# Local authenticated read connector

This package provides a typed, read-only connector for local applications that use an account owner's authenticated browser session. It keeps request authorization separate from downstream scheduling, storage, and analytics.

## Goals

- Define stable read operations independently of any upstream request-authorization mechanism.
- Compare page-native and locally prepared authenticated request strategies behind the same contract.
- Prove deterministic single-page validation, history-boundary evidence, session binding, rule rotation, retries, and explicit failure behavior.
- Produce integration evidence without depending on the conversational-analytics repository.

## Boundaries

The package validates and returns one authenticated read page per call. Its consumer owns every
cross-page loop, durable cursor, retry schedule, commit boundary, and coverage state transition.

- Read operations only.
- The account owner's authenticated session remains local; dedicated browser state and private artifacts stay beneath gitignored `.local/` and are removed after research sessions.
- No credential export to another service.
- No generic arbitrary-URL request proxy.
- No message sending, media retrieval, account mutation, fingerprint manipulation, proxy rotation, challenge circumvention, or traffic-disguise features.
- No observed header values, account identifiers, or browser identifiers are stored in source control. Production receives an explicitly reviewed, revision-pinned signing rule from the consuming build; observed per-browser values remain private local state. No external rule feed is used.

The executable harness uses a simulated upstream service and a conventional HMAC-based authorization scheme. Its purpose is to test adapter boundaries and lifecycle behavior, not to reproduce a live platform.

## Architecture

```text
semantic read intent
        |
        v
authenticated read connector
  | session provider
  | authorization adapter
  | constrained transport
        |
        v
simulated upstream API
        |
        v
page results + coverage evidence
```

The connector accepts a small set of semantic resources and relative paths. The authorization adapter never receives permission to choose arbitrary destinations or methods.

## Run

The Node.js installation floor is 22; there are no runtime dependencies. The
qualification matrix, not the floor alone, identifies tested environments.

```powershell
npm ci --ignore-scripts
npm test
npm run test:types
npm run test:coverage
```

## Diagnostics and TypeScript

All three existing package entry points include checked declarations; runtime code
remains JavaScript with no runtime dependencies. `read()` narrows results by
operation and `success`, preserving nullable message direction and the exact
canonical page shape.

The optional `onDiagnostic` callback receives bounded, allowlisted completion
facts, never response bodies, account identifiers, headers, or exception causes.
Its return value is ignored and thrown errors or rejected promises cannot replace
the signing result. Use `publicSigningError(error)` when logging a caught error;
do not serialize the original error or private generation state.

`status()` performs no authenticated read or refresh. It separates tab availability,
stored generation, packaged-rule compatibility, current proof policy and expected
identity matching. A matching tab does **not** establish authentication:
`browser.ready` and `readiness.ready` are `false` or `null`, never a readiness claim.
See [diagnostics and public types](docs/specs/diagnostics-and-public-types.md) for
fields, compatibility notes and qualification limits.

## Package qualification and release limits

Qualification builds one tarball and binds its actual-byte audit, installed consumer/type
checks, supported Node/platform matrix, focused module coverage and controlled
browser qualification to its source revision and SHA-256. Successful runs retain
the package, checksums, inventory and a machine-readable report. Local and manual
external runners support qualification when GitHub Actions is unavailable.
Node 22/24 run on Linux, macOS and Windows, with Node 26 additionally on Linux.
Real transport and native/proxy MV3 tests exercise stable Chrome and the isolated
Chrome 106 compatibility baseline. Only completed reports establish results.

The manual tag-only release workflow reuses these gates, separates publication
permissions, verifies uploaded bytes before leaving draft and records optional
provenance without assuming private-repository entitlement. **Release-evidence
policy v1 remains prerelease-only and always reports `production_ready: false`.**
Its deterministic report deliberately does not make a live-account or
complete-history claim.

Signer `0.2.0` is an unpublished stable candidate. A separate
`signer-production-readiness/v1` review can mark one exact candidate eligible
for stable promotion when its bundle contains the exact Git-bound package, all
eleven receipts and logs, runner provenance, fresh sanitized live and consumer
inventories, and an explicit technical review. This is a readiness result; it
does not authorize a merge, tag, publication, consumer deployment or account
configuration change. Use the separate bundle commands only after assembling
fresh evidence:

```sh
npm run production:generate -- <bundle>
npm run production:verify -- <bundle>
npm run production:release-check -- <bundle> v0.2.0
```

Hashes bind the files inside a bundle but do not establish authenticity by
themselves. Publication remains a separate owner-controlled operation that
must verify the integrated source tag, exact uploaded bytes, no-clobber
behavior, bounded retries and final asset inventory. The signer owns the fixed
typed operations `identity`, `conversations`, `message-page` and their opaque
continuation; the consumer owns traversal, durable cursors, deduplication,
commits and coverage. A live consumer qualification may establish only a
scoped current-account snapshot when it binds the exact package, signer source,
consumer revision and built extension artifacts.

A **signing generation** is validated signer state; an **acquisition generation**
is the consumer's run/commit fence; an **application account epoch** is the
consumer's authorization boundary. Injected `{ load, save }` requires single-writer
ownership, not cross-process compare-and-swap. Legacy strong proofs require
current-policy revalidation. Once non-cancelable `save()` begins, cancellation may
still leave a fully validated generation committed, but returns no successful
page. MAIN-world execution trusts page-realm integrity; consent, frozen-tab policy
and durable commit fencing remain consumer responsibilities.

See [release qualification and capability matrix](docs/specs/release-qualification.md)
and [ADR 0006](docs/adr/0006-evidence-bearing-release-gates.md). Run
`npm run test:release` for audit/policy regressions and `npm run qualify:pack`,
`npm run qualify:node`, and `npm run qualify:coverage` for local evidence. The
deterministic report requires every required environment, not just one local
host; the production-readiness bundle adds its own review and live/consumer
evidence checks.

## Documents

- [Production readiness](docs/specs/production-readiness.md) details production architecture, capabilities, and qualification gates.
- [Release qualification and capability matrix](docs/specs/release-qualification.md) defines package qualification gates, coverage floors, and policy limits.
- [Consumer compatibility](docs/specs/consumer-compatibility.md) records the installed-package regression contract and ownership boundaries.
- [Packed-package real-browser qualification](docs/specs/browser-qualification.md) describes the isolated MV3 extension, supported-browser matrix, lifecycle tests and evidence. Run `npm run test:browser:harness` for fixture checks or `npm run test:browser` with a disposable Chrome installation.
- [Browser document context and identity](docs/specs/browser-document-context.md) defines document targeting, identity checks, and browser/persistence boundaries.
- [Cancellation and resource cleanup](docs/specs/cancellation-and-resource-cleanup.md) defines abort reasons, coalesced refresh retirement, transport ceilings, and the persistence commit point.
- [Failure classification and differential proof](docs/specs/failure-classification-and-proof.md) details read decisions, refresh budgets, and differential proof policy.
- [Signing lifecycle consistency](docs/specs/signing-lifecycle-consistency.md) covers generation storage, conditional transitions, and single-writer persistence.
- [Diagnostics and public types](docs/specs/diagnostics-and-public-types.md) covers safe failure vocabulary, diagnostic callbacks, and checked declarations.
- [Request validation](docs/specs/request-validation.md) specifies request parameter and header validation.
- [Bounded browser transport](docs/specs/transport-bounds.md) specifies streaming bounds, redirect handling, and response metadata.
- [Transport qualification](docs/specs/transport-qualification.md) documents cross-layer transport verification.
- [Private development state](docs/specs/private-development-state.md) specifies local filesystem security, lock ownership, and pointer transaction semantics.
- [ADR 0001](docs/adr/0001-local-read-connector-boundary.md) records the stable architectural boundary.
- [Connector contract](docs/specs/connector-contract.md) describes the evolving executable interface.
- [Development validation harness](docs/specs/development-validation-harness.md) documents browser capture, preparation, comparison, and live proof.
- [Renewable signing adapter](docs/specs/renewable-signing-adapter.md) documents private runtime extraction, local signing, refresh conditions, and live evidence.
- [Signing-rule rotation](docs/specs/signing-rule-rotation.md) documents one-command reads, atomic activation, bounded retry, and rollback.
- [Signing-rule publication](docs/specs/signing-rule-publication.md) documents release-asset serialization, upload, and consumer coordinates.
- [Browser-hosted signing provider](docs/specs/browser-hosted-signing-provider.md) documents the Chrome MV3 host contract, private browser generations, and typed in-memory response handoff.

## Development validation harness

The browser-session validation suite separates four activities:

1. Capture one known-good read request from an already authenticated browser tab.
2. Prepare a candidate request through a replaceable authorization adapter.
3. Compare request shapes without printing raw header values.
4. Probe the candidate from inside the same authenticated browser context and classify the response semantically.

All private artifacts are forced under `.local/`, which is gitignored. The validated smoke-test adapter replays one exact capture and cannot renew expired authorization. See the harness specification before using the live probe.

For normal local development, `npm run dev:read -- --operation identity` is the primary entry point. It creates signing state on first use and performs one automatic refresh and retry when rules become stale. The explicit capture/extract/prepare/probe commands remain available for diagnostics.

The browser-safe `browser-signing` package export accepts one build-packaged signing rule and provides typed signing without CDP, filesystem dependencies, or page-runtime/module discovery. The signer emits that rule beneath `.local/` in the same byte representation the consuming package writes, and can publish it as a private release asset. The consuming extension retrieves a digest-pinned asset during its build, bundles that one rule, and owns account pairing, normalization, durable scheduling, and ingestion; those application concerns remain outside this package.

## Status

Source and installed-package tests cover the simulator, signing lifecycle, bounded
responses, diagnostics, declarations and consumer-shaped Chrome proxy. A release
claim must refer to its exact-input report. Transport and MV3 fixtures exercise
different layers, while live consumer history qualification remains a separate,
account-scoped evidence item. That item must verify matching conversation and
message ID/material sets, durable cursor reconstruction, empty/terminal,
exact-boundary and overlap controls, and the same package/source/consumer hashes.
The signer contract remains a bounded page provider; it does not become a
history database or traversal scheduler.
