/** Node/simulator entry point; production browser users import ./browser-signing. */
export class ConnectorError extends Error { constructor(message: string, options?: ErrorOptions) }
export class IntentValidationError extends ConnectorError {}
export class SessionError extends ConnectorError {}
export class AuthorizationError extends ConnectorError {}
export class UpstreamResponseError extends ConnectorError {}
export interface AuthorizationConfig { revision: string; issuedAt: string }
export interface SimulatedAuthorizationConfig extends AuthorizationConfig { secret: string }
export function validateBaseConfig<T extends AuthorizationConfig>(config: T): Readonly<T>;
export function validateSimulatedAuthorizationConfig<T extends SimulatedAuthorizationConfig>(config: T): Readonly<T>;
export class InMemoryAuthorizationRegistry<T extends AuthorizationConfig = AuthorizationConfig> {
  constructor(initialConfig: T, options?: { validate?: (config: T) => T });
  current(): T;
  rotate(nextConfig: T): T;
}
export class CachedAuthorizationConfigProvider<T extends AuthorizationConfig = AuthorizationConfig> {
  constructor(fetchCurrent: () => T | PromiseLike<T>, options?: { validate?: (config: T) => T });
  get(): Promise<T>;
  refresh(): Promise<T>;
  cachedRevision(): string | null;
}
export interface LocalSession { sessionId: string; creatorAccountId: string }
export class StaticSessionProvider {
  constructor(session: LocalSession);
  current(): Promise<Readonly<LocalSession>>;
}
export function canonicalQuery(searchParams: URLSearchParams): string;
export function canonicalRequest(input: {
  method: string; url: string | URL; issuedAt: string | number; sessionId: string; revision: string;
}): string;
export function signPreparedRequest(input: {
  method: string; url: string | URL; sessionId: string;
  config: Pick<SimulatedAuthorizationConfig, 'revision' | 'secret'>; now?: () => number;
}): Record<string, string>;
export function verifyPreparedRequest(input: {
  method: string; url: string | URL; headers: Pick<Headers, 'get'>;
  config: Pick<SimulatedAuthorizationConfig, 'revision' | 'secret'>; maximumAgeMs: number; now?: () => number;
}): { ok: true; sessionId: string } | {
  ok: false; code: 'authorization_missing' | 'authorization_revision_stale' | 'authorization_expired' | 'authorization_invalid';
};
export const HEADER_NAMES: Readonly<{
  revision: 'x-local-auth-revision'; issuedAt: 'x-local-auth-time';
  sessionId: 'x-local-auth-session'; signature: 'x-local-auth-signature';
}>;
export interface AuthorizationAdapter<C, S> {
  prepare(input: { method: string; url: URL; session: S; config: C; now: () => number }):
    { headers: Record<string, string> } | PromiseLike<{ headers: Record<string, string> }>;
}
export class SimulatedHmacAuthorizationAdapter implements AuthorizationAdapter<SimulatedAuthorizationConfig, LocalSession> {
  validateConfig<T extends SimulatedAuthorizationConfig>(config: T): Readonly<T>;
  prepare(input: {
    method: string; url: URL; session: LocalSession; config: SimulatedAuthorizationConfig; now: () => number;
  }): Promise<{ headers: Record<string, string> }>;
}
export interface ReadIntent {
  method?: 'GET'; path: string;
  query?: Record<string, string | number | boolean | readonly (string | number | boolean)[] | null | undefined>;
  body?: null;
}
export class AuthenticatedReadExecutor<C = AuthorizationConfig, S = LocalSession> {
  constructor(options: {
    origin: string;
    sessionProvider: { current(): S | PromiseLike<S> };
    configProvider: { get(): C | PromiseLike<C>; refresh(): C | PromiseLike<C> };
    authorizationAdapter: AuthorizationAdapter<C, S>;
    transport?: typeof fetch;
    now?: () => number;
  });
  /** The simulator API does not validate a canonical response entity. */
  execute(intent: ReadIntent): Promise<unknown>;
}
export interface SimulatedPage { items: unknown[]; terminal?: boolean; nextCursor?: string | null }
export class SimulatedPlatform {
  constructor(options: {
    authorizationRegistry: { current(): SimulatedAuthorizationConfig };
    sessions: Record<string, string>;
    pagesByAccount: Record<string, Record<string, Record<string, SimulatedPage>>>;
    now?: () => number;
  });
  start(): Promise<string>;
  close(): Promise<void>;
}
