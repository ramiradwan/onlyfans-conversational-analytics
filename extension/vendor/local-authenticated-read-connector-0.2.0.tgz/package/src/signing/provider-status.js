import { generationMatchesPackagedRule } from './packaged-rule.js';
import { CURRENT_PROOF_POLICY_VERSION, hasCurrentGenerationProof } from './proof-policy.js';
import { normalizeIdentifier } from './response.js';

function generationMetadata(generation) {
  return generation === null ? null : {
    id: generation.id,
    created_at: generation.created_at,
    proof_outcome: generation.proof_outcome,
    proof_policy_version: generation.proof_policy_version ?? null,
    requires_validation: !hasCurrentGenerationProof(generation),
  };
}

// A single store snapshot prevents mixing metadata from different generations.
// This is not a new proof or a live account/session check.
export function signingStatus(state, hostStatus, registry, expectedIdentity) {
  const tabAvailable = typeof hostStatus?.tab_available === 'boolean'
    ? hostStatus.tab_available
    : typeof hostStatus?.ready === 'boolean' ? hostStatus.ready : null;
  const generation = state.active;
  const supportedRule = generation === null ? null : generationMatchesPackagedRule(generation, registry);
  const currentProof = generation === null ? null : hasCurrentGenerationProof(generation);
  const identity = normalizeIdentifier(generation?.context?.session?.userId);
  const identityMatches = generation === null || expectedIdentity === null
    ? null : identity !== null && identity === expectedIdentity;
  const unavailable = tabAvailable === false || generation === null || supportedRule === false
    || currentProof === false || identityMatches === false;
  return {
    schema: 'browser-signing-status/v1',
    state_revision: state.state_revision,
    active: generationMetadata(generation),
    previous: generationMetadata(state.previous),
    browser: {
      // A matching tab never proves authentication. Legacy hosts' ready fields
      // are interpreted only as availability, never as a successful identity read.
      ready: tabAvailable === false ? false : null,
      tab_id: Number.isSafeInteger(hostStatus?.tab_id) && hostStatus.tab_id >= 0
        ? hostStatus.tab_id : null,
      tab_available: tabAvailable,
      authenticated: null,
    },
    readiness: {
      tab_available: tabAvailable,
      active_generation_available: generation !== null,
      supported_rule: supportedRule,
      current_proof: currentProof,
      current_proof_policy_version: CURRENT_PROOF_POLICY_VERSION,
      expected_identity_matches: identityMatches,
      authenticated: null,
      ready: unavailable ? false : null,
    },
  };
}
