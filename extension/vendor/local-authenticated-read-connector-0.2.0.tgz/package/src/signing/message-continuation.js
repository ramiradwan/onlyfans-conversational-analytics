import { MAX_IDENTIFIER_LENGTH } from './validation-limits.js';

const PREFIX = 'msg1.';
const CONVERSATION_ID = /^[A-Za-z0-9_-]{1,128}$/;
const MESSAGE_ID = new RegExp(`^[1-9]\\d{0,${MAX_IDENTIFIER_LENGTH - 1}}$`);

// The opaque public cursor binds the native older-history anchor to its chat.
export function isMessageContinuation(value) {
  return typeof value === 'string' && value.startsWith(PREFIX);
}

export function encodeMessageContinuation(conversationId, messageId) {
  if (typeof conversationId !== 'string' || !CONVERSATION_ID.test(conversationId)
    || typeof messageId !== 'string' || !MESSAGE_ID.test(messageId)) {
    throw new TypeError('Native message continuation requires bounded conversation and message identifiers.');
  }
  return `${PREFIX}${conversationId}.${messageId}`;
}

export function decodeMessageContinuation(value, conversationId) {
  if (!isMessageContinuation(value) || value.length > 512) {
    throw new TypeError('Native message continuation is invalid.');
  }
  const parts = value.split('.');
  if (parts.length !== 3 || parts[1] !== conversationId
    || encodeMessageContinuation(parts[1], parts[2]) !== value) {
    throw new TypeError('Native message continuation does not match its conversation.');
  }
  return parts[2];
}
