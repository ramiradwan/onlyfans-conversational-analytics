/** An error response is not evidence that signing state should be refreshed. */
export function requiresSigningRefresh(summary, responseRevision, expectedRevision) {
  return summary?.semantic_success === true && responseRevision !== expectedRevision;
}
