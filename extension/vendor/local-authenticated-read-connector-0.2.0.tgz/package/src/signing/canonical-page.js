import { utf8ByteLength } from './validation-limits.js';

// Internal: accepts only the newly projected canonical page, whose records hold
// primitive values. Count the exact UTF-8 JSON representation, including escaping,
// keys, brackets and commas, without serializing an entire oversized page at once.
// Each item is already subject to field limits; stop on the first budget overflow.
export function canonicalPageByteLength(page, limit = Number.MAX_SAFE_INTEGER) {
  let bytes = utf8ByteLength(JSON.stringify({
    items: [], continuation: page.continuation, boundary: page.boundary,
  }), limit);
  for (let index = 0; index < page.items.length && bytes <= limit; index += 1) {
    if (index > 0) bytes += 1;
    bytes += utf8ByteLength(JSON.stringify(page.items[index]), Math.max(0, limit - bytes));
  }
  return bytes;
}
