// Internal operation machinery; callers retain acquisition/deadline ownership.
export const DEFAULT_TRANSPORT_TIMEOUT_MS = 30_000;
export const MAX_TIMEOUT_MS = 2_147_483_647;

export function validateTimeout(value, name = 'transportTimeoutMs') {
  if (!Number.isSafeInteger(value) || value < 1 || value > MAX_TIMEOUT_MS) {
    throw new TypeError(`${name} must be a finite integer from 1 to ${MAX_TIMEOUT_MS}.`);
  }
  return value;
}

export function abortError(signal) {
  // AbortSignal reasons may be any JavaScript value, including null and false.
  if (signal?.reason !== undefined) return signal.reason;
  return new DOMException('Browser signing operation was aborted.', 'AbortError');
}

export function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError(signal);
}

export function transportTimeoutError() {
  const error = new Error('Browser signing transport exceeded its time limit.');
  error.name = 'TimeoutError';
  error.code = 'transport_timeout';
  return error;
}

// Observe the input even when already aborted: a late rejection is never orphaned.
export function awaitWithAbort(value, signal, onAbort = null) {
  const pending = Promise.resolve(value);
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (callback, result) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener('abort', aborted);
      callback(result);
    };
    const aborted = () => {
      if (settled) return;
      // Cleanup cannot replace the caller's reason or create a rejected promise.
      try { Promise.resolve(onAbort?.()).catch(() => undefined); } catch {}
      finish(reject, abortError(signal));
    };
    pending.then(
      (result) => signal?.aborted ? aborted() : finish(resolve, result),
      (error) => signal?.aborted ? aborted() : finish(reject, error),
    );
    if (signal?.aborted) aborted();
    else signal?.addEventListener('abort', aborted, { once: true });
  });
}

// Lazy invocation closes the pre-abort / synchronous side-effect gap.
export function runAbortable(signal, task) {
  return awaitWithAbort(Promise.resolve().then(() => {
    throwIfAborted(signal);
    return task();
  }), signal);
}

export function createTransportOperation(signal, timeoutMs = DEFAULT_TRANSPORT_TIMEOUT_MS) {
  validateTimeout(timeoutMs);
  const controller = new AbortController();
  const forward = () => controller.abort(abortError(signal));
  const expiresAt = Date.now() + timeoutMs;
  let timer;
  if (signal?.aborted) forward();
  else {
    signal?.addEventListener('abort', forward, { once: true });
    timer = setTimeout(() => controller.abort(transportTimeoutError()), timeoutMs);
  }
  return {
    signal: controller.signal,
    expiresAt,
    check() {
      if (!controller.signal.aborted && Date.now() >= expiresAt) controller.abort(transportTimeoutError());
      throwIfAborted(controller.signal);
    },
    dispose() {
      clearTimeout(timer);
      signal?.removeEventListener('abort', forward);
    },
  };
}

export async function withTransport(signal, timeoutMs, task) {
  const operation = createTransportOperation(signal, timeoutMs);
  try {
    const result = await runAbortable(operation.signal, () => task(operation.signal));
    operation.check();
    return result;
  } catch (error) {
    operation.check();
    throw error;
  } finally {
    operation.dispose();
  }
}
