import { MAX_CHECKSUM_INDEX_COUNT, MAX_SIGNATURE_PART_LENGTH } from './validation-limits.js';

// Both packaged rules and renewable configs use this exact metadata contract.
// Bounds guarantee every intermediate checksum sum is a safe integer for any
// lowercase SHA-1 digest (the largest possible character code is "f" = 102).
export function copySigningFormat(format) {
  const keys = new Set(['prefix', 'suffix', 'checksum_indexes', 'checksum_constant']);
  if (!format || typeof format !== 'object' || Array.isArray(format)
    || ![Object.prototype, null].includes(Object.getPrototypeOf(format))
    || Reflect.ownKeys(format).some((key) => !keys.has(key)
      || !Object.hasOwn(Object.getOwnPropertyDescriptor(format, key), 'value'))) {
    throw new TypeError('Signing format must be a plain data record.');
  }
  for (const part of [format.prefix, format.suffix]) {
    if (typeof part !== 'string' || part.length === 0 || part.length > MAX_SIGNATURE_PART_LENGTH
      || /[^\x21-\x7e]|:/.test(part)) {
      throw new TypeError('Signing format prefix or suffix is invalid.');
    }
  }
  const indexes = format.checksum_indexes;
  if (!Array.isArray(indexes) || indexes.length === 0 || indexes.length > MAX_CHECKSUM_INDEX_COUNT
    || Reflect.ownKeys(indexes).length !== indexes.length + 1) {
    throw new TypeError('Signing checksum indexes must be a bounded dense array.');
  }
  const copiedIndexes = [];
  for (let position = 0; position < indexes.length; position += 1) {
    const entry = Object.getOwnPropertyDescriptor(indexes, String(position));
    if (!entry || !Object.hasOwn(entry, 'value') || !Number.isSafeInteger(entry.value)
      || entry.value < 0 || entry.value >= 40) {
      throw new TypeError('Signing checksum indexes must address a SHA-1 hexadecimal digest.');
    }
    copiedIndexes.push(entry.value);
  }
  const constant = format.checksum_constant;
  if (!Number.isSafeInteger(constant)
    || constant > Number.MAX_SAFE_INTEGER - 102 * copiedIndexes.length) {
    throw new TypeError('Signing checksum arithmetic exceeds safe-integer bounds.');
  }
  return Object.freeze({
    prefix: format.prefix,
    suffix: format.suffix,
    checksum_indexes: Object.freeze(copiedIndexes),
    checksum_constant: constant,
  });
}
