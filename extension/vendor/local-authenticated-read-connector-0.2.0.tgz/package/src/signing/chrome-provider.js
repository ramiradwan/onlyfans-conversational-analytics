import { observeSigningOperation, validateDiagnosticCallback } from './diagnostics.js';
import { runAbortable, throwIfAborted, validateTimeout, DEFAULT_TRANSPORT_TIMEOUT_MS } from './async-operation.js';
import { ChromeMainWorldSigningHost } from './chrome-host.js';
import {
  createChromeSigningGenerationStore,
  restrictSigningStorageToTrustedContexts,
} from './chrome-storage.js';
import { BrowserSigningProvider } from './provider.js';

export async function createChromeBrowserSigningProvider(options = {}) {
  const callback = validateDiagnosticCallback(options.onDiagnostic);
  return observeSigningOperation(callback, { event: 'initialize', signal: options.signal },
    () => createChromeProvider(options));
}

async function createChromeProvider({
  chromeApi = globalThis.chrome,
  packagedRule,
  storageKey,
  now,
  idFactory,
  sha1Hex,
  captureTimeoutMs,
  tabId,
  expectedIdentity = null,
  persistence = null,
  onDiagnostic = null,
  signal = null,
  transportTimeoutMs = DEFAULT_TRANSPORT_TIMEOUT_MS,
} = {}) {
  throwIfAborted(signal);
  validateTimeout(transportTimeoutMs);
  if (persistence === null) {
    await runAbortable(signal, () => restrictSigningStorageToTrustedContexts(chromeApi));
  }
  const store = createChromeSigningGenerationStore({
    chromeApi,
    key: storageKey,
    now,
    idFactory,
    ...(persistence === null ? {} : { persistence }),
  });
  await runAbortable(signal, () => store.initialize());
  throwIfAborted(signal);
  const host = new ChromeMainWorldSigningHost({
    chromeApi,
    captureTimeoutMs,
    transportTimeoutMs,
    tabId,
    ...(idFactory ? { idFactory } : {}),
  });
  return new BrowserSigningProvider({
    store,
    host,
    packagedRule,
    ...(now ? { now } : {}),
    ...(sha1Hex ? { sha1Hex } : {}),
    expectedIdentity,
    transportTimeoutMs,
    onDiagnostic,
  });
}
