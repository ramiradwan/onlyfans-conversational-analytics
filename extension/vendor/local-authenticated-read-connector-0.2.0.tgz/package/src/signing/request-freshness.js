// Local safety policy copied from the simulator, not an upstream acceptance claim.
// Future timestamps retain the existing symmetric absolute-age treatment.
export const MAXIMUM_SIGNED_REQUEST_AGE_MS = 30_000;

export function isSignedRequestTimestamp(timestamp) {
  return typeof timestamp === 'string' && /^[1-9]\d{0,15}$/.test(timestamp)
    && Number.isSafeInteger(Number(timestamp));
}

export function isFreshSignedRequestTimestamp(timestamp, pageClock = Date.now()) {
  return isSignedRequestTimestamp(timestamp) && Number.isSafeInteger(pageClock)
    && Math.abs(pageClock - Number(timestamp)) <= MAXIMUM_SIGNED_REQUEST_AGE_MS;
}
