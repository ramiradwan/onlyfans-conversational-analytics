// Only fixed vocabulary crosses the diagnostic boundary. Never inspect an error's
// message, stack, cause, response body, headers, generation, or account context.
export const SIGNING_FAILURE_CODES = Object.freeze([
  'aborted',
  'account_mismatch',
  'activation_proof_failed',
  'activation_revision_mismatch',
  'authorization_failed',
  'browser_unavailable',
  'context_lost',
  'generation_id_conflict',
  'invalid_request',
  'invalid_response',
  'lifecycle_conflict',
  'network_failed',
  'no_previous',
  'packaged_rule_mismatch',
  'proof_policy_required',
  'rate_limited',
  'redirect_rejected',
  'refresh_required',
  'refresh_unsafe',
  'response_too_large',
  'rollback_proof_failed',
  'rollback_revision_stale',
  'signing_failed',
  'state_revision_exhausted',
  'storage_corrupt',
  'storage_load_failed',
  'storage_save_failed',
  'storage_schema_unsupported',
  'transport_timeout',
  'unsupported_revision',
  'upstream_rejected',
  'upstream_unavailable'
]);
export const SIGNING_VALIDATION_CODES = Object.freeze([
  'boundary_continuation_conflict',
  'canonical_page_too_large',
  'conflicting_conversation_display_name',
  'conflicting_conversation_identifier',
  'conflicting_conversation_updated_at',
  'conflicting_conversation_user_identifier',
  'conflicting_last_message_timestamp',
  'conflicting_message_chat_identifier',
  'conflicting_message_direction',
  'conflicting_message_direction_flag',
  'conflicting_message_identifier',
  'conflicting_message_sender_identifier',
  'conflicting_message_sent_at',
  'conflicting_message_text',
  'conflicting_page_continuation',
  'conflicting_page_items',
  'conflicting_requested_message_chat_identifier',
  'invalid_boundary',
  'invalid_continuation',
  'invalid_conversation',
  'invalid_conversation_display_name',
  'invalid_conversation_identifier',
  'invalid_conversation_updated_at',
  'invalid_conversation_user',
  'invalid_conversation_user_identifier',
  'invalid_identity',
  'invalid_last_message',
  'invalid_last_message_timestamp',
  'invalid_message',
  'invalid_message_chat',
  'invalid_message_chat_identifier',
  'invalid_message_direction',
  'invalid_message_direction_flag',
  'invalid_message_identifier',
  'invalid_message_sender',
  'invalid_message_sender_identifier',
  'invalid_message_sent_at',
  'invalid_message_text',
  'invalid_page_has_more',
  'invalid_response_metadata',
  'missing_continuation_or_boundary',
  'missing_conversation_user_identifier',
  'missing_items',
  'missing_message_identifier',
  'missing_message_sender_identifier',
  'missing_message_sent_at',
  'missing_message_text',
  'missing_page_continuation',
  'response_body_read_failed',
  'response_body_unavailable',
  'response_too_large',
  'too_many_items',
  'unsupported_response_field'
]);
const FAILURE_CODES = new Set(SIGNING_FAILURE_CODES);
const VALIDATION_CODES = new Set(SIGNING_VALIDATION_CODES);
const OPERATIONS = new Set(['identity', 'conversations', 'message-page']);
const EVENTS = new Set(['read', 'refresh', 'rollback', 'status', 'initialize']);
const MEDIA_TYPES = new Set([
  'application/json', 'application/problem+json', 'application/octet-stream',
  'text/html', 'text/plain',
]);

function property(value, key) {
  try { return value?.[key]; } catch { return undefined; }
}

export function safeValidationCode(value) {
  return VALIDATION_CODES.has(value) ? value : null;
}

export function safeStatus(value) {
  return Number.isInteger(value) && (value === 0 || (value >= 100 && value <= 599))
    ? value : null;
}

export function safeRetryAfter(status, value) {
  return status === 429 && Number.isSafeInteger(value) && value >= 0
    ? Math.min(3_600_000, value) : null;
}

export function safeContentType(value) {
  if (typeof value !== 'string' || value.length > 512 || /[\r\n\0]/.test(value)) return '';
  const type = value.split(';', 1)[0].trim().toLowerCase();
  if (MEDIA_TYPES.has(type)) return type;
  // Vendor names can contain arbitrary private markers. Report only the JSON
  // family, not the original media type or parameters.
  return /^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+\+json$/.test(type)
    ? 'application/json' : '';
}

export function publicSigningError(error) {
  const code = property(error, 'code');
  const validation = safeValidationCode(code);
  const name = property(error, 'name');
  const failure = FAILURE_CODES.has(code) ? code
    : validation !== null ? 'invalid_response'
      : name === 'AbortError' ? 'aborted'
        : name === 'TimeoutError' ? 'transport_timeout'
          : name === 'IntentValidationError' ? 'invalid_request'
            : 'signing_failed';
  return Object.freeze({ failure_code: failure, validation_error: validation });
}

export function validateDiagnosticCallback(callback) {
  if (callback !== null && callback !== undefined && typeof callback !== 'function') {
    throw new TypeError('onDiagnostic must be a function when supplied.');
  }
  return callback ?? null;
}

function notify(callback, input) {
  if (typeof callback !== 'function') return;
  const status = safeStatus(input.status);
  const diagnostic = Object.freeze({
    schema: 'browser-signing-diagnostic/v1',
    event: EVENTS.has(input.event) ? input.event : 'read',
    operation: OPERATIONS.has(input.operation) ? input.operation : null,
    outcome: input.outcome,
    failure_code: FAILURE_CODES.has(input.failure_code) ? input.failure_code : null,
    validation_error: safeValidationCode(input.validation_error),
    status,
    retry_after_ms: safeRetryAfter(status, input.retry_after_ms),
  });
  // Do not await callbacks or let throws/rejected promises replace an operation's
  // result or cancellation reason. Promise assimilation observes rejected thenables.
  try { Promise.resolve(callback(diagnostic)).catch(() => undefined); } catch {}
}

export async function observeSigningOperation(callback, { event, operation = null, signal = null }, task) {
  try {
    const result = await task();
    const failed = event === 'read' && result.success === false;
    notify(callback, {
      event, operation, outcome: failed ? 'failure' : 'success',
      failure_code: failed ? result.response.failure_code : null,
      validation_error: failed ? result.response.validation_error : null,
      status: event === 'read' ? result.response.status : null,
      retry_after_ms: event === 'read' ? result.response.retry_after_ms : null,
    });
    return result;
  } catch (error) {
    const diagnostic = publicSigningError(error);
    const aborted = signal?.aborted === true || diagnostic.failure_code === 'aborted';
    notify(callback, {
      event, operation, outcome: aborted ? 'aborted' : 'failure',
      failure_code: aborted ? 'aborted' : diagnostic.failure_code,
      validation_error: aborted ? null : diagnostic.validation_error,
    });
    throw error;
  }
}
