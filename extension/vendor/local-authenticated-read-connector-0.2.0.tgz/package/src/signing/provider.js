import { observeSigningOperation, validateDiagnosticCallback } from './diagnostics.js';
import { signingStatus } from './provider-status.js';
import {
  abortError, awaitWithAbort, runAbortable, throwIfAborted,
  DEFAULT_TRANSPORT_TIMEOUT_MS, validateTimeout, withTransport,
} from './async-operation.js';
import { transitionPrecondition } from './generation-store.js';
import { requiresSigningRefresh } from './read-policy.js';
import {
  canRunNegativeControl,
  CURRENT_PROOF_POLICY_VERSION,
  hasCurrentGenerationProof,
} from './proof-policy.js';
import { buildOperationRequest, snapshotOperationParameters } from './operations.js';
import {
  createGenerationFromPackagedRule,
  createPackagedSigningRuleRegistry,
  generationMatchesPackagedRule,
} from './packaged-rule.js';
import {
  createPortableRenewableAdapter,
  webCryptoSha1Hex,
} from './renewable-signing.js';
import {
  classifyDifferentialProof,
  normalizeIdentifier,
  parseTypedResponse,
  publicResponseSummary,
} from './response.js';

// Retained for public compatibility; these statuses alone do not authorize refresh.
const AUTHORIZATION_STATUSES = new Set([401, 403]);

export class BrowserSigningError extends Error {
  constructor(code, message, options = {}) {
    super(message, options);
    this.name = 'BrowserSigningError';
    this.code = code;
  }
}

function corrupt(value) {
  if (typeof value !== 'string' || value.length === 0) {
    throw new TypeError('Invalid comparison requires a non-empty header value.');
  }
  const replacement = value[0] === '0' ? '1' : '0';
  return `${replacement}${value.slice(1)}`;
}

export async function prepareGenerationRequest({
  generation,
  operation,
  parameters = {},
  sha1Hex = webCryptoSha1Hex,
  now = Date.now,
  signal = null,
}) {
  throwIfAborted(signal);
  const request = buildOperationRequest(operation, parameters);
  const adapter = createPortableRenewableAdapter({
    config: generation.config,
    sha1Hex,
  });
  const prepared = await runAbortable(signal, () => adapter.prepare({
    method: request.method,
    url: request.url,
    session: generation.context.session,
    now,
  }));
  throwIfAborted(signal);
  return {
    operation,
    method: request.method,
    url: request.url.toString(),
    headers: prepared.headers,
    controlHeaders: prepared.controlHeaders,
  };
}

export class BrowserSigningProvider {
  constructor({
    store,
    host,
    packagedRule,
    sha1Hex = webCryptoSha1Hex,
    now = Date.now,
    expectedIdentity = null,
    transportTimeoutMs = DEFAULT_TRANSPORT_TIMEOUT_MS,
    onDiagnostic = null,
  }) {
    if (!store?.active || !store?.activate || !store?.rollback || !store?.readState) {
      throw new TypeError('Browser signing provider requires a generation store.');
    }
    if (!host?.captureIdentity || !host?.executeTypedRead) {
      throw new TypeError('Browser signing provider requires a browser host adapter.');
    }
    this.onDiagnostic = validateDiagnosticCallback(onDiagnostic);
    this.transportTimeoutMs = validateTimeout(transportTimeoutMs);
    this.store = store;
    this.host = host;
    this.packagedRuleRegistry = createPackagedSigningRuleRegistry([packagedRule]);
    this.sha1Hex = sha1Hex;
    this.now = now;
    if (expectedIdentity !== null && normalizeIdentifier(expectedIdentity) === null) {
      throw new TypeError('Browser signing provider expected identity is invalid.');
    }
    this.expectedIdentity = expectedIdentity === null ? null : normalizeIdentifier(expectedIdentity);
    this.refreshOperation = null;
    this.lifecycleChain = Promise.resolve();
  }

  async read(options) {
    return observeSigningOperation(this.onDiagnostic, {
      event: 'read', operation: options?.operation, signal: options?.signal,
    }, () => this.#read(options));
  }

  async #read({ operation, parameters = {}, refreshMode = 'allow', signal = null }) {
    throwIfAborted(signal);
    if (!['allow', 'never'].includes(refreshMode)) {
      throw new TypeError('Browser signing read refreshMode must be allow or never.');
    }
    parameters = snapshotOperationParameters(operation, parameters);
    let generation = await runAbortable(signal, () => this.store.active());
    let refreshed = false;
    let refreshReason = null;
    let operationHost = null;
    const generationReason = generation === null
      ? 'missing-active-generation'
      : !generationMatchesPackagedRule(generation, this.packagedRuleRegistry)
        ? 'active-generation-not-packaged'
        : hasCurrentGenerationProof(generation)
          ? null
          : 'active-generation-proof-obsolete';
    if (generationReason !== null) {
      if (refreshMode === 'never') this.#refreshRequired(generationReason);
      const refresh = await this.#refresh({ reason: generationReason, signal });
      generation = refresh.result.generation;
      operationHost = refresh.host;
      refreshed = true;
      refreshReason = generationReason;
    }
    this.#assertGeneration(generation);

    operationHost ??= await this.#openHost(false, signal);
    let attempt = await this.#attempt(generation, operation, parameters, signal, operationHost);
    // Error responses do not establish signing drift. In particular, missing
    // revision metadata on a rate limit, outage, or unclassified 401/403 is not
    // authorization-refresh evidence. Scheduling/retry policy stays with callers.
    const revisionMismatch = requiresSigningRefresh(
      attempt.summary, attempt.responseRevision, generation.config.source_revision,
    );

    // Bootstrap and obsolete-proof validation share the one-refresh budget.
    if (revisionMismatch && !refreshed) {
      refreshReason = 'response-revision-mismatch';
      if (refreshMode === 'never') this.#refreshRequired(refreshReason);
      const refresh = await this.#refresh({ reason: refreshReason, signal }, operationHost);
      generation = refresh.result.generation;
      this.#assertGeneration(generation);
      refreshed = true;
      attempt = await this.#attempt(generation, operation, parameters, signal, operationHost);
    }
    if (
      attempt.summary.semantic_success &&
      attempt.responseRevision !== generation.config.source_revision
    ) {
      this.#unsupportedRevision(attempt.responseRevision);
    }

    throwIfAborted(signal);

    return {
      schema: 'browser-signing-read/v1',
      operation,
      generation_id: generation.id,
      refreshed,
      refresh_reason: refreshReason,
      success: attempt.summary.semantic_success,
      response: publicResponseSummary({
        ...attempt.summary,
        retry_after_ms: attempt.retryAfterMs,
      }),
      data: attempt.data,
    };
  }

  async refresh(options = {}) {
    return observeSigningOperation(this.onDiagnostic, {
      event: 'refresh', signal: options?.signal,
    }, async () => (await this.#refresh(options)).result);
  }

  // Unbound callers may share capture/proof and adopt that operation's host.
  // A recovery already bound to a document must not join an unrelated refresh.
  async #refresh({ reason = 'manual', signal = null } = {}, operationHost = null) {
    throwIfAborted(signal);
    const scoped = operationHost !== null && operationHost !== this.host;
    if (this.refreshOperation?.controller.signal.aborted) this.refreshOperation = null;
    let operation = scoped ? null : this.refreshOperation;
    const reused = operation !== null;
    if (!reused) {
      operation = {
        controller: new AbortController(),
        waiters: 0,
        promise: null,
        host: operationHost,
      };
      operation.promise = this.#runLifecycle(
        async () => {
          // Select only when this lifecycle starts, not while it waits in queue.
          operation.host ??= await this.#openHost(true, operation.controller.signal);
          return this.#performRefresh(reason, operation.controller.signal, operation.host);
        },
        operation.controller.signal,
      ).finally(() => {
        if (this.refreshOperation === operation) this.refreshOperation = null;
      });
      if (!scoped) this.refreshOperation = operation;
    }

    operation.waiters += 1;
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      operation.waiters -= 1;
      if (signal?.aborted && operation.waiters === 0) {
        // Retire synchronously, including private document-bound recoveries.
        if (this.refreshOperation === operation) this.refreshOperation = null;
        operation.controller.abort(abortError(signal));
      }
    };
    try {
      const generation = await awaitWithAbort(operation.promise, signal, release);
      return {
        result: { generation, refreshed: !reused, reused, reason },
        host: operation.host,
      };
    } finally {
      release();
    }
  }

  // Existing injected hosts remain valid. Browser hosts implementing this hook
  // return an operation-local adapter, never a persisted account/generation epoch.
  async #openHost(reload, signal) {
    if (typeof this.host.openOperation !== 'function') return this.host;
    let host;
    try {
      host = await this.#transport(signal, (transportSignal) => (
        this.host.openOperation({ reload, signal: transportSignal })
      ));
    } catch (cause) {
      throwIfAborted(signal);
      if (cause?.name === 'AbortError' || ['transport_timeout', 'context_lost', 'refresh_unsafe'].includes(cause?.code)) throw cause;
      throw new BrowserSigningError(
        'browser_unavailable',
        'Open an authenticated OnlyFans tab and retry the operation.',
        { cause },
      );
    }
    if (!host?.captureIdentity || !host?.executeTypedRead || !host?.assertContext) {
      throw new TypeError('Browser operation host is invalid.');
    }
    return host;
  }

  async #assertContext(host, signal) {
    if (typeof host.assertContext === 'function') {
      await this.#transport(signal, (transportSignal) => host.assertContext({ signal: transportSignal }));
    }
    throwIfAborted(signal);
  }

  async rollback(options = {}) {
    return observeSigningOperation(this.onDiagnostic, {
      event: 'rollback', signal: options?.signal,
    }, () => this.#rollback(options));
  }

  async #rollback({ signal = null } = {}) {
    throwIfAborted(signal);
    return awaitWithAbort(this.#runLifecycle(() => this.#performRollback(signal), signal), signal);
  }

  // Only lifecycle operations share this queue. Reads use detached, validated
  // generation snapshots and do not wait for capture or proof network requests.
  #runLifecycle(operation, signal) {
    const pending = this.lifecycleChain.then(() => {
      throwIfAborted(signal);
      return runAbortable(signal, operation);
    });
    this.lifecycleChain = pending.then(() => undefined, () => undefined);
    return pending;
  }

  async #performRollback(signal) {
    throwIfAborted(signal);
    const state = await runAbortable(signal, () => this.store.readState());
    const expected = transitionPrecondition(state);
    const previous = state.previous;
    if (previous === null) {
      throw new BrowserSigningError('no_previous', 'No previous signing generation is available.');
    }
    this.#assertGeneration(previous);
    const operationHost = await this.#openHost(false, signal);
    const validation = await this.#prove(previous, signal, operationHost);
    if (
      validation.candidateSucceeded &&
      validation.responseRevision !== previous.config.source_revision
    ) {
      throw new BrowserSigningError(
        'rollback_revision_stale',
        'The previous signing generation does not match the current upstream revision.',
      );
    }
    if (validation.proof.outcome !== 'strong') {
      throw new BrowserSigningError(
        'rollback_proof_failed',
        'The previous signing generation failed strong proof and was not activated.',
      );
    }
    throwIfAborted(signal);
    await this.#assertContext(operationHost, signal);
    const generation = await this.store.rollback({ expected, proof: validation.proof, signal });
    await this.#assertContext(operationHost, signal);
    return { generation, proof: validation.proof };
  }

  async status() {
    return observeSigningOperation(this.onDiagnostic, { event: 'status' }, async () => {
      const state = await this.store.readState();
      const browser = this.host.status ? await this.host.status() : null;
      return signingStatus(state, browser, this.packagedRuleRegistry, this.expectedIdentity);
    });
  }

  async #performRefresh(reason, signal, operationHost) {
    throwIfAborted(signal);
    const expected = transitionPrecondition(await runAbortable(signal, () => this.store.readState()));
    throwIfAborted(signal);
    let capture;
    try {
      capture = await this.#transport(signal, (transportSignal) => (
        operationHost.captureIdentity({ reload: true, signal: transportSignal })
      ));
    } catch (cause) {
      if (signal?.aborted) throw abortError(signal);
      if (cause?.name === 'AbortError' || ['transport_timeout', 'context_lost', 'refresh_unsafe'].includes(cause?.code)) throw cause;
      throw new BrowserSigningError(
        'browser_unavailable',
        'Open an authenticated OnlyFans tab and retry the operation.',
        { cause },
      );
    }

    const requestRevision = capture?.headers?.['x-of-rev'];
    if (
      typeof requestRevision !== 'string' ||
      typeof capture.responseRevision !== 'string' ||
      capture.responseRevision !== requestRevision
    ) {
      throw new BrowserSigningError(
        'activation_revision_mismatch',
        'The captured response revision does not match the captured signing headers.',
      );
    }
    const rule = this.packagedRuleRegistry.get(requestRevision);
    if (rule === null) this.#unsupportedRevision(requestRevision);

    let derived;
    try {
      derived = await runAbortable(signal, () => createGenerationFromPackagedRule({
        rule,
        capture,
        sha1Hex: this.sha1Hex,
        expectedIdentity: this.expectedIdentity,
      }));
    } catch (cause) {
      if (signal?.aborted) throw abortError(signal);
      if (cause?.name === 'AbortError' || ['transport_timeout', 'context_lost', 'refresh_unsafe'].includes(cause?.code)) throw cause;
      throw new BrowserSigningError(
        'packaged_rule_mismatch',
        'The packaged signing rule did not reproduce the observed identity request.',
        { cause },
      );
    }
    this.#assertGeneration(derived);

    const transient = { config: derived.config, context: derived.context };
    const validation = await this.#prove(transient, signal, operationHost);
    if (
      validation.candidateSucceeded &&
      validation.responseRevision !== derived.config.source_revision
    ) {
      throw new BrowserSigningError(
        'activation_revision_mismatch',
        'The packaged signing revision changed before activation completed.',
      );
    }

    if (validation.proof.outcome !== 'strong') {
      throw new BrowserSigningError(
        'activation_proof_failed',
        'New signing rules failed strong differential proof and were not activated.',
      );
    }
    throwIfAborted(signal);
    await this.#assertContext(operationHost, signal);
    const generation = await this.store.activate({
      signal,
      expected,
      config: derived.config,
      context: derived.context,
      reason,
      proof: validation.proof,
      summary: { packaged_rule: derived.summary },
    });
    await this.#assertContext(operationHost, signal);
    return generation;
  }

  async #prove(generation, signal, operationHost) {
    throwIfAborted(signal);
    const request = await prepareGenerationRequest({
      generation,
      operation: 'identity',
      sha1Hex: this.sha1Hex,
      now: this.now,
      signal,
    });
    const candidate = await this.#transport(signal, (transportSignal) => (
      operationHost.executeTypedRead(request, { signal: transportSignal })
    ));
    const candidateResult = parseTypedResponse({
      operation: 'identity',
      status: candidate.status,
      contentType: candidate.contentType,
      body: candidate.body,
      bodyError: candidate.bodyError,
    });
    this.#assertIdentityResult(generation, candidateResult.data);
    const controlHeader = request.controlHeaders[0] ?? null;
    const context = {
      expectedRevision: generation.config.source_revision,
      candidateRevision: candidate.responseRevision ?? null,
      negativeRevision: null,
      controlHeader,
      timestamp: request.headers.time,
      now: this.now(),
    };
    let negative = null;
    if (canRunNegativeControl(candidateResult.summary, context)) {
      throwIfAborted(signal);
      negative = await this.#transport(signal, (transportSignal) => operationHost.executeTypedRead({
        ...request,
        headers: {
          ...request.headers,
          [controlHeader]: corrupt(request.headers[controlHeader]),
        },
      }, { signal: transportSignal }));
    }
    const negativeResult = negative === null ? null : parseTypedResponse({
      operation: 'identity',
      status: negative.status,
      contentType: negative.contentType,
      body: negative.body,
      bodyError: negative.bodyError,
    });
    if (negativeResult !== null) this.#assertIdentityResult(generation, negativeResult.data);
    return {
      proof: {
        ...classifyDifferentialProof(candidateResult.summary, negativeResult?.summary ?? null, {
          ...context,
          negativeRevision: negative?.responseRevision ?? null,
          now: this.now(),
        }),
        policy_version: CURRENT_PROOF_POLICY_VERSION,
      },
      responseRevision: candidate.responseRevision ?? null,
      candidateSucceeded: candidateResult.summary.semantic_success,
    };
  }

  #transport(signal, task) {
    return withTransport(signal, this.transportTimeoutMs, task);
  }

  async #attempt(generation, operation, parameters, signal, operationHost) {
    throwIfAborted(signal);
    const request = await prepareGenerationRequest({
      generation,
      operation,
      parameters,
      sha1Hex: this.sha1Hex,
      now: this.now,
      signal,
    });
    const response = await this.#transport(signal, (transportSignal) => (
      operationHost.executeTypedRead(request, { signal: transportSignal })
    ));
    throwIfAborted(signal);
    const parsed = parseTypedResponse({
      operation,
      parameters,
      status: response.status,
      contentType: response.contentType,
      body: response.body,
      bodyError: response.bodyError,
    });
    if (operation === 'identity') this.#assertIdentityResult(generation, parsed.data);
    return {
      responseRevision: response.responseRevision ?? null,
      retryAfterMs: response.retryAfterMs ?? null,
      summary: parsed.summary,
      data: parsed.data,
    };
  }

  #assertIdentityResult(generation, data) {
    if (data !== null && data.id !== this.#assertGenerationIdentity(generation)) {
      throw new BrowserSigningError(
        'account_mismatch',
        'The authenticated browser identity does not match the signing generation.',
      );
    }
  }

  #assertGeneration(generation) {
    if (!generationMatchesPackagedRule(generation, this.packagedRuleRegistry)) {
      this.#unsupportedRevision(generation?.config?.source_revision ?? null);
    }
    return this.#assertGenerationIdentity(generation);
  }

  #assertGenerationIdentity(generation) {
    const identity = normalizeIdentifier(generation?.context?.session?.userId);
    if (identity === null || (this.expectedIdentity !== null && identity !== this.expectedIdentity)) {
      throw new BrowserSigningError(
        'account_mismatch',
        'The signing generation does not match the expected creator account.',
      );
    }
    return identity;
  }

  #unsupportedRevision(revision) {
    throw new BrowserSigningError(
      'unsupported_revision',
      'The observed signing revision is not supported by the packaged rule.',
    );
  }

  #refreshRequired(reason) {
    throw new BrowserSigningError(
      'refresh_required',
      `Signing state requires refresh (${reason}), but refresh is disabled for this read.`,
    );
  }
}

export { AUTHORIZATION_STATUSES };
