// Internal finite safety policy. Measurements and units: docs/specs/transport-validation.md.
// Mirrored constants inside the closure-free executor are checked by conformance tests.
export const MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
export const MAX_CANONICAL_PAGE_BYTES = 2 * 1024 * 1024;
export const MAX_MESSAGE_TEXT_BYTES = 350_000;
export const MAX_DISPLAY_NAME_LENGTH = 512; // UTF-16 code units (existing contract).
export const MAX_IDENTIFIER_LENGTH = 256; // ASCII characters.
export const MAX_CONVERSATION_ID_LENGTH = 128;
export const MAX_CAPTURED_HEADER_COUNT = 7;
export const MAX_HEADER_NAME_BYTES = 64;
export const MAX_HEADER_VALUE_BYTES = 4096;
export const MAX_CAPTURED_HEADER_BYTES = 16 * 1024; // Sum of retained name + value bytes.
export const MAX_REVISION_LENGTH = 128;
export const MAX_STATIC_PARAM_LENGTH = 4096;
export const MAX_SIGNATURE_PART_LENGTH = 128;
export const MAX_CHECKSUM_INDEX_COUNT = 256;

// Does not allocate an encoded copy of a potentially large string. Matches TextEncoder,
// including replacement of unpaired UTF-16 surrogates. Stops as soon as the limit is crossed.
export function utf8ByteLength(value, limit = Number.MAX_SAFE_INTEGER) {
  if (typeof value !== 'string') throw new TypeError('A string is required.');
  let bytes = 0;
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code < 0x80) bytes += 1;
    else if (code < 0x800) bytes += 2;
    else if (code >= 0xd800 && code <= 0xdbff && index + 1 < value.length
      && value.charCodeAt(index + 1) >= 0xdc00 && value.charCodeAt(index + 1) <= 0xdfff) {
      bytes += 4;
      index += 1;
    } else bytes += 3;
    if (bytes > limit) return bytes;
  }
  return bytes;
}
