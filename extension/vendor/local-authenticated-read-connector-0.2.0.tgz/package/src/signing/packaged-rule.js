import { normalizeSigningHeaders } from './header-policy.js';
import { ORIGIN } from './operations.js';
import { copySigningFormat } from './signing-format.js';
import { isSignedRequestTimestamp } from './request-freshness.js';
import {
  MAX_IDENTIFIER_LENGTH,
  MAX_REVISION_LENGTH,
  MAX_STATIC_PARAM_LENGTH,
} from './validation-limits.js';
import {
  createSignatureFromDigest,
  createSigningInput,
  validateRenewableSigningConfig,
  validateSigningSession,
  webCryptoSha1Hex,
} from './renewable-signing.js';

export const PACKAGED_SIGNING_RULE_SCHEMA = 'local-packaged-signing-rule/v1';

const OBSERVED_STATIC_HEADERS = Object.freeze(['accept', 'app-token', 'x-bc', 'x-of-rev']);
const REQUIRED_OBSERVED_HEADERS = Object.freeze(['app-token', 'x-bc', 'x-of-rev']);
const OBSERVED_CAPTURE_HEADERS = new Set([
  ...OBSERVED_STATIC_HEADERS,
  'sign',
  'time',
  'user-id',
]);
const IDENTITY_PATH = '/api2/v2/users/me';

function hasOnlyKeys(value, keys) {
  return Object.keys(value).every((key) => keys.has(key));
}

export function validatePackagedSigningRule(rule) {
  if (
    !rule ||
    typeof rule !== 'object' ||
    Array.isArray(rule) ||
    !hasOnlyKeys(
      rule,
      new Set(['schema', 'source_revision', 'static_param', 'format']),
    ) ||
    rule.schema !== PACKAGED_SIGNING_RULE_SCHEMA ||
    typeof rule.source_revision !== 'string' ||
    rule.source_revision.length === 0 ||
    rule.source_revision.length > MAX_REVISION_LENGTH ||
    /[^\x21-\x7e]/.test(rule.source_revision) ||
    typeof rule.static_param !== 'string' ||
    rule.static_param.length === 0 ||
    rule.static_param.length > MAX_STATIC_PARAM_LENGTH ||
    /[\x00-\x1f\x7f]/.test(rule.static_param)
  ) {
    throw new TypeError('Packaged signing rule is invalid.');
  }
  return Object.freeze({
    schema: PACKAGED_SIGNING_RULE_SCHEMA,
    source_revision: rule.source_revision,
    static_param: rule.static_param,
    format: copySigningFormat(rule.format),
  });
}

function createPackagedSigningRuleRegistry(rules) {
  if (!Array.isArray(rules) || rules.length === 0) {
    throw new TypeError('At least one packaged signing rule is required.');
  }
  const byRevision = new Map();
  for (const input of rules) {
    const rule = validatePackagedSigningRule(input);
    if (byRevision.has(rule.source_revision)) {
      throw new TypeError(`Duplicate packaged signing revision: ${rule.source_revision}.`);
    }
    byRevision.set(rule.source_revision, rule);
  }
  return Object.freeze({
    revisions: Object.freeze([...byRevision.keys()]),
    get(revision) {
      return typeof revision === 'string' ? byRevision.get(revision) ?? null : null;
    },
  });
}

const BOOTSTRAP_SIGNING_IDENTITY = '0';

function normalizeAbsentHeaderExpectedIdentity(value) {
  if (Number.isSafeInteger(value) && value > 0) {
    const stringValue = String(value);
    if (stringValue.length <= MAX_IDENTIFIER_LENGTH) return stringValue;
  }
  if (
    typeof value === 'string'
    && value.length >= 1
    && value.length <= MAX_IDENTIFIER_LENGTH
    && /^[1-9]\d*$/.test(value)
  ) {
    return value;
  }
  return null;
}

function identityCapture(capture) {
  if (!capture || capture.method !== 'GET' || typeof capture.url !== 'string') {
    throw new TypeError('Packaged signing activation requires an observed identity GET.');
  }
  const url = new URL(capture.url);
  if (url.origin !== ORIGIN || url.username || url.password || url.href.includes('#')
    || /[\x00-\x20\x7f]/.test(capture.url) || url.pathname !== IDENTITY_PATH || url.search !== '') {
    throw new TypeError('Packaged signing activation requires the exact identity endpoint.');
  }
  if (!capture.headers || typeof capture.headers !== 'object' || Array.isArray(capture.headers)) {
    throw new TypeError('Observed identity headers are invalid.');
  }
  const headers = normalizeSigningHeaders(capture.headers);
  for (const name of [...REQUIRED_OBSERVED_HEADERS, 'sign', 'time']) {
    if (typeof headers[name] !== 'string' || headers[name].length === 0) {
      throw new TypeError(`Observed identity request is missing ${name}.`);
    }
  }
  if (!isSignedRequestTimestamp(headers.time)) {
    throw new TypeError('Observed identity timestamp is invalid.');
  }
  const hasUserId = Object.hasOwn(headers, 'user-id');
  if (hasUserId) {
    validateSigningSession({ userId: headers['user-id'] });
  }
  if (typeof capture.responseRevision !== 'string' || capture.responseRevision.length === 0) {
    throw new TypeError('Observed identity response is missing x-of-rev.');
  }
  if (capture.responseRevision !== headers['x-of-rev']) {
    throw new TypeError('Observed request and response revisions do not match.');
  }
  return { headers, path: `${url.pathname}${url.search}`, hasUserId };
}

export async function createGenerationFromPackagedRule({
  rule: inputRule,
  capture,
  sha1Hex = webCryptoSha1Hex,
  expectedIdentity = null,
}) {
  if (typeof sha1Hex !== 'function') throw new TypeError('A SHA-1 digest provider is required.');
  const rule = validatePackagedSigningRule(inputRule);
  const observed = identityCapture(capture);
  if (observed.headers['x-of-rev'] !== rule.source_revision) {
    throw new TypeError('Observed identity revision is not supported by the packaged rule.');
  }

  let sessionUserId;
  if (observed.hasUserId) {
    sessionUserId = observed.headers['user-id'];
  } else {
    if (expectedIdentity === null || expectedIdentity === undefined) {
      throw new TypeError('Packaged signing activation requires a bounded positive decimal expectedIdentity when observed identity request lacks user-id.');
    }
    const validatedExpectedIdentity = normalizeAbsentHeaderExpectedIdentity(expectedIdentity);
    if (validatedExpectedIdentity === null) {
      throw new TypeError('Packaged signing activation requires a bounded positive decimal expectedIdentity when observed identity request lacks user-id.');
    }
    validateSigningSession({ userId: validatedExpectedIdentity });
    sessionUserId = validatedExpectedIdentity;
  }

  const staticHeaders = {};
  for (const name of OBSERVED_STATIC_HEADERS) {
    const value = observed.headers[name];
    if (typeof value === 'string' && value.length > 0) staticHeaders[name] = value;
  }
  const config = {
    schema: 'local-renewable-signing-config/v1',
    source_revision: rule.source_revision,
    static_param: rule.static_param,
    format: {
      prefix: rule.format.prefix,
      suffix: rule.format.suffix,
      checksum_indexes: [...rule.format.checksum_indexes],
      checksum_constant: rule.format.checksum_constant,
    },
    headers: staticHeaders,
  };
  const validatedConfig = validateRenewableSigningConfig(config);
  const input = observed.hasUserId
    ? createSigningInput({
      config: validatedConfig,
      path: observed.path,
      timestamp: observed.headers.time,
      userId: observed.headers['user-id'],
    })
    : [
      validatedConfig.staticParam,
      observed.headers.time,
      observed.path,
      BOOTSTRAP_SIGNING_IDENTITY,
    ].join('\n');
  const digest = await sha1Hex(input);
  const expectedSignature = createSignatureFromDigest({ config: validatedConfig, digest });
  if (expectedSignature !== observed.headers.sign) {
    throw new TypeError('Packaged signing rule does not reproduce the observed identity signature.');
  }

  return {
    config,
    context: { session: { userId: sessionUserId } },
    summary: {
      source: 'packaged-rule',
      source_revision: rule.source_revision,
      reproduced_observed_signature: true,
    },
  };
}

export function generationMatchesPackagedRule(generation, registry) {
  const config = generation?.config;
  const rule = registry?.get?.(config?.source_revision);
  if (rule === null || rule === undefined) return false;
  try {
    const validated = validateRenewableSigningConfig(config);
    return (
      validated.sourceRevision === rule.source_revision &&
      validated.staticParam === rule.static_param &&
      validated.format.prefix === rule.format.prefix &&
      validated.format.suffix === rule.format.suffix &&
      validated.format.checksumConstant === rule.format.checksum_constant &&
      validated.format.checksumIndexes.length === rule.format.checksum_indexes.length &&
      validated.format.checksumIndexes.every(
        (value, index) => value === rule.format.checksum_indexes[index],
      )
    );
  } catch {
    return false;
  }
}

export {
  createPackagedSigningRuleRegistry,
  IDENTITY_PATH,
  OBSERVED_STATIC_HEADERS,
  REQUIRED_OBSERVED_HEADERS,
};
