import { executeTypedReadInPage } from './typed-read-executor.js';
export { executeTypedReadInPage } from './typed-read-executor.js';
import { normalizeSigningHeaders } from './header-policy.js';
import {
  abortError, awaitWithAbort, createTransportOperation,
  throwIfAborted, validateTimeout, withTransport, DEFAULT_TRANSPORT_TIMEOUT_MS,
} from './async-operation.js';

const ONLYFANS_ORIGIN = 'https://onlyfans.com';
const CAPTURE_HEADERS = new Set([
  'accept',
  'app-token',
  'sign',
  'time',
  'user-id',
  'x-bc',
  'x-of-rev',
]);

function callChrome(chromeApi, receiver, method, args) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      const error = chromeApi?.runtime?.lastError;
      if (error) reject(new Error(error.message));
      else resolve(value);
    };
    const fail = (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    };
    try {
      const returned = method.call(receiver, ...args, finish);
      if (returned?.then) returned.then(finish, fail);
    } catch (error) {
      fail(error);
    }
  });
}

function headersToObject(headers, allowedNames = null) {
  if (allowedNames === CAPTURE_HEADERS) return normalizeSigningHeaders(headers ?? [], { capture: true });
  const selected = {};
  for (const header of headers ?? []) {
    const name = typeof header?.name === 'string' ? header.name.toLowerCase() : '';
    if (!['x-of-rev', 'content-type'].includes(name)) continue;
    if (Object.hasOwn(selected, name) || typeof header.value !== 'string'
      || header.value.length === 0 || header.value.length > 4096
      || /[^\x20-\x7e]/.test(header.value) || header.value.trim() !== header.value) {
      throw new TypeError('Observed response headers are invalid or oversized.');
    }
    selected[name] = header.value;
  }
  return selected;
}

function isIdentityRequest(details, tabId) {
  if (details.tabId !== tabId || details.method !== 'GET') return false;
  try {
    const url = new URL(details.url);
    return (
      url.origin === ONLYFANS_ORIGIN &&
      url.pathname === '/api2/v2/users/me' &&
      url.search === ''
    );
  } catch {
    return false;
  }
}

// This function is intentionally closure-free for MAIN-world execution.
export function abortTypedReadInPage(requestId, expiresAt = null) {
  if (typeof requestId !== 'string' || !/^[A-Za-z0-9._~-]{1,128}$/.test(requestId)) return false;
  const key = '__LOCAL_AUTHENTICATED_READ_ABORTS_V1__';
  let registry = globalThis[key];
  const controller = registry instanceof Map ? registry.get(requestId) : null;
  if (controller instanceof AbortController) {
    if (!controller.signal.aborted) {
      controller.abort();
      controller.retire?.();
      registry.delete(requestId);
    }
    return true;
  }
  // Cancellation may reach MAIN before the original injection. Reserve its ID
  // until that injection consumes the cancellation or the absolute ceiling wins.
  // Never retain an unbounded tombstone or re-arm one on duplicate cancellation.
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= Date.now()) return false;
  if (!(registry instanceof Map)) globalThis[key] = registry = new Map();
  const canceled = new AbortController();
  canceled.abort();
  let timer;
  canceled.retire = () => {
    clearTimeout(timer);
    if (registry.get(requestId) === canceled) registry.delete(requestId);
  };
  registry.set(requestId, canceled);
  timer = setTimeout(canceled.retire, Math.min(2_147_483_647, expiresAt - Date.now()));
  return true;
}

// This function is intentionally closure-free for MAIN-world execution.
export function inspectSafeRefreshInPage() {
  const draftControls = [
    ...document.querySelectorAll('textarea, [contenteditable="true"]'),
  ];
  const hasDraft = draftControls.some((control) => {
    if (typeof control.value === 'string') return control.value.trim().length > 0;
    return (control.textContent ?? '').trim().length > 0;
  });
  if (document.visibilityState !== 'hidden') {
    return { safe: false, reason: 'tab_visible' };
  }
  if (hasDraft) return { safe: false, reason: 'composer_draft_present' };
  return { safe: true, reason: null };
}

// This probe runs in the extension's ISOLATED world. Document identity itself
// comes from Chrome's InjectionResult metadata, never a page-supplied identifier.
export function inspectSigningDocumentInPage() {
  return globalThis.location?.origin === 'https://onlyfans.com'
    && globalThis.window !== undefined && globalThis.window === globalThis.window.top;
}

function contextLostError() {
  const error = new Error('The browser signing document is no longer available.');
  error.name = 'BrowserSigningContextError';
  error.code = 'context_lost';
  return error;
}

function documentResult(results, expected = null) {
  if (!Array.isArray(results) || results.length !== 1) throw contextLostError();
  const result = results[0];
  if (result?.frameId !== 0 || typeof result.documentId !== 'string'
    || result.documentId.length === 0 || result.documentId.length > 128
    || (expected !== null && result.documentId !== expected)) throw contextLostError();
  return result;
}

export class ChromeMainWorldSigningHost {
  constructor({
    chromeApi = globalThis.chrome,
    captureTimeoutMs = 20_000,
    transportTimeoutMs = DEFAULT_TRANSPORT_TIMEOUT_MS,
    tabId = null,
    idFactory = () => crypto.randomUUID(),
  } = {}) {
    if (!chromeApi?.tabs || !chromeApi?.scripting || !chromeApi?.webRequest) {
      throw new TypeError('Chrome tabs, scripting, and webRequest APIs are required.');
    }
    this.chrome = chromeApi;
    this.captureTimeoutMs = validateTimeout(captureTimeoutMs, 'captureTimeoutMs');
    this.transportTimeoutMs = validateTimeout(transportTimeoutMs);
    this.tabId = tabId;
    this.idFactory = idFactory;
  }

  async status() {
    try {
      const tab = await this.#onlyFansTab();
      return { ready: null, tab_id: tab.id, tab_available: true, authenticated: null };
    } catch {
      return { ready: false, tab_id: null, tab_available: false, authenticated: null };
    }
  }

  // One logical operation owns this adapter. Its only permitted document change
  // is the deliberate reload in captureIdentity; no tab fallback occurs later.
  async openOperation({ reload = false, signal = null } = {}) {
    return withTransport(signal, this.transportTimeoutMs, async (transportSignal) => {
      const context = await this.#resolveContext(reload, transportSignal);
      return Object.freeze({
        captureIdentity: ({ reload = true, signal = null } = {}) => (
          withTransport(signal, this.transportTimeoutMs, (innerSignal) => (
            this.#captureIdentity(context, reload, innerSignal)
          ))
        ),
        executeTypedRead: (request, { signal = null } = {}) => this.#runExecution(context, request, signal),
        assertContext: ({ signal = null } = {}) => (
          withTransport(signal, this.transportTimeoutMs, (innerSignal) => this.#assertContext(context, innerSignal))
        ),
      });
    });
  }

  async #resolveContext(reload, signal) {
    const tab = await this.#onlyFansTab(signal, reload);
    return { ...await this.#document(tab.id, signal), lost: false };
  }

  async #document(tabId, signal) {
    let results;
    try {
      results = await awaitWithAbort(callChrome(
        this.chrome, this.chrome.scripting, this.chrome.scripting.executeScript,
        [{ target: { tabId, frameIds: [0] }, world: 'ISOLATED', func: inspectSigningDocumentInPage }],
      ), signal);
    } catch (error) {
      throwIfAborted(signal);
      throw contextLostError();
    }
    const result = documentResult(results);
    if (result.result !== true) throw contextLostError();
    return { tabId, documentId: result.documentId };
  }

  async #assertContext(context, signal) {
    throwIfAborted(signal);
    if (context.lost) throw contextLostError();
    const current = await this.#document(context.tabId, signal);
    if (current.documentId !== context.documentId) {
      context.lost = true;
      throw contextLostError();
    }
  }

  async captureIdentity({ reload = true, signal = null } = {}) {
    return withTransport(signal, this.transportTimeoutMs, async (transportSignal) => {
      const context = await this.#resolveContext(reload, transportSignal);
      return this.#captureIdentity(context, reload, transportSignal);
    });
  }

  async #captureIdentity(context, reload, signal) {
    throwIfAborted(signal);
    await this.#assertContext(context, signal);
    if (reload) await this.#assertSafeRefresh(context, signal);
    const capture = this.#observeIdentity(context, signal, reload);
    let reloadStarted = false;
    if (reload && !capture.settled) {
      // Capture can time out while a safety query is pending. Retire that query's
      // continuation when observation ends; otherwise a late Chrome reply could
      // start another injection after the capture has already been abandoned.
      const recheck = new AbortController();
      const forwardAbort = () => recheck.abort(abortError(signal));
      signal?.addEventListener('abort', forwardAbort, { once: true });
      if (signal?.aborted) forwardAbort();
      const stopRecheck = () => {
        signal?.removeEventListener('abort', forwardAbort);
        recheck.abort();
      };
      void capture.promise.then(stopRecheck, stopRecheck);
      // Recheck after listener registration, immediately before reload. Chrome
      // has no document-targeted/conditional reload, so this is not atomic.
      // Observe a late reload rejection without retaining an abort listener on
      // its acknowledgement (which Chrome/proxies may never settle).
      void Promise.resolve().then(async () => {
        await this.#assertSafeRefresh(context, recheck.signal);
        throwIfAborted(signal);
        if (capture.settled) return;
        capture.arm();
        reloadStarted = true;
        return callChrome(
          this.chrome, this.chrome.tabs, this.chrome.tabs.reload,
          [context.tabId, { bypassCache: true }],
        );
      }).catch((error) => capture.cancel(error));
    }
    try {
      const observed = await awaitWithAbort(capture.promise, signal, () => capture.cancel(abortError(signal)));
      const current = await this.#document(context.tabId, signal);
      if (current.documentId !== observed.documentId) throw contextLostError();
      // Adopt only the top-level document that supplied the completed capture.
      context.documentId = observed.documentId;
      return observed.capture;
    } catch (error) {
      if (reloadStarted || error?.code === 'context_lost') context.lost = true;
      throw error;
    }
  }

  async executeTypedRead(request, { signal = null } = {}) {
    return this.#runExecution(null, request, signal);
  }

  async #runExecution(context, request, signal) {
    const operation = createTransportOperation(signal, this.transportTimeoutMs);
    try {
      context ??= await this.#resolveContext(false, operation.signal);
      const result = await this.#executeTypedRead(context, request, operation.signal, operation.expiresAt);
      operation.check();
      return result;
    } catch (error) {
      operation.check();
      throw error;
    } finally {
      operation.dispose();
    }
  }

  async #executeTypedRead(context, request, signal, expiresAt) {
    await this.#assertContext(context, signal);
    const requestId = this.idFactory();
    throwIfAborted(signal);
    const target = { tabId: context.tabId, documentIds: [context.documentId] };
    const execution = callChrome(
      this.chrome, this.chrome.scripting, this.chrome.scripting.executeScript,
      [{
        target,
        world: 'MAIN',
        func: executeTypedReadInPage,
        args: [{
          operation: request.operation,
          method: request.method,
          url: request.url,
          headers: request.headers,
          request_id: requestId,
          expires_at: expiresAt,
        }],
      }],
    );
    const cancelInPage = () => {
      // Cancellation must never target the new document after navigation.
      void callChrome(
        this.chrome, this.chrome.scripting, this.chrome.scripting.executeScript,
        [{ target, world: 'MAIN', func: abortTypedReadInPage, args: [requestId, expiresAt] }],
      ).catch(() => undefined);
    };
    let results;
    try {
      results = await awaitWithAbort(execution, signal, cancelInPage);
    } catch (error) {
      throwIfAborted(signal);
      // A lost target is context loss, not a reason to select another tab.
      // Preserve execution errors (e.g. signature expiry) when context survives.
      await this.#assertContext(context, signal);
      throw error;
    }
    const value = documentResult(results, context.documentId).result;
    await this.#assertContext(context, signal);
    if (!value || !Number.isInteger(value.status) || typeof value.contentType !== 'string') {
      throw new Error('Chrome MAIN-world typed read returned an invalid result.');
    }
    return value;
  }

  async #queryTabs(signal) {
    return awaitWithAbort(callChrome(this.chrome, this.chrome.tabs, this.chrome.tabs.query, [{
      url: ['https://onlyfans.com/*'],
    }]), signal);
  }

  async #onlyFansTab(signal = null, reload = false) {
    const tabs = await this.#queryTabs(signal);
    const candidates = (tabs ?? []).filter((tab) => Number.isInteger(tab.id));
    const tab = this.tabId !== null
      ? candidates.find((tab) => tab.id === this.tabId)
      : reload ? candidates.find((tab) => tab.active !== true)
        : candidates.find((tab) => tab.active === true) ?? candidates[0];
    if (!tab && this.tabId !== null) throw contextLostError();
    if (reload && candidates.length > 0 && (!tab || tab.active === true)) {
      const error = new Error('Safe signing refresh requires an inactive OnlyFans tab.');
      error.code = 'refresh_unsafe';
      throw error;
    }
    if (!tab) throw new Error('No authenticated OnlyFans tab is open.');
    return tab;
  }

  async #assertSafeRefresh(context, signal) {
    await this.#assertContext(context, signal);
    const tabs = await this.#queryTabs(signal);
    const tab = (tabs ?? []).find((tab) => tab.id === context.tabId);
    if (!tab) throw contextLostError();
    if (tab.active === true) {
      const error = new Error('Safe signing refresh requires an inactive OnlyFans tab.');
      error.code = 'refresh_unsafe';
      throw error;
    }
    let results;
    try {
      results = await awaitWithAbort(callChrome(
        this.chrome, this.chrome.scripting, this.chrome.scripting.executeScript,
        [{ target: { tabId: context.tabId, documentIds: [context.documentId] },
          world: 'MAIN', func: inspectSafeRefreshInPage }],
      ), signal);
    } catch (error) {
      throwIfAborted(signal);
      throw contextLostError();
    }
    const safety = documentResult(results, context.documentId).result;
    if (safety?.safe !== true) {
      const reason = ['tab_visible', 'composer_draft_present'].includes(safety?.reason)
        ? safety.reason : 'safety_unproven';
      const error = new Error(`OnlyFans tab refresh is unsafe (${reason}).`);
      error.code = 'refresh_unsafe';
      throw error;
    }
  }

  #observeIdentity(context, signal = null, reload = false) {
    const tabId = context.tabId;
    let armed = !reload;
    let selectedDocumentId = null;
    throwIfAborted(signal);
    const webRequest = this.chrome.webRequest;
    let selectedRequestId = null;
    let request = null;
    let responseRevision = null;
    let responseStatus = null;
    let responseContentType = '';
    let settled = false;
    let timeout;
    let resolvePromise, rejectPromise;
    const registrations = [];
    const cleanup = () => {
      clearTimeout(timeout);
      signal?.removeEventListener('abort', aborted);
      for (const [event, listener] of registrations.splice(0)) {
        try { event.removeListener(listener); } catch {}
      }
    };
    const fail = (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      rejectPromise(error);
    };
    const beforeHeaders = (details) => {
      if (settled || !armed || selectedRequestId !== null || !isIdentityRequest(details, tabId)) return;
      // Ignore child frames; missing top-frame metadata cannot authorize proof.
      if (Number.isInteger(details.frameId) && details.frameId !== 0) return;
      if (details.frameId !== 0 || typeof details.documentId !== 'string'
        || details.documentId.length === 0 || details.documentId.length > 128
        || details.documentLifecycle !== 'active') return fail(contextLostError());
      if (reload && details.documentId === context.documentId) return;
      if (!reload && details.documentId !== context.documentId) return fail(contextLostError());
      selectedDocumentId = details.documentId;
      selectedRequestId = details.requestId;
      try {
        request = {
          method: details.method, url: details.url,
          headers: headersToObject(details.requestHeaders, CAPTURE_HEADERS),
        };
      } catch {
        fail(new TypeError('Observed identity headers are invalid or oversized.'));
      }
    };
    const matchesDocument = (details) => details.tabId === tabId && details.frameId === 0
      && details.documentId === selectedDocumentId && details.documentLifecycle === 'active';
    const receivedHeaders = (details) => {
      if (settled || details.requestId !== selectedRequestId) return;
      if (!matchesDocument(details)) return fail(contextLostError());
      try {
        const headers = headersToObject(details.responseHeaders);
        responseRevision = headers['x-of-rev'] ?? null;
        responseContentType = headers['content-type'] ?? '';
        responseStatus = details.statusCode;
      } catch {
        fail(new TypeError('Observed response headers are invalid or oversized.'));
      }
    };
    const completed = (details) => {
      if (settled || details.requestId !== selectedRequestId || request === null) return;
      if (!matchesDocument(details)) return fail(contextLostError());
      settled = true;
      cleanup();
      resolvePromise({
        documentId: selectedDocumentId,
        capture: {
          method: request.method, url: request.url, headers: request.headers,
          responseRevision,
          response: { status: responseStatus ?? details.statusCode ?? 0, contentType: responseContentType },
        },
      });
    };
    const failed = (details) => {
      if (details.requestId === selectedRequestId) fail(matchesDocument(details)
        ? new Error('The captured identity request failed.') : contextLostError());
    };
    const aborted = () => fail(abortError(signal));
    const promise = new Promise((resolve, reject) => {
      resolvePromise = resolve;
      rejectPromise = reject;
    });
    // Attach before any Chrome callback or registration can fail synchronously.
    void promise.catch(() => undefined);
    try {
      signal?.addEventListener('abort', aborted, { once: true });
      throwIfAborted(signal);
      const filter = { urls: ['https://onlyfans.com/api2/v2/users/me*'], tabId };
      for (const [event, listener, extra] of [
        [webRequest.onBeforeSendHeaders, beforeHeaders, ['requestHeaders', 'extraHeaders']],
        [webRequest.onHeadersReceived, receivedHeaders, ['responseHeaders', 'extraHeaders']],
        [webRequest.onCompleted, completed],
        [webRequest.onErrorOccurred, failed],
      ]) {
        if (settled) break;
        // Include a registration even if the API attaches it and then throws.
        registrations.push([event, listener]);
        event.addListener(listener, filter, ...(extra ? [extra] : []));
      }
      if (!settled) timeout = setTimeout(() => {
        fail(new Error('No completed identity request was observed before timeout.'));
      }, this.captureTimeoutMs);
    } catch (error) {
      fail(error);
    }
    return {
      promise,
      arm: () => { armed = true; },
      get settled() { return settled; },
      cancel: (error = new Error('Identity capture was cancelled.')) => fail(error),
    };
  }
}

export { CAPTURE_HEADERS };
