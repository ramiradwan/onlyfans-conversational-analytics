/** Public browser surface. */
export type MaybePromise<T> = T | PromiseLike<T>;
export type Operation = 'identity' | 'conversations' | 'message-page';
export type RefreshMode = 'allow' | 'never';
export type Identifier = string;
/** Pass a returned continuation unchanged; native message cursors are bound to their conversation. */
export interface PageQuery { limit?: number; cursor?: string | null }
export type IdentityParameters = Record<string, never>;
export interface ConversationParameters { query?: PageQuery }
export interface MessagePageParameters { conversationId: string; query?: PageQuery }
export interface OperationParameters {
  identity: IdentityParameters;
  conversations: ConversationParameters;
  'message-page': MessagePageParameters;
}
export type OperationArguments =
  | { operation: 'identity'; parameters?: IdentityParameters }
  | { operation: 'conversations'; parameters?: ConversationParameters }
  | { operation: 'message-page'; parameters: MessagePageParameters };
export type ReadRequest = OperationArguments & { refreshMode?: RefreshMode; signal?: AbortSignal | null };
export interface CanonicalIdentity { id: Identifier }
export interface CanonicalConversation {
  id: Identifier;
  platform_user_id: Identifier;
  display_name: string | null;
  updated_at: string | null;
}
export interface CanonicalMessage {
  id: Identifier;
  chat_id: Identifier | null;
  sender_platform_user_id: Identifier;
  text: string;
  sent_at: string;
  direction: 'inbound' | 'outbound' | null;
}
/** Exactly these three fields. Continuation values are opaque to callers. */
export type CanonicalPage<T, B extends string> = { items: T[] } & (
  | { continuation: string; boundary: null }
  | { continuation: null; boundary: B }
);
export interface CanonicalData {
  identity: CanonicalIdentity;
  conversations: CanonicalPage<CanonicalConversation, 'inventory_end'>;
  'message-page': CanonicalPage<CanonicalMessage, 'history_start'>;
}
export interface PublicResponseSummary {
  status: number | null;
  /** Normalized, allowlisted media type; empty string when unknown. */
  content_type: string;
  response_class: string;
  retry_after_ms: number | null;
  failure_code: SigningFailureCode | null;
  validation_error: SigningValidationCode | null;
}
export type ReadResult<O extends Operation = Operation> = O extends Operation ? {
  schema: 'browser-signing-read/v1';
  operation: O;
  generation_id: string;
  refreshed: boolean;
  refresh_reason: string | null;
} & (
  | { success: true; data: CanonicalData[O]; response: PublicResponseSummary & { failure_code: null } }
  | { success: false; data: null; response: PublicResponseSummary & { failure_code: SigningFailureCode } }
) : never;
export interface TypedResponseSummary {
  status: number | null;
  content_type: string;
  json: boolean;
  semantic_success: boolean;
  validation_error: SigningValidationCode | null;
  rejection_class: 'observed_bad_request' | null;
  response_class: string;
  retry_after_ms?: number | null;
}
export type TypedResponseInput<O extends Operation = Operation> = {
  operation: O;
  parameters?: OperationParameters[O];
  status: number;
  contentType: string;
  body: unknown;
  /** Any non-null transport-body failure suppresses data; unknown codes are not echoed. */
  bodyError?: string | null;
};
export function parseTypedResponse<O extends Operation>(input: TypedResponseInput<O>): {
  summary: TypedResponseSummary; data: CanonicalData[O] | null;
};
export function summarizeTypedResponse<O extends Operation>(input: TypedResponseInput<O>): TypedResponseSummary;
export function publicResponseSummary(summary: TypedResponseSummary): PublicResponseSummary;
export function normalizeIdentifier(value: unknown): Identifier | null;
export class TypedResponseValidationError extends Error { constructor(code: string); code: string }

export interface SigningFormat {
  prefix: string;
  suffix: string;
  checksum_indexes: readonly number[];
  checksum_constant: number;
}
export interface PackagedSigningRule {
  schema: 'local-packaged-signing-rule/v1';
  source_revision: string;
  static_param: string;
  format: SigningFormat;
}
export interface RenewableSigningConfig {
  schema: 'local-renewable-signing-config/v1';
  source_revision: string;
  static_param: string;
  format: SigningFormat;
  headers: Readonly<Record<string, string>>;
}
export interface ValidatedSigningConfig {
  readonly schema: 'local-renewable-signing-config/v1';
  readonly sourceRevision: string;
  readonly staticParam: string;
  readonly format: {
    readonly prefix: string; readonly suffix: string;
    readonly checksumIndexes: readonly number[]; readonly checksumConstant: number;
  };
  readonly headers: Readonly<Record<string, string>>;
}
export interface SigningSession { userId: string }
export type Sha1Hex = (input: string) => MaybePromise<string>;
export interface PreparedSigningHeaders {
  headers: Record<string, string>;
  controlHeaders: string[];
  /** Existing adapter metadata; not a sanitized logging/diagnostic event. */
  diagnostics: { revision: string; checksumIndexCount: number };
}
export interface PortableRenewableAdapter {
  id: 'runtime-derived-renewable-signing';
  prepare(input: { method: string; url: URL; session: SigningSession; now: () => number }): Promise<PreparedSigningHeaders>;
}
export function validateRenewableSigningConfig(config: unknown): ValidatedSigningConfig;
export function validateSigningSession(session: unknown): string;
export function validateSigningRequest(method: string, url: URL): void;
export function createSigningInput(input: {
  config: ValidatedSigningConfig; path: string; timestamp: string; userId: string;
}): string;
export function createSignatureFromDigest(input: { config: ValidatedSigningConfig; digest: string }): string;
export function createPortableRenewableAdapter(options: { config: RenewableSigningConfig; sha1Hex: Sha1Hex }): PortableRenewableAdapter;
export function webCryptoSha1Hex(input: string, cryptoApi?: Pick<Crypto, 'subtle'>): Promise<string>;
export function validatePackagedSigningRule(rule: unknown): Readonly<PackagedSigningRule>;
export interface PackagedRuleRegistry { get(revision: unknown): Readonly<PackagedSigningRule> | null }
export function generationMatchesPackagedRule(generation: unknown, registry: PackagedRuleRegistry): boolean;
export interface CapturedIdentityRequest {
  method: 'GET'; url: string; headers: Record<string, string>; responseRevision: string;
}
export interface DerivedGeneration {
  config: RenewableSigningConfig;
  context: { session: SigningSession };
  summary: { source: 'packaged-rule'; source_revision: string; reproduced_observed_signature: true };
}
export function createGenerationFromPackagedRule(options: {
  rule: PackagedSigningRule; capture: CapturedIdentityRequest; sha1Hex?: Sha1Hex;
  expectedIdentity?: string | number | null;
}): Promise<DerivedGeneration>;
export interface PreparedGenerationRequest<O extends Operation = Operation> {
  operation: O; method: 'GET'; url: string; headers: Record<string, string>; controlHeaders: string[];
}
export type SignableGeneration = Pick<DerivedGeneration, 'config' | 'context'>;
export function prepareGenerationRequest<R extends OperationArguments>(options: R & {
  generation: SignableGeneration; sha1Hex?: Sha1Hex; now?: () => number; signal?: AbortSignal | null;
}): Promise<PreparedGenerationRequest<R['operation']>>;

export interface DifferentialProof {
  outcome: 'strong' | 'partial' | 'inconclusive' | 'failed'; detail: string;
}
export interface ProofContext {
  expectedRevision: string;
  candidateRevision: string | null;
  negativeRevision: string | null;
  controlHeader: string | null;
  timestamp: string;
  now: number;
}
export function classifyDifferentialProof(
  candidate: TypedResponseSummary, negativeControl?: TypedResponseSummary | null, context?: ProofContext | null,
): DifferentialProof;
export interface CurrentStrongProof { outcome: 'strong'; policy_version: number; detail?: string }
export interface SigningGeneration {
  schema: 'browser-signing-generation/v1';
  id: string; created_at: string; reason: string;
  proof_outcome: 'strong';
  /** Missing on legacy state; never sufficient evidence of current-policy proof. */
  proof_policy_version?: number;
  config: RenewableSigningConfig;
  context: { session: SigningSession };
  summary: Record<string, unknown>;
}
export interface SigningState {
  schema: 'browser-signing-state/v1'; state_revision: number;
  active: SigningGeneration | null; previous: SigningGeneration | null;
}
/** Load must return unknown: persisted bytes are validated by the store. Single writer only. */
export interface SigningPersistence {
  load(): MaybePromise<unknown>;
  save(state: SigningState): MaybePromise<void>;
}
export interface GenerationMetadata {
  id: string; created_at: string; proof_outcome: 'strong';
  proof_policy_version: number | null; requires_validation: boolean;
}
export interface StoreStatus {
  state_revision: number; active: GenerationMetadata | null; previous: GenerationMetadata | null;
}
export interface TransitionPrecondition {
  state_revision: number; active_id: string | null; previous_id: string | null;
}
export interface ActivationOptions extends SignableGeneration {
  reason: string; proof: CurrentStrongProof; summary?: Record<string, unknown>;
  expected?: TransitionPrecondition; signal?: AbortSignal | null;
}
export interface StoreRollbackOptions {
  expected?: TransitionPrecondition; proof?: CurrentStrongProof; signal?: AbortSignal | null;
}
export interface SigningGenerationStore {
  initialize(): Promise<SigningState>;
  snapshot(): SigningState;
  readState(): Promise<SigningState>;
  active(): Promise<SigningGeneration | null>;
  previous(): Promise<SigningGeneration | null>;
  status(): Promise<StoreStatus>;
  activate(options: ActivationOptions): Promise<SigningGeneration>;
  rollback(options?: StoreRollbackOptions): Promise<SigningGeneration>;
}
export interface GenerationStoreOptions { persistence: SigningPersistence; now?: () => number; idFactory?: () => string }
export class AtomicSigningGenerationStore implements SigningGenerationStore {
  constructor(options: GenerationStoreOptions);
  persistence: SigningPersistence; now: () => number; idFactory: () => string;
  initialize(): Promise<SigningState>;
  snapshot(): SigningState;
  readState(): Promise<SigningState>;
  active(): Promise<SigningGeneration | null>;
  previous(): Promise<SigningGeneration | null>;
  status(): Promise<StoreStatus>;
  activate(options: ActivationOptions): Promise<SigningGeneration>;
  rollback(options?: StoreRollbackOptions): Promise<SigningGeneration>;
}
export class MemorySigningPersistence implements SigningPersistence {
  constructor(initialState?: unknown);
  value: unknown;
  load(): Promise<unknown>;
  save(value: SigningState): Promise<void>;
}
export function transitionPrecondition(state: SigningState): TransitionPrecondition;
export class SigningGenerationStoreError extends Error {
  constructor(code: string, message: string, options?: ErrorOptions); code: string;
}
export class BrowserSigningError extends Error {
  constructor(code: string, message: string, options?: ErrorOptions); code: string;
}

export interface BrowserHostStatus {
  /** Deprecated availability-only input from legacy injected hosts, never authentication. */
  ready?: boolean | null;
  tab_id?: number | null;
  tab_available?: boolean | null;
  authenticated?: null;
}
export interface HostReadResponse {
  status: number; contentType: string; body: unknown;
  responseRevision?: string | null; retryAfterMs?: number | null;
  /** A transport-body failure, independent of the observed HTTP status. */
  bodyError?: string | null;
}
export interface SignalOptions { signal?: AbortSignal | null }
export interface CaptureOptions extends SignalOptions { reload?: boolean }
export interface BrowserSigningHost {
  captureIdentity(options?: CaptureOptions): MaybePromise<CapturedIdentityRequest>;
  executeTypedRead(request: PreparedGenerationRequest, options?: SignalOptions): MaybePromise<HostReadResponse>;
  status?(): MaybePromise<BrowserHostStatus>;
  openOperation?(options?: CaptureOptions): MaybePromise<BrowserOperationHost>;
  assertContext?(options?: SignalOptions): MaybePromise<void>;
}
export interface BrowserOperationHost extends BrowserSigningHost {
  assertContext(options?: SignalOptions): MaybePromise<void>;
}
export interface BrowserSigningStatus extends StoreStatus {
  schema: 'browser-signing-status/v1';
  browser: {
    ready: false | null; tab_id: number | null; tab_available: boolean | null; authenticated: null;
  };
  readiness: {
    tab_available: boolean | null;
    active_generation_available: boolean;
    supported_rule: boolean | null;
    current_proof: boolean | null;
    current_proof_policy_version: number;
    expected_identity_matches: boolean | null;
    authenticated: null;
    /** false: a known prerequisite failed; null: authentication has not been checked. */
    ready: false | null;
  };
}
export interface BrowserSigningProviderOptions {
  store: SigningGenerationStore;
  host: BrowserSigningHost;
  packagedRule: PackagedSigningRule;
  sha1Hex?: Sha1Hex; now?: () => number;
  expectedIdentity?: string | number | null;
  transportTimeoutMs?: number;
  onDiagnostic?: DiagnosticCallback | null;
}
export interface RefreshOptions extends SignalOptions { reason?: string }
export interface RefreshResult { generation: SigningGeneration; refreshed: boolean; reused: boolean; reason: string }
export class BrowserSigningProvider {
  constructor(options: BrowserSigningProviderOptions);
  store: SigningGenerationStore;
  host: BrowserSigningHost;
  onDiagnostic: DiagnosticCallback | null;
  expectedIdentity: string | null;
  transportTimeoutMs: number;
  read<R extends ReadRequest>(options: R): Promise<ReadResult<R['operation']>>;
  refresh(options?: RefreshOptions): Promise<RefreshResult>;
  rollback(options?: SignalOptions): Promise<{ generation: SigningGeneration; proof: DifferentialProof & { policy_version: number } }>;
  status(): Promise<BrowserSigningStatus>;
}

/** Structural Chrome API: Promise-only consumer proxies and callback APIs both fit. */
export interface ChromeTab { id?: number; active?: boolean; frozen?: boolean }
export interface ChromeRequestDetails {
  tabId: number; frameId?: number; documentId?: string; documentLifecycle?: string;
  requestId: string; method: string; url: string; statusCode?: number;
  requestHeaders?: Array<{ name: string; value?: string }>;
  responseHeaders?: Array<{ name: string; value?: string }>;
  error?: string;
}
export interface ChromeRequestEvent {
  addListener(callback: (details: ChromeRequestDetails) => void, filter: { urls: string[] }, extraInfoSpec?: string[]): void;
  removeListener(callback: (details: ChromeRequestDetails) => void): void;
}
export interface ChromeInjectionTarget { tabId: number; documentIds?: string[]; frameIds?: number[] }
export interface ChromeInjection<A extends unknown[] = unknown[], R = unknown> {
  target: ChromeInjectionTarget; world: 'MAIN' | 'ISOLATED';
  func: (...args: A) => R; args?: A;
}
export interface ChromeInjectionResult<R = unknown> { frameId?: number; documentId?: string; result?: R }
export interface ChromeStorageArea {
  get(keys: string[], callback?: (items: Record<string, unknown>) => void): void | Promise<Record<string, unknown>>;
  set(items: Record<string, unknown>, callback?: () => void): void | Promise<void>;
  setAccessLevel?(options: { accessLevel: 'TRUSTED_CONTEXTS' }, callback?: () => void): void | Promise<void>;
}
export interface SigningChromeApi {
  runtime?: { lastError?: { message?: string } | null };
  tabs: {
    query(query: { url: string[] }, callback?: (tabs: ChromeTab[]) => void): void | Promise<ChromeTab[]>;
    reload(tabId: number, options: { bypassCache?: boolean }, callback?: () => void): void | Promise<void>;
  };
  scripting: {
    executeScript<A extends unknown[], R>(
      details: ChromeInjection<A, R>, callback?: (results: ChromeInjectionResult<Awaited<R>>[]) => void,
    ): void | Promise<ChromeInjectionResult<Awaited<R>>[]>;
  };
  webRequest: {
    onBeforeSendHeaders: ChromeRequestEvent; onHeadersReceived: ChromeRequestEvent;
    onCompleted: ChromeRequestEvent; onErrorOccurred: ChromeRequestEvent;
  };
  storage?: { local: ChromeStorageArea };
}
export interface ChromeHostOptions {
  chromeApi?: SigningChromeApi;
  captureTimeoutMs?: number; transportTimeoutMs?: number; tabId?: number | null; idFactory?: () => string;
}
export class ChromeMainWorldSigningHost implements BrowserSigningHost {
  constructor(options?: ChromeHostOptions);
  status(): Promise<BrowserHostStatus>;
  openOperation(options?: CaptureOptions): Promise<BrowserOperationHost>;
  captureIdentity(options?: CaptureOptions): Promise<CapturedIdentityRequest>;
  executeTypedRead(request: PreparedGenerationRequest, options?: SignalOptions): Promise<HostReadResponse>;
}
export interface ChromePersistenceOptions {
  chromeApi?: Pick<SigningChromeApi, 'runtime' | 'storage'>; storageArea?: ChromeStorageArea; key?: string;
}
export function createChromeSigningPersistence(options?: ChromePersistenceOptions): SigningPersistence;
export function createChromeSigningGenerationStore(options?: ChromePersistenceOptions & {
  persistence?: SigningPersistence; now?: () => number; idFactory?: () => string;
}): AtomicSigningGenerationStore;
export function restrictSigningStorageToTrustedContexts(chromeApi?: Pick<SigningChromeApi, 'runtime' | 'storage'>): Promise<boolean>;
export interface ChromeProviderOptions extends ChromeHostOptions {
  packagedRule: PackagedSigningRule;
  storageKey?: string; now?: () => number; sha1Hex?: Sha1Hex;
  expectedIdentity?: string | number | null;
  persistence?: SigningPersistence | null; signal?: AbortSignal | null;
  onDiagnostic?: DiagnosticCallback | null;
}
export function createChromeBrowserSigningProvider(options: ChromeProviderOptions): Promise<BrowserSigningProvider>;
export interface PageExecutionInput {
  operation: Operation; method: 'GET'; url: string; headers: Record<string, string>;
  request_id?: string; expires_at?: number;
}
export function executeTypedReadInPage(input: PageExecutionInput): Promise<HostReadResponse>;
export function abortTypedReadInPage(requestId: string, expiresAt?: number | null): boolean;
export function inspectSafeRefreshInPage(): { safe: true; reason: null } | { safe: false; reason: 'tab_visible' | 'composer_draft_present' };
export function inspectSigningDocumentInPage(): boolean;

export interface OperationDefinition<O extends Operation = Operation> {
  pathPattern: RegExp;
  buildPath(parameters: OperationParameters[O]): string;
  expectedJsonKey: string;
  expectedKind: 'present' | 'array';
  boundary: 'inventory_end' | 'history_start' | null;
  validateParameters(parameters: OperationParameters[O]): { conversationId?: string; query?: Record<string, string> };
}
export function getOperation<O extends Operation>(name: O): OperationDefinition<O>;
export function buildOperationRequest(name: 'identity', parameters?: IdentityParameters): { operation: 'identity'; method: 'GET'; url: URL };
export function buildOperationRequest(name: 'conversations', parameters?: ConversationParameters): { operation: 'conversations'; method: 'GET'; url: URL };
export function buildOperationRequest(name: 'message-page', parameters: MessagePageParameters): { operation: 'message-page'; method: 'GET'; url: URL };
export function matchesOperation(name: Operation, rawUrl: string | URL, method?: string): boolean;
export function expectedResponse(name: Operation): { key: string; kind: 'present' | 'array'; boundary: 'inventory_end' | 'history_start' | null };
export function normalizeHeaderName(name: string): string;
export function isForbiddenHeader(name: string): boolean;
export function assertAllowedHeader(name: string, label?: string): string;
export const ORIGIN: 'https://onlyfans.com';
export const MAX_PAGE_LIMIT: 100;
export const MAX_CURSOR_LENGTH: 512;
export const SAFE_CURSOR: RegExp;
export const DEFINITIONS: Readonly<{ [O in Operation]: OperationDefinition<O> }>;
export const AUTHORIZATION_STATUSES: Set<number>;
export const FORBIDDEN_HEADERS: Set<string>;
export const CAPTURE_HEADERS: Set<string>;
export const CHROME_SIGNING_STATE_KEY: 'browser_signing_state_v1';
export const STATE_SCHEMA: 'browser-signing-state/v1';
export const GENERATION_SCHEMA: 'browser-signing-generation/v1';
export const PACKAGED_SIGNING_RULE_SCHEMA: 'local-packaged-signing-rule/v1';
export const RENEWABLE_SIGNING_SCHEMA: 'local-renewable-signing-config/v1';

export interface SigningDiagnostic {
  readonly schema: 'browser-signing-diagnostic/v1';
  readonly event: 'read' | 'refresh' | 'rollback' | 'status' | 'initialize';
  readonly operation: Operation | null;
  readonly outcome: 'success' | 'failure' | 'aborted';
  readonly failure_code: SigningFailureCode | null;
  readonly validation_error: SigningValidationCode | null;
  readonly status: number | null;
  readonly retry_after_ms: number | null;
}
/** Return values are ignored; rejected promises/thenables are observed, never awaited. */
export type DiagnosticCallback = (diagnostic: SigningDiagnostic) => unknown;
export function publicSigningError(error: unknown): Readonly<{
  failure_code: SigningFailureCode; validation_error: SigningValidationCode | null;
}>;

export type SigningFailureCode =
  'aborted'
  | 'account_mismatch'
  | 'activation_proof_failed'
  | 'activation_revision_mismatch'
  | 'authorization_failed'
  | 'browser_unavailable'
  | 'context_lost'
  | 'generation_id_conflict'
  | 'invalid_request'
  | 'invalid_response'
  | 'lifecycle_conflict'
  | 'network_failed'
  | 'no_previous'
  | 'packaged_rule_mismatch'
  | 'proof_policy_required'
  | 'rate_limited'
  | 'redirect_rejected'
  | 'refresh_required'
  | 'refresh_unsafe'
  | 'response_too_large'
  | 'rollback_proof_failed'
  | 'rollback_revision_stale'
  | 'signing_failed'
  | 'state_revision_exhausted'
  | 'storage_corrupt'
  | 'storage_load_failed'
  | 'storage_save_failed'
  | 'storage_schema_unsupported'
  | 'transport_timeout'
  | 'unsupported_revision'
  | 'upstream_rejected'
  | 'upstream_unavailable';

export type SigningValidationCode =
  'boundary_continuation_conflict'
  | 'canonical_page_too_large'
  | 'conflicting_conversation_display_name'
  | 'conflicting_conversation_identifier'
  | 'conflicting_conversation_updated_at'
  | 'conflicting_conversation_user_identifier'
  | 'conflicting_last_message_timestamp'
  | 'conflicting_message_chat_identifier'
  | 'conflicting_message_direction'
  | 'conflicting_message_direction_flag'
  | 'conflicting_message_identifier'
  | 'conflicting_message_sender_identifier'
  | 'conflicting_message_sent_at'
  | 'conflicting_message_text'
  | 'conflicting_page_continuation'
  | 'conflicting_page_items'
  | 'conflicting_requested_message_chat_identifier'
  | 'invalid_boundary'
  | 'invalid_continuation'
  | 'invalid_conversation'
  | 'invalid_conversation_display_name'
  | 'invalid_conversation_identifier'
  | 'invalid_conversation_updated_at'
  | 'invalid_conversation_user'
  | 'invalid_conversation_user_identifier'
  | 'invalid_identity'
  | 'invalid_last_message'
  | 'invalid_last_message_timestamp'
  | 'invalid_message'
  | 'invalid_message_chat'
  | 'invalid_message_chat_identifier'
  | 'invalid_message_direction'
  | 'invalid_message_direction_flag'
  | 'invalid_message_identifier'
  | 'invalid_message_sender'
  | 'invalid_message_sender_identifier'
  | 'invalid_message_sent_at'
  | 'invalid_message_text'
  | 'invalid_page_has_more'
  | 'invalid_response_metadata'
  | 'missing_continuation_or_boundary'
  | 'missing_conversation_user_identifier'
  | 'missing_items'
  | 'missing_message_identifier'
  | 'missing_message_sender_identifier'
  | 'missing_message_sent_at'
  | 'missing_message_text'
  | 'missing_page_continuation'
  | 'response_body_read_failed'
  | 'response_body_unavailable'
  | 'response_too_large'
  | 'too_many_items'
  | 'unsupported_response_field';

export const SIGNING_FAILURE_CODES: readonly SigningFailureCode[];
export const SIGNING_VALIDATION_CODES: readonly SigningValidationCode[];
