import {
  MAX_CAPTURED_HEADER_COUNT, MAX_HEADER_NAME_BYTES, MAX_HEADER_VALUE_BYTES,
  MAX_CAPTURED_HEADER_BYTES,
} from './validation-limits.js';

const FORBIDDEN_HEADERS = new Set([
  'accept-charset',
  'accept-encoding',
  'accept-language',
  'access-control-request-headers',
  'access-control-request-method',
  'authorization',
  'connection',
  'constructor',
  'content-length',
  'cookie',
  'date',
  'dnt',
  'expect',
  'host',
  'keep-alive',
  'origin',
  'permissions-policy',
  'proxy-authorization',
  'prototype',
  'referer',
  'set-cookie',
  'te',
  'trailer',
  'transfer-encoding',
  'upgrade',
  'user-agent',
  'via',
  '__proto__',
]);

const HEADER_NAME = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
const CSRF_HEADER = /(?:^|[-_])(?:csrf|xsrf)(?:$|[-_])/;

export function normalizeHeaderName(name) {
  if (typeof name !== 'string' || !HEADER_NAME.test(name)) {
    throw new TypeError('Header names must be valid HTTP field names.');
  }
  return name.toLowerCase();
}

export function isForbiddenHeader(name) {
  const normalized = normalizeHeaderName(name);
  return (
    FORBIDDEN_HEADERS.has(normalized) ||
    normalized.startsWith('proxy-') ||
    normalized.startsWith('sec-') ||
    CSRF_HEADER.test(normalized)
  );
}

export function assertAllowedHeader(name, label = 'Header') {
  const normalized = normalizeHeaderName(name);
  if (isForbiddenHeader(normalized)) {
    throw new TypeError(`${label} is browser-managed or credential-bearing.`);
  }
  return normalized;
}

export { FORBIDDEN_HEADERS };

export const SIGNING_HEADER_NAMES = Object.freeze([
  'accept', 'app-token', 'sign', 'time', 'user-id', 'x-bc', 'x-of-rev',
]);
export const STATIC_HEADER_NAMES = Object.freeze(['accept', 'app-token', 'x-bc', 'x-of-rev']);

// Capture accepts unmerged Chrome entries and discards browser-owned headers.
export function normalizeSigningHeaders(input, { capture = false, staticOnly = false } = {}) {
  let entries;
  if (capture && Array.isArray(input)) {
    entries = input.map((entry) => [entry?.name, entry?.value]);
  } else {
    if (!input || typeof input !== 'object' || Array.isArray(input)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(input))
      || Reflect.ownKeys(input).some((key) => typeof key !== 'string'
        || !Object.hasOwn(Object.getOwnPropertyDescriptor(input, key), 'value'))) {
      throw new TypeError('Signing headers must be a plain data record.');
    }
    entries = Object.entries(input);
  }
  const allowed = new Set(staticOnly ? STATIC_HEADER_NAMES : SIGNING_HEADER_NAMES);
  const headers = {};
  let bytes = 0;
  for (const [rawName, value] of entries) {
    if (capture && (typeof rawName !== 'string' || !allowed.has(rawName.toLowerCase()))) continue;
    const name = normalizeHeaderName(rawName);
    if (staticOnly && ['sign', 'time', 'user-id'].includes(name)) {
      throw new TypeError('Dynamic header must not be stored in renewable configuration.');
    }
    if (!allowed.has(name) || Object.hasOwn(headers, name)) {
      throw new TypeError('Signing headers contain a disallowed or duplicate header.');
    }
    if (name.length > MAX_HEADER_NAME_BYTES || typeof value !== 'string'
      || value.length === 0 || value.length > MAX_HEADER_VALUE_BYTES
      || /[^\x20-\x7e]/.test(value) || value.trim() !== value) {
      throw new TypeError('Signing header value is invalid or oversized.');
    }
    bytes += name.length + value.length;
    if (bytes > MAX_CAPTURED_HEADER_BYTES
      || Object.keys(headers).length >= MAX_CAPTURED_HEADER_COUNT) {
      throw new TypeError('Signing headers exceed the captured-header budget.');
    }
    headers[name] = value;
  }
  return headers;
}
