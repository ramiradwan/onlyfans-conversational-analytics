// This function is intentionally closure-free for MAIN-world execution.
export async function executeTypedReadInPage(input) {
  // This must remain local to this closure-free MAIN-world function. The value mirrors the
  // simulator's only documented request-age check (src/simulated-platform.js), not a verified
  // platform acceptance window.
  const simulatorMaximumRequestAgeMs = 30_000;
  // Mirrors validation-limits.js; exercised at the exact boundary after serialization.
  const maximumResponseBytes = 8 * 1024 * 1024;
  const definitions = {
    identity: /^\/api2\/v2\/users\/me\/?$/,
    conversations: /^\/api2\/v2\/chats\/?$/,
    'message-page': /^\/api2\/v2\/chats\/[A-Za-z0-9_-]+\/messages\/?$/,
  };
  const safeMessageId = /^[1-9]\d{0,255}$/;
  const isMessageContinuation = (value) => typeof value === 'string' && value.startsWith('msg1.');
  const allowedHeaders = new Set([
    'accept',
    'app-token',
    'sign',
    'time',
    'user-id',
    'x-bc',
    'x-of-rev',
  ]);
  if (!input || input.method !== 'GET' || typeof input.operation !== 'string'
    || !Object.hasOwn(definitions, input.operation)) {
    throw new TypeError('MAIN-world signer accepts typed GET reads only.');
  }
  if (typeof input.url !== 'string' || /[\x00-\x20\x7f]/.test(input.url)) {
    throw new TypeError('MAIN-world signer URL is invalid.');
  }
  const url = new URL(input.url);
  if (url.origin !== 'https://onlyfans.com' || url.username || url.password || url.href.includes('#')
    || !definitions[input.operation].test(url.pathname)
    || (input.operation === 'message-page' && url.pathname.split('/')[4].length > 128)) {
    throw new TypeError('MAIN-world signer destination is outside its typed operation.');
  }
  const queryKeys = [...new Set(url.searchParams.keys())];
  if (input.operation === 'identity' && queryKeys.length !== 0) {
    throw new TypeError('MAIN-world identity read does not accept a query.');
  }
  if (input.operation !== 'identity') {
    const allowedQueryKeys = input.operation === 'message-page'
      ? ['limit', 'cursor', 'offset', 'id', 'order']
      : ['limit', 'cursor', 'offset'];
    if (queryKeys.some((key) => !allowedQueryKeys.includes(key))) {
      throw new TypeError('MAIN-world signer query contains an unsupported field.');
    }
    if (queryKeys.some((key) => url.searchParams.getAll(key).length !== 1)) {
      throw new TypeError('MAIN-world signer query fields must not repeat.');
    }
    if (url.searchParams.has('limit')) {
      const rawLimit = url.searchParams.get('limit');
      const limit = Number(rawLimit);
      if (!/^[1-9]\d*$/.test(rawLimit) || !Number.isSafeInteger(limit) || limit > 100) {
        throw new TypeError('MAIN-world signer query limit is invalid.');
      }
    }
    if (url.searchParams.has('cursor') && url.searchParams.has('offset')) {
      throw new TypeError('MAIN-world signer received conflicting continuation fields.');
    }
    if (url.searchParams.has('id')
      && (input.operation !== 'message-page'
        || url.searchParams.has('cursor') || url.searchParams.has('offset'))) {
      throw new TypeError('MAIN-world signer received an invalid message continuation field.');
    }
    if (url.searchParams.has('order') && url.searchParams.get('order') !== 'desc') {
      throw new TypeError('MAIN-world signer message order must be desc.');
    }
    if (url.searchParams.has('id') && !url.searchParams.has('order')) {
      throw new TypeError('MAIN-world signer message id requires descending order.');
    }
    if (url.searchParams.has('id') && !safeMessageId.test(url.searchParams.get('id'))) {
      throw new TypeError('MAIN-world signer message continuation id is invalid.');
    }
    if (url.searchParams.has('cursor')) {
      const cursor = url.searchParams.get('cursor');
      if (isMessageContinuation(cursor)) {
        throw new TypeError('MAIN-world signer received a reserved message continuation on the wire.');
      }
      if (!cursor || cursor.length > 512 || !/^[A-Za-z0-9._~-]+$/.test(cursor)) {
        throw new TypeError('MAIN-world signer query cursor is invalid.');
      }
    }
    if (url.searchParams.has('offset')) {
      const offset = url.searchParams.get('offset');
      if (isMessageContinuation(offset)) {
        throw new TypeError('MAIN-world signer received a reserved message continuation on the wire.');
      }
      if (!offset || offset.length > 512 || !/^[A-Za-z0-9._~-]+$/.test(offset)) {
        throw new TypeError('MAIN-world signer query offset is invalid.');
      }
    }
  }
  if (!input.headers || typeof input.headers !== 'object' || Array.isArray(input.headers)) {
    throw new TypeError('MAIN-world signer headers are invalid.');
  }
  const headers = {};
  let headerBytes = 0;
  for (const [rawName, value] of Object.entries(input.headers)) {
    const name = rawName.toLowerCase();
    if (!allowedHeaders.has(name) || Object.hasOwn(headers, name)
      || typeof value !== 'string' || value.length === 0 || value.length > 4096
      || /[^\x20-\x7e]/.test(value) || value.trim() !== value
      || (headerBytes += name.length + value.length) > 16 * 1024) {
      throw new TypeError(name === 'time'
        ? 'MAIN-world signer requires a valid signed request timestamp.'
        : 'MAIN-world signer received a disallowed header.');
    }
    headers[name] = value;
  }
  // This predicate intentionally duplicates src/signing/request-freshness.js because this
  // executor is serialized into the MAIN world and cannot retain imported bindings.
  const timestampWasMinted = (timestamp) => {
    if (typeof timestamp !== 'string' || !/^[1-9]\d{0,15}$/.test(timestamp)) return false;
    const issuedAt = Number(timestamp);
    return Number.isSafeInteger(issuedAt) && issuedAt > 0;
  };
  const timestampIsFresh = (timestamp, pageClock) => {
    if (!timestampWasMinted(timestamp)) return false;
    const issuedAt = Number(timestamp);
    return (
      Number.isSafeInteger(pageClock) &&
      Math.abs(pageClock - issuedAt) <= simulatorMaximumRequestAgeMs
    );
  };
  if (!timestampWasMinted(headers.time)) {
    throw new TypeError('MAIN-world signer requires a valid signed request timestamp.');
  }
  if (headers['user-id'] !== undefined && !/^[1-9]\d{0,255}$/.test(headers['user-id'])) {
    throw new TypeError('MAIN-world signer user ID is invalid.');
  }
  if (
    input.request_id !== undefined
    && (typeof input.request_id !== 'string' || !/^[A-Za-z0-9._~-]{1,128}$/.test(input.request_id))
  ) {
    throw new TypeError('MAIN-world signer request identifier is invalid.');
  }
  // Absolute dispatch ceiling is separate from the signed timestamp. A frozen
  // or delayed injection cannot renew an abandoned transport's lifetime.
  const expiresAt = input.expires_at ?? Date.now() + 30_000;
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= 0) {
    throw new TypeError('MAIN-world signer transport expiry is invalid.');
  }
  const timeoutError = () => {
    const error = new Error('Browser signing transport exceeded its time limit.');
    error.name = 'TimeoutError';
    error.code = 'transport_timeout';
    return error;
  };
  const registryKey = '__LOCAL_AUTHENTICATED_READ_ABORTS_V1__';
  let registry = null;
  if (input.request_id !== undefined) {
    registry = globalThis[registryKey];
    if (!(registry instanceof Map)) globalThis[registryKey] = registry = new Map();
    const existing = registry.get(input.request_id);
    if (existing instanceof AbortController) {
      if (existing.signal.aborted) {
        existing.retire?.();
        registry.delete(input.request_id);
        throw existing.signal.reason;
      }
      throw new Error('MAIN-world signer request identifier is already active.');
    }
  }
  if (Date.now() >= expiresAt) throw timeoutError();
  const controller = new AbortController();
  let timer;
  const documentLost = () => {
    const error = new Error('The browser signing document is no longer available.');
    error.name = 'BrowserSigningContextError';
    error.code = 'context_lost';
    controller.abort(error);
  };
  const retire = () => {
    globalThis.removeEventListener?.('pagehide', documentLost);
    clearTimeout(timer);
    if (registry?.get(input.request_id) === controller) registry.delete(input.request_id);
  };
  globalThis.addEventListener?.('pagehide', documentLost, { once: true });
  controller.retire = retire;
  registry?.set(input.request_id, controller);
  timer = setTimeout(() => controller.abort(timeoutError()), Math.min(2_147_483_647, expiresAt - Date.now()));
  // Closure-local equivalent of runAbortable: imports are lost on serialization.
  // Observe late failures even when fetch/body consumption ignores cancellation.
  const run = (task) => new Promise((resolve, reject) => {
    const signal = controller.signal;
    const aborted = () => reject(signal.reason);
    const work = Promise.resolve().then(() => {
      if (signal.aborted) throw signal.reason;
      return task();
    });
    work.then(
      (value) => { signal.removeEventListener('abort', aborted); signal.aborted ? reject(signal.reason) : resolve(value); },
      (error) => { signal.removeEventListener('abort', aborted); reject(signal.aborted ? signal.reason : error); },
    );
    if (signal.aborted) aborted();
    else signal.addEventListener('abort', aborted, { once: true });
  });
  const destination = url.toString();
  let response = null;
  let reader = null;
  let bodyConsumed = false;
  const cancelQuietly = (source) => {
    // Cleanup cannot extend the transport deadline or leak a rejected promise.
    try { Promise.resolve(source?.cancel()).catch(() => undefined); } catch {}
  };
  const check = () => {
    if (controller.signal.aborted) throw controller.signal.reason;
    if (Date.now() >= expiresAt) throw timeoutError();
  };
  try {
    // Authoritative freshness check, immediately before transmission. No async work
    // or URL transformation intervenes between this clock sample and fetch.
    response = await run(() => {
      const dispatchClock = Date.now();
      if (dispatchClock >= expiresAt) throw timeoutError();
      if (!timestampIsFresh(headers.time, dispatchClock)) {
        throw new Error('MAIN-world signer refused an expired signed request before fetch.');
      }
      return Promise.resolve(fetch(destination, {
        method: 'GET',
        headers,
        credentials: 'include',
        cache: 'no-store',
        redirect: 'error',
        signal: controller.signal,
      })).then((value) => {
        // Even a noncooperative fetch resolving after abandonment cannot retain a body.
        if (controller.signal.aborted) {
          cancelQuietly(value?.body);
          throw controller.signal.reason;
        }
        return value;
      });
    });
    check();
    let bodyError = null;
    const selectedHeader = (name, maximum) => {
      const value = response.headers.get(name);
      if (value === null || value === '') return null;
      if (typeof value !== 'string' || value.length > maximum || /[^\x20-\x7e]/.test(value)) {
        bodyError = 'invalid_response_metadata';
        return null;
      }
      return value;
    };
    const contentType = selectedHeader('content-type', 4096) ?? '';
    const responseRevision = selectedHeader('x-of-rev', 128);
    let retryAfterMs = null;
    if (response.status === 429) {
      const rawRetryAfter = selectedHeader('retry-after', 4096);
      if (rawRetryAfter !== null && rawRetryAfter.trim().length > 0) {
        const seconds = Number(rawRetryAfter);
        const milliseconds = Number.isFinite(seconds) && seconds >= 0
          ? seconds * 1_000
          : Date.parse(rawRetryAfter) - Date.now();
        if (Number.isFinite(milliseconds)) {
          retryAfterMs = Math.min(3_600_000, Math.max(0, Math.ceil(milliseconds)));
        }
      }
    }
    const result = (body) => {
      check();
      return {
      status: response.status, contentType, responseRevision, retryAfterMs, body,
      ...(bodyError === null ? {} : { bodyError }),
      };
    };
    if (bodyError !== null) return result(null);
    if (response.body === null) {
      // Null-body HTTP responses are empty, not permission to use an unbounded fallback.
      bodyConsumed = true;
      return result(null);
    }
    try {
      if (typeof response.body?.getReader !== 'function') throw new TypeError();
      reader = response.body.getReader();
    } catch {
      check();
      bodyError = 'response_body_unavailable';
      return result(null);
    }
    let bytes = new Uint8Array(0);
    let received = 0;
    try {
      while (true) {
        const chunk = await run(() => reader.read());
        check();
        if (chunk.done) { bodyConsumed = true; break; }
        if (!(chunk.value instanceof Uint8Array)) throw new TypeError();
        // Count actual consumed bytes, not Content-Length (which may describe compressed
        // bytes, be absent, or lie). Never copy or decode an overflowing chunk.
        if (chunk.value.byteLength > maximumResponseBytes - received) {
          bodyError = 'response_too_large';
          return result(null);
        }
        const total = received + chunk.value.byteLength;
        if (total > bytes.length) {
          // Bounded contiguous storage: tiny chunks cannot create an unbounded chunk list,
          // and small views cannot retain arbitrarily large upstream backing buffers.
          const grown = new Uint8Array(Math.min(maximumResponseBytes,
            Math.max(total, bytes.length * 2, 64 * 1024)));
          grown.set(bytes.subarray(0, received));
          bytes = grown;
        }
        bytes.set(chunk.value, received);
        received = total;
      }
    } catch {
      check();
      bodyError = 'response_body_read_failed';
      return result(null);
    }
    check();
    let body = null;
    try {
      body = JSON.parse(new TextDecoder().decode(bytes.subarray(0, received)));
    } catch {
      // Preserve malformed-JSON semantics; never return fragments or parser messages.
    }
    check();
    return result(body);
  } finally {
    if (!bodyConsumed) {
      cancelQuietly(reader ?? response?.body);
      if (!controller.signal.aborted) controller.abort();
    }
    // Release without awaiting cancellation: a stalled source must not delay settlement.
    try { reader?.releaseLock(); } catch {}
    retire();
  }
}
