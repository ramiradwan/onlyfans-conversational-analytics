import { safeContentType, safeRetryAfter, safeStatus } from './diagnostics.js';
import {
  expectedResponse,
  isUsableContinuation,
  MAX_PAGE_LIMIT,
} from './operations.js';

import {
  MAX_CANONICAL_PAGE_BYTES, MAX_DISPLAY_NAME_LENGTH, MAX_MESSAGE_TEXT_BYTES, utf8ByteLength,
} from './validation-limits.js';
import { canonicalPageByteLength } from './canonical-page.js';
import { decodeMessageContinuation, encodeMessageContinuation, isMessageContinuation } from './message-continuation.js';

const BODY_ERROR_CODES = new Set([
  'response_too_large', 'response_body_unavailable', 'response_body_read_failed',
  'invalid_response_metadata',
]);
const VALIDATION_CODES = new Set([
  ...BODY_ERROR_CODES,
  'canonical_page_too_large',
  'conflicting_page_continuation',
  'conflicting_page_items',
  'invalid_page_has_more',
  'boundary_continuation_conflict',
  'conflicting_conversation_display_name',
  'conflicting_conversation_identifier',
  'conflicting_conversation_updated_at',
  'conflicting_conversation_user_identifier',
  'conflicting_last_message_timestamp',
  'conflicting_message_chat_identifier',
  'conflicting_message_direction',
  'conflicting_message_direction_flag',
  'conflicting_message_identifier',
  'conflicting_message_sender_identifier',
  'conflicting_message_sent_at',
  'conflicting_message_text',
  'conflicting_requested_message_chat_identifier',
  'invalid_boundary',
  'invalid_continuation',
  'invalid_conversation',
  'invalid_conversation_display_name',
  'invalid_conversation_identifier',
  'invalid_conversation_updated_at',
  'invalid_conversation_user',
  'invalid_conversation_user_identifier',
  'invalid_identity',
  'invalid_last_message',
  'invalid_last_message_timestamp',
  'invalid_message',
  'invalid_message_chat',
  'invalid_message_chat_identifier',
  'invalid_message_direction',
  'invalid_message_direction_flag',
  'invalid_message_identifier',
  'invalid_message_sender',
  'invalid_message_sender_identifier',
  'invalid_message_sent_at',
  'invalid_message_text',
  'missing_continuation_or_boundary',
  'missing_conversation_user_identifier',
  'missing_items',
  'missing_message_identifier',
  'missing_message_sender_identifier',
  'missing_message_sent_at',
  'missing_message_text',
  'missing_page_continuation',
  'too_many_items',
  'unsupported_response_field',
]);

const CONVERSATION_KEYS = new Set([
  'id',
  'chat_id',
  'chatId',
  'platform_user_id',
  'platformUserId',
  'withUser',
  'with_user',
  'user',
  'display_name',
  'displayName',
  'updated_at',
  'updatedAt',
  'changedAt',
  'lastMessage',
  'last_message',
]);
const CONVERSATION_USER_KEYS = new Set(['id', 'name', 'displayName', 'username']);
const MESSAGE_KEYS = new Set([
  'id',
  'message_id',
  'messageId',
  'chat_id',
  'chatId',
  'chat',
  'sender_platform_user_id',
  'senderPlatformUserId',
  'sender_id',
  'senderId',
  'fromUser',
  'from_user',
  'sender',
  'text',
  'body',
  'sent_at',
  'sentAt',
  'created_at',
  'createdAt',
  'postedAt',
  'direction',
  'isFromCreator',
  'is_from_creator',
  'isOutgoing',
  'is_outgoing',
  'outgoing',
]);
const MESSAGE_USER_KEYS = new Set(['id', 'is_me', 'isMe', 'me']);
const ID_ONLY_KEYS = new Set(['id']);

class TypedResponseValidationError extends Error {
  constructor(code) {
    super(code);
    this.name = 'TypedResponseValidationError';
    this.code = code;
  }
}

function responseClass(summary) {
  return [
    summary.status ?? 'unknown',
    summary.content_type?.split(';', 1)[0] || 'unknown',
    summary.semantic_success ? 'expected-shape' : summary.json ? 'json-other' : 'non-json',
  ].join('|');
}

function isJsonContentType(contentType) {
  if (typeof contentType !== 'string') return false;
  const mediaType = contentType.split(';', 1)[0].trim().toLowerCase();
  return mediaType === 'application/json' || mediaType.endsWith('+json');
}

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function rejectUnknownKeys(value, allowed, code) {
  if (!isPlainObject(value)) throw new TypedResponseValidationError(code);
  if (Object.keys(value).some((key) => !allowed.has(key))) {
    throw new TypedResponseValidationError(code);
  }
}

function validateNestedObject(record, key, allowed, code) {
  if (!Object.hasOwn(record, key)) return;
  rejectUnknownKeys(record[key], allowed, code);
}

// Closure-free so the diagnostic probe can serialize the exact same validator.
export function normalizeIdentifier(value) {
  const MAX_IDENTIFIER_LENGTH = 256;
  const SAFE_IDENTIFIER = /^[A-Za-z0-9_-]+$/;
  if (Number.isSafeInteger(value) && value >= 0) return String(value);
  if (
    typeof value === 'string'
    && value.length >= 1
    && value.length <= MAX_IDENTIFIER_LENGTH
    && SAFE_IDENTIFIER.test(value)
  ) return value;
  return null;
}

function valueAt(record, path) {
  let value = record;
  for (const segment of path) {
    if (!isPlainObject(value) || !Object.hasOwn(value, segment)) {
      return { present: false, value: undefined };
    }
    value = value[segment];
  }
  return { present: true, value };
}

function resolveAliases(record, paths, normalize, invalidCode, conflictCode) {
  const normalized = [];
  for (const path of paths) {
    const candidate = valueAt(record, path);
    if (!candidate.present) continue;
    let value;
    try {
      value = normalize(candidate.value);
    } catch {
      throw new TypedResponseValidationError(invalidCode);
    }
    if (value === undefined) throw new TypedResponseValidationError(invalidCode);
    normalized.push(value);
  }
  if (normalized.length === 0) return undefined;
  if (normalized.some((value) => !Object.is(value, normalized[0]))) {
    throw new TypedResponseValidationError(conflictCode);
  }
  return normalized[0];
}

function requiredIdentifier(value) {
  const normalized = normalizeIdentifier(value);
  if (normalized === null) throw new TypeError('invalid identifier');
  return normalized;
}

function optionalDisplayName(value) {
  if (value === null || value === '') return null;
  if (typeof value !== 'string' || value.length > MAX_DISPLAY_NAME_LENGTH) {
    throw new TypeError('invalid display name');
  }
  return value;
}

function normalizedTimestamp(value) {
  let milliseconds;
  if (typeof value === 'number' && Number.isFinite(value)) {
    milliseconds = Math.abs(value) < 1_000_000_000_000 ? value * 1000 : value;
  } else if (
    typeof value === 'string'
    && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)
  ) {
    milliseconds = Date.parse(value);
  } else {
    throw new TypeError('invalid timestamp');
  }
  if (!Number.isFinite(milliseconds)) throw new TypeError('invalid timestamp');
  return new Date(milliseconds).toISOString();
}

function normalizedText(value) {
  if (typeof value !== 'string' || utf8ByteLength(value, MAX_MESSAGE_TEXT_BYTES) > MAX_MESSAGE_TEXT_BYTES) {
    throw new TypeError('invalid message text');
  }
  return value;
}

function normalizedDirection(value) {
  if (value === null) return null;
  if (typeof value !== 'string') throw new TypeError('invalid direction');
  const normalized = value.toLowerCase();
  if (['outbound', 'creator', 'outgoing', 'sent'].includes(normalized)) return 'outbound';
  if (['inbound', 'fan', 'incoming', 'received'].includes(normalized)) return 'inbound';
  throw new TypeError('invalid direction');
}

function directionFromBoolean(value) {
  if (typeof value !== 'boolean') throw new TypeError('invalid direction flag');
  return value ? 'outbound' : 'inbound';
}

function normalizeConversation(record) {
  rejectUnknownKeys(record, CONVERSATION_KEYS, 'invalid_conversation');
  for (const key of ['withUser', 'with_user', 'user']) {
    validateNestedObject(record, key, CONVERSATION_USER_KEYS, 'invalid_conversation_user');
  }
  validateNestedObject(record, 'lastMessage', new Set(['createdAt']), 'invalid_last_message');
  validateNestedObject(record, 'last_message', new Set(['created_at']), 'invalid_last_message');

  const platformUserId = resolveAliases(record, [
    ['platform_user_id'],
    ['platformUserId'],
    ['withUser', 'id'],
    ['with_user', 'id'],
    ['user', 'id'],
  ], requiredIdentifier, 'invalid_conversation_user_identifier', 'conflicting_conversation_user_identifier');
  if (platformUserId === undefined) {
    throw new TypedResponseValidationError('missing_conversation_user_identifier');
  }
  const explicitConversationId = resolveAliases(record, [
    ['id'],
    ['chat_id'],
    ['chatId'],
  ], requiredIdentifier, 'invalid_conversation_identifier', 'conflicting_conversation_identifier');
  const displayName = resolveAliases(record, [
    ['display_name'],
    ['displayName'],
    ['withUser', 'name'],
    ['withUser', 'displayName'],
    ['withUser', 'username'],
    ['with_user', 'name'],
    ['with_user', 'displayName'],
    ['with_user', 'username'],
    ['user', 'name'],
    ['user', 'displayName'],
    ['user', 'username'],
  ], optionalDisplayName, 'invalid_conversation_display_name', 'conflicting_conversation_display_name');
  const directUpdatedAt = resolveAliases(record, [
    ['updated_at'],
    ['updatedAt'],
    ['changedAt'],
  ], normalizedTimestamp, 'invalid_conversation_updated_at', 'conflicting_conversation_updated_at');
  const fallbackUpdatedAt = resolveAliases(record, [
    ['lastMessage', 'createdAt'],
    ['last_message', 'created_at'],
  ], normalizedTimestamp, 'invalid_last_message_timestamp', 'conflicting_last_message_timestamp');
  const updatedAt = directUpdatedAt ?? fallbackUpdatedAt;

  return {
    id: explicitConversationId ?? platformUserId,
    platform_user_id: platformUserId,
    display_name: displayName ?? null,
    updated_at: updatedAt ?? null,
  };
}

function normalizeMessage(record, requestedChatId) {
  rejectUnknownKeys(record, MESSAGE_KEYS, 'invalid_message');
  validateNestedObject(record, 'chat', ID_ONLY_KEYS, 'invalid_message_chat');
  for (const key of ['fromUser', 'from_user']) {
    validateNestedObject(record, key, MESSAGE_USER_KEYS, 'invalid_message_sender');
  }
  validateNestedObject(record, 'sender', ID_ONLY_KEYS, 'invalid_message_sender');

  const id = resolveAliases(record, [
    ['id'],
    ['message_id'],
    ['messageId'],
  ], requiredIdentifier, 'invalid_message_identifier', 'conflicting_message_identifier');
  if (id === undefined) throw new TypedResponseValidationError('missing_message_identifier');
  const responseChatId = resolveAliases(record, [
    ['chat_id'],
    ['chatId'],
    ['chat', 'id'],
  ], requiredIdentifier, 'invalid_message_chat_identifier', 'conflicting_message_chat_identifier');
  if (
    requestedChatId !== null
    && responseChatId !== undefined
    && responseChatId !== requestedChatId
  ) throw new TypedResponseValidationError('conflicting_requested_message_chat_identifier');
  const senderId = resolveAliases(record, [
    ['sender_platform_user_id'],
    ['senderPlatformUserId'],
    ['sender_id'],
    ['senderId'],
    ['fromUser', 'id'],
    ['from_user', 'id'],
    ['sender', 'id'],
  ], requiredIdentifier, 'invalid_message_sender_identifier', 'conflicting_message_sender_identifier');
  if (senderId === undefined) throw new TypedResponseValidationError('missing_message_sender_identifier');
  const text = resolveAliases(record, [
    ['text'],
    ['body'],
  ], normalizedText, 'invalid_message_text', 'conflicting_message_text');
  if (text === undefined) throw new TypedResponseValidationError('missing_message_text');
  const sentAt = resolveAliases(record, [
    ['sent_at'],
    ['sentAt'],
    ['created_at'],
    ['createdAt'],
    ['postedAt'],
  ], normalizedTimestamp, 'invalid_message_sent_at', 'conflicting_message_sent_at');
  if (sentAt === undefined) throw new TypedResponseValidationError('missing_message_sent_at');
  const explicitDirection = resolveAliases(record, [
    ['direction'],
  ], normalizedDirection, 'invalid_message_direction', 'conflicting_message_direction');
  const flagDirection = resolveAliases(record, [
    ['isFromCreator'],
    ['is_from_creator'],
    ['isOutgoing'],
    ['is_outgoing'],
    ['outgoing'],
    ['fromUser', 'is_me'],
    ['fromUser', 'isMe'],
    ['fromUser', 'me'],
    ['from_user', 'is_me'],
    ['from_user', 'isMe'],
    ['from_user', 'me'],
  ], directionFromBoolean, 'invalid_message_direction_flag', 'conflicting_message_direction_flag');
  if (
    explicitDirection != null
    && flagDirection !== undefined
    && explicitDirection !== flagDirection
  ) throw new TypedResponseValidationError('conflicting_message_direction');

  return {
    id,
    chat_id: requestedChatId,
    sender_platform_user_id: senderId,
    text,
    sent_at: sentAt,
    direction: explicitDirection ?? flagDirection ?? null,
  };
}

function normalizeItems(operation, value, requestedChatId) {
  if (!Array.isArray(value)) throw new TypedResponseValidationError('missing_items');
  if (value.length > MAX_PAGE_LIMIT) throw new TypedResponseValidationError('too_many_items');
  return operation === 'conversations'
    ? Array.from(value, (record) => normalizeConversation(record))
    : Array.from(value, (record) => normalizeMessage(record, requestedChatId));
}

// OnlyFans returns full platform objects rather than the reduced shapes the
// development simulator emits. The adapter below extracts the canonical fields
// and ignores everything else instead of rejecting unknown keys.
function firstPresent(record, paths, normalize, invalidCode) {
  for (const path of paths) {
    const candidate = valueAt(record, path);
    if (!candidate.present || candidate.value === undefined || candidate.value === null) continue;
    let value;
    try {
      value = normalize(candidate.value);
    } catch {
      throw new TypedResponseValidationError(invalidCode);
    }
    if (value !== undefined && value !== null) return value;
  }
  return undefined;
}

function validateProjectedObject(record, key, code, nullable = false) {
  if (Object.hasOwn(record, key) && !(nullable && record[key] === null)
    && !isPlainObject(record[key])) throw new TypedResponseValidationError(code);
}

function normalizeOnlyFansConversation(record) {
  if (!isPlainObject(record)) throw new TypedResponseValidationError('invalid_conversation');
  for (const key of ['withUser', 'with_user', 'user']) {
    validateProjectedObject(record, key, 'invalid_conversation_user');
  }
  for (const key of ['lastMessage', 'last_message']) {
    validateProjectedObject(record, key, 'invalid_last_message', true);
  }
  const platformUserId = resolveAliases(record, [
    ['platform_user_id'], ['platformUserId'],
    ['withUser', 'id'], ['with_user', 'id'], ['user', 'id'],
  ], requiredIdentifier, 'invalid_conversation_user_identifier', 'conflicting_conversation_user_identifier');
  if (platformUserId === undefined) {
    throw new TypedResponseValidationError('missing_conversation_user_identifier');
  }
  const explicitConversationId = resolveAliases(record, [
    ['id'], ['chat_id'], ['chatId'],
  ], requiredIdentifier, 'invalid_conversation_identifier', 'conflicting_conversation_identifier');
  // Explicit aliases must agree; legitimate user name/displayName/username
  // fallbacks need not. Full-object projection must not conflate those fields.
  const explicitDisplayName = resolveAliases(record, [
    ['display_name'], ['displayName'],
  ], optionalDisplayName, 'invalid_conversation_display_name', 'conflicting_conversation_display_name');
  const displayName = explicitDisplayName ?? firstPresent(record, [
    ['withUser', 'displayName'], ['withUser', 'name'], ['withUser', 'username'],
    ['with_user', 'displayName'], ['with_user', 'name'], ['with_user', 'username'],
    ['user', 'displayName'], ['user', 'name'], ['user', 'username'],
  ], optionalDisplayName, 'invalid_conversation_display_name');
  // Conversation records carry no conversation-scoped timestamp of their own, so
  // the value comes from the last message. The platform omits that last message
  // for some conversations, including ones that do have message history, and the
  // only timestamps left on such a record describe the counterparty user rather
  // than the conversation. A field the platform does not guarantee cannot be
  // required, and none is synthesised.
  const updatedAt = resolveAliases(record, [
    ['updated_at'], ['updatedAt'], ['changedAt'],
    ['lastMessage', 'createdAt'], ['last_message', 'created_at'],
  ], normalizedTimestamp, 'invalid_conversation_updated_at', 'conflicting_conversation_updated_at');
  return {
    id: explicitConversationId ?? platformUserId,
    platform_user_id: platformUserId,
    display_name: displayName ?? null,
    updated_at: updatedAt ?? null,
  };
}

function normalizeOnlyFansMessage(record, requestedChatId) {
  if (!isPlainObject(record)) throw new TypedResponseValidationError('invalid_message');
  validateProjectedObject(record, 'chat', 'invalid_message_chat');
  for (const key of ['fromUser', 'from_user', 'sender', 'author']) {
    validateProjectedObject(record, key, 'invalid_message_sender');
  }
  const id = resolveAliases(record, [
    ['id'], ['message_id'], ['messageId'],
  ], requiredIdentifier, 'invalid_message_identifier', 'conflicting_message_identifier');
  if (id === undefined) throw new TypedResponseValidationError('missing_message_identifier');
  const responseChatId = resolveAliases(record, [
    ['chat_id'], ['chatId'], ['chat', 'id'],
  ], requiredIdentifier, 'invalid_message_chat_identifier', 'conflicting_message_chat_identifier');
  if (
    requestedChatId !== null
    && responseChatId !== undefined
    && responseChatId !== requestedChatId
  ) throw new TypedResponseValidationError('conflicting_requested_message_chat_identifier');
  const senderId = resolveAliases(record, [
    ['sender_platform_user_id'], ['senderPlatformUserId'], ['sender_id'], ['senderId'],
    ['fromUser', 'id'], ['from_user', 'id'], ['sender', 'id'], ['author', 'id'],
  ], requiredIdentifier, 'invalid_message_sender_identifier', 'conflicting_message_sender_identifier');
  if (senderId === undefined) throw new TypedResponseValidationError('missing_message_sender_identifier');
  const text = resolveAliases(record, [
    ['text'], ['body'],
  ], normalizedText, 'invalid_message_text', 'conflicting_message_text');
  if (text === undefined) throw new TypedResponseValidationError('missing_message_text');
  const sentAt = resolveAliases(record, [
    ['sent_at'], ['sentAt'], ['created_at'], ['createdAt'], ['postedAt'],
  ], normalizedTimestamp, 'invalid_message_sent_at', 'conflicting_message_sent_at');
  if (sentAt === undefined) throw new TypedResponseValidationError('missing_message_sent_at');
  const explicitDirection = resolveAliases(record, [
    ['direction'],
  ], normalizedDirection, 'invalid_message_direction', 'conflicting_message_direction');
  const flagDirection = resolveAliases(record, [
    ['isFromCreator'], ['is_from_creator'], ['isOutgoing'], ['is_outgoing'], ['outgoing'],
    ['fromUser', 'isMe'], ['fromUser', 'is_me'], ['fromUser', 'me'],
    ['from_user', 'isMe'], ['from_user', 'is_me'], ['from_user', 'me'],
  ], directionFromBoolean, 'invalid_message_direction_flag', 'conflicting_message_direction_flag');
  if (
    explicitDirection != null
    && flagDirection !== undefined
    && explicitDirection !== flagDirection
  ) throw new TypedResponseValidationError('conflicting_message_direction');
  return {
    id,
    chat_id: requestedChatId,
    sender_platform_user_id: senderId,
    text,
    sent_at: sentAt,
    direction: explicitDirection ?? flagDirection ?? null,
  };
}

function onlyFansParticipantId(record, key) {
  if (!isPlainObject(record)) return null;
  if (key === 'sender') {
    return isPlainObject(record.fromUser) ? normalizeIdentifier(record.fromUser.id) : null;
  }
  return normalizeIdentifier(record.chatUserId);
}

function inferOnlyFansMessageDirections(records, items) {
  const participants = records.map((record) => ({
    senderId: onlyFansParticipantId(record, 'sender'),
    counterpartyId: onlyFansParticipantId(record, 'counterparty'),
  }));
  const completeParticipants = participants.filter(
    ({ senderId, counterpartyId }) => senderId !== null && counterpartyId !== null,
  );
  const counterpartyIds = new Set(completeParticipants.map(({ counterpartyId }) => counterpartyId));
  const senderIds = new Set(completeParticipants.map(({ senderId }) => senderId));
  const [counterpartyId] = counterpartyIds;
  const hasTwoParticipantShape = (
    counterpartyIds.size === 1
    && senderIds.has(counterpartyId)
    && senderIds.size >= 1
    && senderIds.size <= 2
  );

  return items.map((item, index) => {
    const { senderId, counterpartyId: recordCounterpartyId } = participants[index];
    const derivedDirection = hasTwoParticipantShape && senderId !== null && recordCounterpartyId !== null
      ? senderId === recordCounterpartyId ? 'inbound' : 'outbound'
      : null;
    // Never overwrite validated explicit direction/flags with page-relative inference.
    return { ...item, direction: item.direction ?? derivedDirection };
  });
}

function normalizeOnlyFansItems(operation, list, requestedChatId) {
  if (!Array.isArray(list)) throw new TypedResponseValidationError('missing_items');
  if (list.length > MAX_PAGE_LIMIT) throw new TypedResponseValidationError('too_many_items');
  // Array.from visits holes too: sparse custom-host arrays are not valid pages.
  const items = Array.from(list, (record) => operation === 'conversations'
    ? normalizeOnlyFansConversation(record) : normalizeOnlyFansMessage(record, requestedChatId));
  return operation === 'message-page' ? inferOnlyFansMessageDirections(list, items) : items;
}

function sameItems(left, right) {
  return left.length === right.length && left.every((item, index) => (
    Object.keys(item).every((key) => Object.is(item[key], right[index][key]))
  ));
}

function normalizeOnlyFansPage(operation, object, requestedChatId) {
  const items = normalizeOnlyFansItems(operation, object.list, requestedChatId);
  if (operation === 'message-page' && Object.hasOwn(object, 'messages')) {
    const alias = normalizeOnlyFansItems(operation, object.messages, requestedChatId);
    if (!sameItems(items, alias)) throw new TypedResponseValidationError('conflicting_page_items');
  }
  const hasMore = object.hasMore;
  const hasOffset = Object.hasOwn(object, 'nextOffset');
  if (hasOffset && (!Number.isSafeInteger(object.nextOffset) || object.nextOffset < 0)) {
    throw new TypedResponseValidationError('invalid_continuation');
  }
  let continuation = null;
  if (hasMore) {
    if (hasOffset) continuation = normalizeContinuation(String(object.nextOffset));
    else if (operation === 'message-page' && items.length > 0 && requestedChatId !== null) {
      // Native older-history reads use the oldest returned message ID as `id`.
      // Validate the page's descending ID order before exposing that anchor.
      try {
        for (let index = 0; index < items.length; index++) {
          encodeMessageContinuation(requestedChatId, items[index].id);
          if (index > 0 && BigInt(items[index - 1].id) <= BigInt(items[index].id)) {
            throw new TypeError('Native message page identifiers are not descending.');
          }
        }
        continuation = encodeMessageContinuation(requestedChatId, items.at(-1).id);
      } catch {
        throw new TypedResponseValidationError('invalid_continuation');
      }
    } else throw new TypedResponseValidationError('missing_page_continuation');
  }
  const expectedBoundary = expectedResponse(operation).boundary;
  const boundary = hasMore ? null : expectedBoundary;
  if (Object.hasOwn(object, 'next_cursor')
    && normalizeContinuation(object.next_cursor) !== continuation) {
    throw new TypedResponseValidationError('conflicting_page_continuation');
  }
  if (Object.hasOwn(object, 'boundary')
    && normalizeBoundary(object.boundary, expectedBoundary) !== boundary) {
    throw new TypedResponseValidationError('boundary_continuation_conflict');
  }
  // A terminal upstream page may carry nextOffset: 0. It is metadata, not a
  // usable continuation: hasMore:false remains the evidenced terminal signal.
  return { items, continuation, boundary };
}

function normalizeContinuation(value) {
  if (value === undefined || value === null) return null;
  if (!isUsableContinuation(value)) throw new TypedResponseValidationError('invalid_continuation');
  return value;
}

function normalizeBoundary(value, expectedBoundary) {
  if (value === undefined || value === null) return null;
  if (value !== expectedBoundary) throw new TypedResponseValidationError('invalid_boundary');
  return value;
}

function normalizeTypedData(operation, object, parameters) {
  const expectation = expectedResponse(operation);
  const requestedChatId = operation === 'message-page'
    ? normalizeIdentifier(parameters?.conversationId)
    : null;
  if (operation === 'identity') {
    // The identity endpoint returns the full authenticated user object; reduce
    // it to the id rather than requiring an exact single-key shape.
    if (!isPlainObject(object)) throw new TypedResponseValidationError('invalid_identity');
    const id = normalizeIdentifier(object.id);
    if (id === null) throw new TypedResponseValidationError('invalid_identity');
    return { id };
  }

  // Native conversations use nextOffset; native older-message pages use an ID
  // anchor. Reduced pages below carry an explicit continuation and boundary.
  if (Object.hasOwn(object, 'hasMore')) {
    if (typeof object.hasMore !== 'boolean') throw new TypedResponseValidationError('invalid_page_has_more');
    return normalizeOnlyFansPage(operation, object, requestedChatId);
  }

  rejectUnknownKeys(
    object,
    new Set([expectation.key, 'next_cursor', 'boundary']),
    'unsupported_response_field',
  );
  const items = normalizeItems(operation, object[expectation.key], requestedChatId);
  const continuation = normalizeContinuation(object.next_cursor);
  const boundary = normalizeBoundary(object.boundary, expectation.boundary);
  if ((continuation === null) === (boundary === null)) {
    throw new TypedResponseValidationError(
      continuation === null
        ? 'missing_continuation_or_boundary'
        : 'boundary_continuation_conflict',
    );
  }
  return { items, continuation, boundary };
}

export function parseTypedResponse({ operation, parameters, status, contentType, body, bodyError = null }) {
  const contentTypeValue = typeof contentType === 'string' ? contentType : '';
  // Valid HTTP status codes are integers in the range 100..599. Status 0 (or any non-integer / out-of-range value)
  // is not a valid HTTP status for typed response parsing and is normalized to null, yielding
  // validation_error: 'invalid_response_metadata'. Note that separate diagnostic projection
  // (safeStatus in diagnostics.js) allows 0 for transport failure before headers.
  const validStatus = Number.isInteger(status) && status >= 100 && status <= 599 ? status : null;
  // Any reported transport-body failure suppresses both success and rejection proof.
  // Unknown codes are not echoed and cannot turn a supplied partial body into evidence.
  const object = validStatus !== null && bodyError === null && isPlainObject(body) ? body : null;
  let data = null;
  let validationError = BODY_ERROR_CODES.has(bodyError)
    ? bodyError
    : (validStatus === null ? 'invalid_response_metadata' : null);
  if (validStatus !== null && validStatus >= 200 && validStatus < 300 && isJsonContentType(contentTypeValue) && object !== null) {
    try {
      const normalized = normalizeTypedData(operation, object, parameters);
      if (isMessageContinuation(normalized.continuation)) {
        try {
          if (operation !== 'message-page') throw new TypeError('Wrong continuation operation.');
          decodeMessageContinuation(normalized.continuation, parameters?.conversationId);
        } catch {
          throw new TypedResponseValidationError('invalid_continuation');
        }
      }
      if (operation !== 'identity'
        && canonicalPageByteLength(normalized, MAX_CANONICAL_PAGE_BYTES) > MAX_CANONICAL_PAGE_BYTES) {
        throw new TypedResponseValidationError('canonical_page_too_large');
      }
      // Assign only after the whole page passes. No truncation or partial success.
      data = normalized;
    } catch (error) {
      if (!(error instanceof TypedResponseValidationError)) throw error;
      validationError = error.code;
    }
  }
  const expectation = expectedResponse(operation);
  const hasExpectedKey = object !== null && (
    Object.hasOwn(object, expectation.key)
    || (operation === 'message-page' && Object.hasOwn(object, 'list'))
  );
  const summary = {
    status: validStatus,
    content_type: contentTypeValue,
    json: object !== null,
    semantic_success: data !== null,
    validation_error: validationError,
    // Internal proof evidence, never a platform error-message/code guess.
    rejection_class: validStatus === 400 && object !== null
      && isJsonContentType(contentTypeValue) && !hasExpectedKey
      ? 'observed_bad_request' : null,
  };
  summary.response_class = responseClass(summary);
  return { summary, data };
}

export function summarizeTypedResponse(input) {
  return parseTypedResponse(input).summary;
}

export function publicResponseSummary(summary) {
  const status = safeStatus(summary.status);
  const contentType = safeContentType(summary.content_type);
  const failureCode = summary.semantic_success === true ? null
    : status === 429 ? 'rate_limited'
      : status === 401 || status === 403 ? 'authorization_failed'
        : status >= 500 && status < 600 ? 'upstream_unavailable'
          : status === null || status === 0 || (status >= 200 && status < 300) ? 'invalid_response'
            : 'upstream_rejected';
  return {
    status,
    content_type: contentType,
    response_class: [
      status ?? 'unknown', contentType || 'unknown',
      summary.semantic_success === true ? 'expected-shape' : summary.json === true ? 'json-other' : 'non-json',
    ].join('|'),
    retry_after_ms: safeRetryAfter(status, summary.retry_after_ms),
    failure_code: failureCode,
    validation_error: VALIDATION_CODES.has(summary.validation_error)
      ? summary.validation_error : null,
  };
}

export { classifyDifferentialProof } from './proof-policy.js';

export { TypedResponseValidationError };
