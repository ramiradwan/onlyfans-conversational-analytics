import { isFreshSignedRequestTimestamp } from './request-freshness.js';

// Version 1 identified the legacy divergence classifier. Version 2 requires
// the differential evidence checks below. A future classifier change must bump
// this value; never relabel stored proof on load.
export const CURRENT_PROOF_POLICY_VERSION = 2;

export function hasCurrentGenerationProof(generation) {
  return generation?.proof_outcome === 'strong'
    && generation.proof_policy_version === CURRENT_PROOF_POLICY_VERSION;
}

export function isCurrentStrongProof(proof) {
  return proof?.outcome === 'strong'
    && proof.policy_version === CURRENT_PROOF_POLICY_VERSION;
}

function isJson(contentType) {
  if (typeof contentType !== 'string') return false;
  const type = contentType.split(';', 1)[0].trim().toLowerCase();
  return type === 'application/json' || type.endsWith('+json');
}

function validCandidate(candidate) {
  return candidate?.semantic_success === true
    && Number.isInteger(candidate.status)
    && candidate.status >= 200 && candidate.status < 300
    && candidate.json === true && isJson(candidate.content_type);
}

export function canRunNegativeControl(candidate, context) {
  return validCandidate(candidate)
    && context?.controlHeader === 'sign'
    && typeof context.expectedRevision === 'string'
    && context.expectedRevision.length > 0
    && context.candidateRevision === context.expectedRevision
    && isFreshSignedRequestTimestamp(context.timestamp, context.now);
}

/**
 * Recorded live evidence identifies an HTTP 400 rejection class, not a stable
 * platform-specific error code (docs/specs/renewable-signing-adapter.md).
 * Do not infer causality from arbitrary divergence, or recognize synthetic error
 * strings as production codes. Context is required before reporting strong proof.
 */
export function classifyDifferentialProof(candidate, negativeControl = null, context = null) {
  if (!validCandidate(candidate)) {
    return { outcome: 'failed', detail: 'Candidate response did not contain the expected semantic shape.' };
  }
  if (!canRunNegativeControl(candidate, context)) {
    return { outcome: 'inconclusive', detail: 'Proof requires a fresh sign-only comparison at the expected revision.' };
  }
  if (negativeControl === null) {
    return { outcome: 'partial', detail: 'Candidate succeeded; no invalid comparison was completed.' };
  }
  if (
    negativeControl.semantic_success !== false
    || negativeControl.status !== 400
    || negativeControl.json !== true
    || !isJson(negativeControl.content_type)
    || negativeControl.rejection_class !== 'observed_bad_request'
    || context.negativeRevision !== context.expectedRevision
  ) {
    return { outcome: 'inconclusive', detail: 'Comparison did not establish the recorded same-revision rejection class.' };
  }
  return {
    outcome: 'strong',
    detail: 'Candidate succeeded and the fresh sign-only comparison matched the recorded HTTP 400 rejection class.',
  };
}
