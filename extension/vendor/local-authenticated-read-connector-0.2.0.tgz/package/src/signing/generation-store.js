import { awaitWithAbort, throwIfAborted } from './async-operation.js';
import { validateRenewableSigningConfig, validateSigningSession } from './renewable-signing.js';
import {
  hasCurrentGenerationProof,
  isCurrentStrongProof,
} from './proof-policy.js';

const STATE_SCHEMA = 'browser-signing-state/v1';
const GENERATION_SCHEMA = 'browser-signing-generation/v1';
const clone = (value) => structuredClone(value);
const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

export class SigningGenerationStoreError extends Error {
  constructor(code, message, options = {}) {
    super(message, options);
    this.name = 'SigningGenerationStoreError';
    this.code = code;
  }
}

function corruptState(cause) {
  return new SigningGenerationStoreError(
    'storage_corrupt', 'Stored browser signing state is corrupt; it was not replaced.', { cause },
  );
}

function validateGeneration(generation) {
  if (
    !isObject(generation)
    || generation.schema !== GENERATION_SCHEMA
    || typeof generation.id !== 'string'
    || generation.id.length === 0
    || typeof generation.created_at !== 'string'
    || Number.isNaN(Date.parse(generation.created_at))
    || generation.proof_outcome !== 'strong'
    || (Object.hasOwn(generation, 'proof_policy_version') && (
      !Number.isSafeInteger(generation.proof_policy_version)
      || generation.proof_policy_version < 0
    ))
  ) throw new TypeError('Browser signing generation is invalid.');
  validateRenewableSigningConfig(generation.config);
  validateSigningSession(generation.context?.session);
  return generation;
}

function validateState(state) {
  if (!isObject(state) || typeof state.schema !== 'string') throw corruptState();
  if (state.schema !== STATE_SCHEMA) {
    throw new SigningGenerationStoreError(
      'storage_schema_unsupported', 'Stored browser signing state uses an unsupported schema.',
    );
  }
  try {
    // v1 documents without a revision are legacy, not missing. Normalize only a
    // detached in-memory copy; initialize() must never migrate by writing.
    if (!Object.hasOwn(state, 'state_revision')) state.state_revision = 0;
    if (!Number.isSafeInteger(state.state_revision) || state.state_revision < 0) {
      throw new TypeError('Invalid state revision.');
    }
    if (state.active !== null) validateGeneration(state.active);
    if (state.previous !== null) validateGeneration(state.previous);
    if (state.active && state.previous && state.active.id === state.previous.id) {
      throw new TypeError('Active and previous signing generations must be distinct.');
    }
  } catch (cause) {
    throw corruptState(cause);
  }
  return state;
}

export function transitionPrecondition(state) {
  return {
    state_revision: state.state_revision,
    active_id: state.active?.id ?? null,
    previous_id: state.previous?.id ?? null,
  };
}

function validatePrecondition(expected) {
  const validId = (id) => id === null || (typeof id === 'string' && id.length > 0);
  if (
    !isObject(expected)
    || !Number.isSafeInteger(expected.state_revision)
    || expected.state_revision < 0
    || !validId(expected.active_id)
    || !validId(expected.previous_id)
  ) throw new TypeError('A state revision and exact generation identities are required.');
  return clone(expected);
}

function assertPrecondition(state, expected) {
  const actual = transitionPrecondition(state);
  if (
    actual.state_revision !== expected.state_revision
    || actual.active_id !== expected.active_id
    || actual.previous_id !== expected.previous_id
  ) {
    throw new SigningGenerationStoreError(
      'lifecycle_conflict', 'Signing state changed during validation; no transition was committed.',
    );
  }
}

function requireProof(proof) {
  if (!isCurrentStrongProof(proof)) {
    throw new SigningGenerationStoreError(
      'proof_policy_required', 'A strong proof under the current proof policy is required.',
    );
  }
}

function generationStatus(generation) {
  return generation === null ? null : {
    id: generation.id,
    created_at: generation.created_at,
    proof_outcome: generation.proof_outcome,
    proof_policy_version: generation.proof_policy_version ?? null,
    requires_validation: !hasCurrentGenerationProof(generation),
  };
}

// One owner/store per persistence document. This queue is NOT cross-instance CAS.
export class AtomicSigningGenerationStore {
  #state = null;
  #initialization = null;
  #writeChain = Promise.resolve();

  constructor({ persistence, now = Date.now, idFactory = () => crypto.randomUUID() }) {
    if (typeof persistence?.load !== 'function' || typeof persistence?.save !== 'function') {
      throw new TypeError('Signing generation persistence requires load and save operations.');
    }
    this.persistence = persistence;
    this.now = now;
    this.idFactory = idFactory;
  }

  async initialize() {
    if (this.#state !== null) return this.snapshot();
    if (this.#initialization === null) {
      // Start in a microtask so even a synchronous load failure clears the exact
      // cached attempt, rather than leaving a rejected promise cached forever.
      const attempt = Promise.resolve().then(async () => {
        let saved;
        try {
          saved = await this.persistence.load();
        } catch (cause) {
          if (cause instanceof SigningGenerationStoreError) throw cause;
          throw new SigningGenerationStoreError(
            'storage_load_failed', 'Browser signing state could not be loaded.', { cause },
          );
        }
        let state;
        try {
          state = saved === null || saved === undefined
            ? { schema: STATE_SCHEMA, state_revision: 0, active: null, previous: null }
            : validateState(clone(saved));
        } catch (cause) {
          if (cause instanceof SigningGenerationStoreError) throw cause;
          throw corruptState(cause);
        }
        this.#state = state;
        return this.snapshot();
      });
      this.#initialization = attempt;
      // The finally result is the shared attempt and is observed by callers.
      this.#initialization = attempt.finally(() => { this.#initialization = null; });
    }
    return this.#initialization;
  }

  snapshot() {
    if (this.#state === null) throw new Error('Signing generation store is not initialized.');
    return clone(this.#state);
  }

  async readState() {
    await this.#writeChain;
    await this.initialize();
    return this.snapshot();
  }

  async active() { return (await this.readState()).active; }
  async previous() { return (await this.readState()).previous; }

  async status() {
    const state = await this.readState();
    return {
      state_revision: state.state_revision,
      active: generationStatus(state.active),
      previous: generationStatus(state.previous),
    };
  }

  async activate({ config, context, reason, proof, summary = {}, expected, signal = null } = {}) {
    throwIfAborted(signal);
    requireProof(proof);
    validateRenewableSigningConfig(config);
    validateSigningSession(context?.session);
    const createdAt = new Date(this.now()).toISOString();
    const generation = validateGeneration({
      schema: GENERATION_SCHEMA,
      id: `${createdAt}-${this.idFactory()}`,
      created_at: createdAt,
      reason,
      proof_outcome: proof.outcome,
      proof_policy_version: proof.policy_version,
      config: clone(config),
      context: clone(context),
      summary: clone(summary),
    });
    // Callers proving across awaits must supply their PRE-proof snapshot. The
    // default keeps direct store calls usable, but captures only call-time state.
    const precondition = expected === undefined
      ? transitionPrecondition(await awaitWithAbort(this.readState(), signal))
      : validatePrecondition(expected);
    return this.#mutate(precondition, (state) => {
      if (state.active?.id === generation.id || state.previous?.id === generation.id) {
        throw new SigningGenerationStoreError('generation_id_conflict', 'Generation ID must be unique.');
      }
      return { ...state, active: generation, previous: state.active };
    }, signal);
  }

  async rollback({ expected, proof, signal = null } = {}) {
    throwIfAborted(signal);
    // Copy all caller-owned inputs before awaiting or entering the write queue.
    const validation = proof === undefined ? undefined : clone(proof);
    if (validation !== undefined) requireProof(validation);
    const precondition = expected === undefined
      ? transitionPrecondition(await awaitWithAbort(this.readState(), signal))
      : validatePrecondition(expected);
    return this.#mutate(precondition, (state) => {
      if (state.previous === null) {
        throw new SigningGenerationStoreError('no_previous', 'No previous signing generation is available.');
      }
      let target = state.previous;
      if (validation !== undefined) {
        target = { ...target, proof_policy_version: validation.policy_version };
      } else if (!hasCurrentGenerationProof(target)) {
        requireProof(undefined);
      }
      return { ...state, active: target, previous: state.active };
    }, signal);
  }

  #mutate(expected, operation, signal) {
    const precondition = validatePrecondition(expected);
    const write = this.#writeChain.then(async () => {
      throwIfAborted(signal);
      // Initialize within the serialized mutation too: a preceding failed save
      // may have invalidated the cache and requires reconciliation from storage.
      await awaitWithAbort(this.initialize(), signal);
      throwIfAborted(signal);
      assertPrecondition(this.#state, precondition);
      if (this.#state.state_revision === Number.MAX_SAFE_INTEGER) {
        throw new SigningGenerationStoreError('state_revision_exhausted', 'Signing state revision is exhausted.');
      }
      const candidate = validateState({
        ...operation(clone(this.#state)),
        state_revision: this.#state.state_revision + 1,
      });
      const document = clone(candidate);
      // Commit point: no await separates this guard from invoking save(). Once
      // save begins it cannot be canceled; retain the write queue until it settles.
      throwIfAborted(signal);
      try {
        await this.persistence.save(document);
      } catch (cause) {
        // save() can commit and then reject. Do not continue from a possibly
        // stale cache; reload before any subsequent transition. No compensating
        // write is safe with a non-transactional load/save adapter.
        this.#state = null;
        throw new SigningGenerationStoreError(
          'storage_save_failed', 'Browser signing state could not be saved; reload is required.', { cause },
        );
      }
      this.#state = candidate;
      // Read the result ONLY from the state this mutation actually committed.
      return clone(this.#state.active);
    });
    this.#writeChain = write.then(() => undefined, () => undefined);
    return awaitWithAbort(write, signal);
  }
}

export class MemorySigningPersistence {
  constructor(initialState = null) {
    this.value = initialState === null ? null : clone(initialState);
  }
  async load() { return this.value === null ? null : clone(this.value); }
  async save(value) { this.value = clone(value); }
}

export { GENERATION_SCHEMA, STATE_SCHEMA };
