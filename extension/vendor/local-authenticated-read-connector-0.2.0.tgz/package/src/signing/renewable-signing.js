import { normalizeSigningHeaders } from './header-policy.js';
import { DEFINITIONS, matchesSigningRequest, ORIGIN } from './operations.js';
import { isSignedRequestTimestamp } from './request-freshness.js';
import { copySigningFormat } from './signing-format.js';
import { MAX_IDENTIFIER_LENGTH, MAX_REVISION_LENGTH, MAX_STATIC_PARAM_LENGTH } from './validation-limits.js';

export const RENEWABLE_SIGNING_SCHEMA = 'local-renewable-signing-config/v1';

const REQUIRED_STATIC_HEADERS = ['app-token', 'x-bc', 'x-of-rev'];

function validateFormat(input) {
  const format = copySigningFormat(input);
  return Object.freeze({
    prefix: format.prefix,
    suffix: format.suffix,
    checksumIndexes: format.checksum_indexes,
    checksumConstant: format.checksum_constant,
  });
}

function validStaticParam(value) {
  return typeof value === 'string' && value.length > 0 && value.length <= MAX_STATIC_PARAM_LENGTH
    && !/[\x00-\x1f\x7f]/.test(value);
}

export function validateRenewableSigningConfig(config) {
  if (
    !config ||
    config.schema !== RENEWABLE_SIGNING_SCHEMA ||
    typeof config.source_revision !== 'string' ||
    config.source_revision.length === 0 ||
    config.source_revision.length > MAX_REVISION_LENGTH ||
    /[^\x21-\x7e]/.test(config.source_revision) ||
    !validStaticParam(config.static_param) ||
    typeof config.headers !== 'object' ||
    config.headers === null ||
    Array.isArray(config.headers)
  ) {
    throw new TypeError('Renewable signing configuration is invalid.');
  }

  const headers = normalizeSigningHeaders(config.headers, { staticOnly: true });
  for (const name of REQUIRED_STATIC_HEADERS) {
    if (!Object.hasOwn(headers, name)) {
      throw new TypeError(`Renewable signing configuration is missing ${name}.`);
    }
  }
  if (headers['x-of-rev'] !== config.source_revision) {
    throw new TypeError('Signing source revision does not match x-of-rev.');
  }

  return Object.freeze({
    schema: config.schema,
    sourceRevision: config.source_revision,
    staticParam: config.static_param,
    format: validateFormat(config.format),
    headers: Object.freeze(headers),
  });
}

export function validateSigningSession(session) {
  if (!session || typeof session.userId !== 'string' || session.userId.length > MAX_IDENTIFIER_LENGTH
    || !/^[1-9]\d*$/.test(session.userId)) {
    throw new TypeError('Renewable signing requires a bounded positive decimal session userId.');
  }
  return session.userId;
}

export function validateSigningRequest(method, url) {
  if (!(url instanceof URL) || typeof method !== 'string' || method !== 'GET') {
    throw new TypeError('Renewable signing accepts typed GET operations only.');
  }
  const supported = Object.keys(DEFINITIONS).some((operation) => matchesSigningRequest(operation, url, method));
  if (!supported) {
    throw new TypeError('Renewable signing request is outside the typed read-operation boundary.');
  }
}

export function createSigningInput({ config, path, timestamp, userId }) {
  if (!validStaticParam(config?.staticParam)) {
    throw new TypeError('Signing static parameter is invalid.');
  }
  if (typeof path !== 'string' || !path.startsWith('/api2/v2/') || /[\x00-\x20\x7f]/.test(path)) {
    throw new TypeError('Signing path is invalid.');
  }
  const url = new URL(path, ORIGIN);
  validateSigningRequest('GET', url);
  if (`${url.pathname}${url.search}` !== path) {
    throw new TypeError('Signing path must not be normalized after signing.');
  }
  if (!isSignedRequestTimestamp(timestamp)) {
    throw new TypeError('Signing timestamp is invalid.');
  }
  validateSigningSession({ userId });
  return [config.staticParam, timestamp, path, userId].join('\n');
}

export function createSignatureFromDigest({ config, digest }) {
  if (typeof digest !== 'string' || !/^[0-9a-f]{40}$/i.test(digest)) {
    throw new TypeError('Signing digest must be a SHA-1 hexadecimal value.');
  }
  // This helper is public: validate arithmetic even without a validated config.
  const format = copySigningFormat({
    prefix: config?.format?.prefix,
    suffix: config?.format?.suffix,
    checksum_indexes: config?.format?.checksumIndexes,
    checksum_constant: config?.format?.checksumConstant,
  });
  // Character-code checksums operate on the same lowercase hex that is emitted.
  // Prefix/suffix are opaque rule data and retain their original capitalization.
  const normalizedDigest = digest.toLowerCase();
  const checksum = Math.abs(format.checksum_indexes.reduce(
    (sum, index) => sum + normalizedDigest.charCodeAt(index), format.checksum_constant,
  )).toString(16);
  return [format.prefix, normalizedDigest, checksum, format.suffix].join(':');
}

export function createPortableRenewableAdapter({ config, sha1Hex }) {
  if (typeof sha1Hex !== 'function') throw new TypeError('A SHA-1 digest provider is required.');
  const validated = validateRenewableSigningConfig(config);
  return {
    id: 'runtime-derived-renewable-signing',
    async prepare({ method, url, session, now }) {
      validateSigningRequest(method, url);
      const userId = validateSigningSession(session);
      const currentTime = now();
      if (!Number.isSafeInteger(currentTime) || currentTime <= 0) {
        throw new TypeError('Renewable signing clock returned an invalid timestamp.');
      }
      const timestamp = String(currentTime);
      const path = `${url.pathname}${url.search}`;
      const input = createSigningInput({
        config: validated,
        path,
        timestamp,
        userId,
      });
      const digest = await sha1Hex(input);
      const sign = createSignatureFromDigest({ config: validated, digest });
      return {
        headers: {
          ...validated.headers,
          'user-id': userId,
          time: timestamp,
          sign,
        },
        controlHeaders: ['sign'],
        diagnostics: {
          revision: validated.sourceRevision,
          checksumIndexCount: validated.format.checksumIndexes.length,
        },
      };
    },
  };
}

export async function webCryptoSha1Hex(input, cryptoApi = globalThis.crypto) {
  if (!cryptoApi?.subtle) throw new Error('Web Crypto SHA-1 support is unavailable.');
  const digest = await cryptoApi.subtle.digest('SHA-1', new TextEncoder().encode(input));
  return [...new Uint8Array(digest)]
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('');
}
