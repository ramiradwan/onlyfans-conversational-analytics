import { IntentValidationError } from '../errors.js';
import {
  decodeMessageContinuation,
  isMessageContinuation,
} from './message-continuation.js';

const ORIGIN = 'https://onlyfans.com';
const MAX_PAGE_LIMIT = 100;
const MAX_CURSOR_LENGTH = 512;
const MAX_CONVERSATION_ID_LENGTH = 128;
const SAFE_CURSOR = /^[A-Za-z0-9._~-]+$/;
const SAFE_CONVERSATION_ID = /^[A-Za-z0-9_-]+$/;
const SAFE_MESSAGE_ID = /^[1-9]\d{0,255}$/;

function requirePlainObject(value, label) {
  if (typeof value !== 'object' || value === null || Array.isArray(value)
    || ![Object.prototype, null].includes(Object.getPrototypeOf(value))
    || Reflect.ownKeys(value).some((key) => typeof key !== 'string'
      || !Object.hasOwn(Object.getOwnPropertyDescriptor(value, key), 'value'))) {
    throw new IntentValidationError(`${label} must be an object.`);
  }
  return value;
}

function rejectUnknownKeys(value, allowedKeys, label) {
  const unknown = Object.keys(value).filter((key) => !allowedKeys.has(key));
  if (unknown.length > 0) {
    throw new IntentValidationError(`${label} contains an unsupported field.`);
  }
}

function normalizePageQuery(query, { operation = null, conversationId = null } = {}) {
  if (query === undefined) return {};
  requirePlainObject(query, 'Operation query');
  rejectUnknownKeys(query, new Set(['limit', 'cursor']), 'Operation query');

  const normalized = {};
  if (query.limit !== undefined) {
    if (!Number.isSafeInteger(query.limit) || query.limit < 1 || query.limit > MAX_PAGE_LIMIT) {
      throw new IntentValidationError(
        `Operation query limit must be an integer from 1 through ${MAX_PAGE_LIMIT}.`,
      );
    }
    normalized.limit = String(query.limit);
  }
  if (query.cursor !== undefined && query.cursor !== null) {
    if (!isUsableContinuation(query.cursor)) {
      throw new IntentValidationError('Operation query cursor is not a safe opaque token.');
    }
    normalized.cursor = query.cursor;
    if (isMessageContinuation(query.cursor)) {
      if (operation !== 'message-page') {
        throw new IntentValidationError('Message continuation is only valid for message-page.');
      }
      try {
        normalized.id = decodeMessageContinuation(query.cursor, conversationId);
      } catch {
        throw new IntentValidationError('Operation query cursor is not a valid message continuation.');
      }
    } else {
      // Reduced fixtures and existing consumers continue to use the offset wire parameter.
      normalized.offset = query.cursor;
    }
  }
  return normalized;
}

const DEFINITIONS = Object.freeze({
  identity: {
    pathPattern: /^\/api2\/v2\/users\/me\/?$/,
    buildPath() {
      return '/api2/v2/users/me';
    },
    expectedJsonKey: 'id',
    expectedKind: 'present',
    boundary: null,
    validateParameters(parameters) {
      requirePlainObject(parameters, 'identity parameters');
      rejectUnknownKeys(parameters, new Set(), 'identity parameters');
      return {};
    },
  },
  conversations: {
    pathPattern: /^\/api2\/v2\/chats\/?$/,
    buildPath() {
      return '/api2/v2/chats';
    },
    expectedJsonKey: 'list',
    expectedKind: 'array',
    boundary: 'inventory_end',
    validateParameters(parameters) {
      requirePlainObject(parameters, 'conversations parameters');
      rejectUnknownKeys(parameters, new Set(['query']), 'conversations parameters');
      return { query: normalizePageQuery(parameters.query, { operation: 'conversations' }) };
    },
  },
  'message-page': {
    pathPattern: /^\/api2\/v2\/chats\/[^/]+\/messages\/?$/,
    buildPath(parameters) {
      const conversationId = parameters.conversationId;
      if (
        typeof conversationId !== 'string' ||
        conversationId.length < 1 ||
        conversationId.length > MAX_CONVERSATION_ID_LENGTH ||
        !SAFE_CONVERSATION_ID.test(conversationId)
      ) {
        throw new IntentValidationError('message-page requires an alphanumeric conversationId.');
      }
      return `/api2/v2/chats/${encodeURIComponent(conversationId)}/messages`;
    },
    expectedJsonKey: 'messages',
    expectedKind: 'array',
    boundary: 'history_start',
    validateParameters(parameters) {
      requirePlainObject(parameters, 'message-page parameters');
      rejectUnknownKeys(
        parameters,
        new Set(['conversationId', 'query']),
        'message-page parameters',
      );
      const conversationId = parameters.conversationId;
      if (
        typeof conversationId !== 'string' ||
        conversationId.length < 1 ||
        conversationId.length > MAX_CONVERSATION_ID_LENGTH ||
        !SAFE_CONVERSATION_ID.test(conversationId)
      ) {
        throw new IntentValidationError('message-page requires an alphanumeric conversationId.');
      }
      return {
        conversationId,
        query: normalizePageQuery(parameters.query, { operation: 'message-page', conversationId }),
      };
    },
  },
});

export function getOperation(name) {
  const definition = typeof name === 'string' && Object.hasOwn(DEFINITIONS, name) ? DEFINITIONS[name] : null;
  if (!definition) {
    throw new IntentValidationError(
      'Unknown operation. Expected identity, conversations, or message-page.',
    );
  }
  return definition;
}

export function buildOperationRequest(name, parameters = {}) {
  const definition = getOperation(name);
  const normalized = definition.validateParameters(parameters);
  const url = new URL(definition.buildPath(normalized), ORIGIN);
  const query = normalized.query ?? {};
  for (const [key, value] of Object.entries(query)) {
    if (key !== 'cursor') url.searchParams.set(key, value);
  }
  // Match the native descending message read shape. This is an internal wire
  // field; callers continue to express continuation through the opaque cursor.
  if (name === 'message-page') url.searchParams.set('order', 'desc');
  return { operation: name, method: 'GET', url };
}

// Development artifacts use route classification, not transmission authorization.
export function matchesOperation(name, rawUrl, method = 'GET') {
  try {
    const url = new URL(rawUrl);
    return typeof method === 'string' && method.toUpperCase() === 'GET'
      && url.origin === ORIGIN && getOperation(name).pathPattern.test(url.pathname);
  } catch { return false; }
}

// Snapshot before asynchronous work; accessors and symbols are rejected above.
export function snapshotOperationParameters(name, parameters = {}) {
  const normalized = getOperation(name).validateParameters(parameters);
  const result = {};
  if (name === 'message-page') result.conversationId = normalized.conversationId;
  if (name !== 'identity') {
    const query = {};
    if (normalized.query.limit !== undefined) query.limit = Number(normalized.query.limit);
    if (normalized.query.cursor !== undefined) query.cursor = normalized.query.cursor;
    else if (normalized.query.offset !== undefined) query.cursor = normalized.query.offset;
    result.query = Object.freeze(query);
  }
  return Object.freeze(result);
}

export function isUsableContinuation(value) {
  return typeof value === 'string' && value.length >= 1
    && value.length <= MAX_CURSOR_LENGTH && SAFE_CURSOR.test(value);
}

// This is the executable wire contract; MAIN mirrors it without imported bindings.
export function matchesSigningRequest(name, rawUrl, method = 'GET') {
  try {
    if (typeof method !== 'string' || method !== 'GET') return false;
    if (typeof rawUrl === 'string' && /[\x00-\x20\x7f]/.test(rawUrl)) return false;
    const url = new URL(rawUrl);
    if (url.origin !== ORIGIN || url.username || url.password || url.href.includes('#')
      || !getOperation(name).pathPattern.test(url.pathname)) return false;
    if (name === 'message-page') {
      const id = url.pathname.split('/')[4];
      if (id.length > MAX_CONVERSATION_ID_LENGTH || !SAFE_CONVERSATION_ID.test(id)) return false;
    }
    const query = url.searchParams;
    const keys = [...query.keys()];
    if (name === 'identity') return keys.length === 0;
    const allowedKeys = name === 'message-page'
      ? ['limit', 'cursor', 'offset', 'id', 'order']
      : ['limit', 'cursor', 'offset'];
    if (new Set(keys).size !== keys.length
      || keys.some((key) => !allowedKeys.includes(key))
      || (query.has('cursor') && query.has('offset'))
      || (query.has('id') && (query.has('cursor') || query.has('offset')))
      || (query.has('id') && name !== 'message-page')) return false;
    if (query.has('order') && query.get('order') !== 'desc') return false;
    if (query.has('id') && !query.has('order')) return false;
    if (query.has('limit')) {
      const value = query.get('limit');
      if (!/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value))
        || Number(value) > MAX_PAGE_LIMIT) return false;
    }
    if (query.has('id') && !SAFE_MESSAGE_ID.test(query.get('id'))) return false;
    if (['cursor', 'offset'].some((key) => query.has(key)
      && isMessageContinuation(query.get(key)))) return false;
    return ['cursor', 'offset'].every((key) => !query.has(key) || isUsableContinuation(query.get(key)));
  } catch { return false; }
}

export function expectedResponse(name) {
  const definition = getOperation(name);
  return {
    key: definition.expectedJsonKey,
    kind: definition.expectedKind,
    boundary: definition.boundary,
  };
}

export {
  DEFINITIONS,
  MAX_CURSOR_LENGTH,
  MAX_PAGE_LIMIT,
  ORIGIN,
  SAFE_CURSOR,
};
