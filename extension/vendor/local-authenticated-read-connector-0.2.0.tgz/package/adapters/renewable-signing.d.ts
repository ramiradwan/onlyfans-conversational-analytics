import type { PortableRenewableAdapter, RenewableSigningConfig, ValidatedSigningConfig } from '../src/signing/index.js';
export { RENEWABLE_SIGNING_SCHEMA, validateRenewableSigningConfig } from '../src/signing/index.js';
export function createRequestSignature(input: {
  config: ValidatedSigningConfig; path: string; timestamp: string; userId: string;
}): string;
export function createAdapter(options: { config: RenewableSigningConfig }): PortableRenewableAdapter;
