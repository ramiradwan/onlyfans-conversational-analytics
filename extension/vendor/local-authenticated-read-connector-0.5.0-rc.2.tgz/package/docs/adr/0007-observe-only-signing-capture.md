# ADR 0007: Observe signing material without reloading user tabs

- Status: accepted for candidate implementation; publication requires qualification
- Date: 2026-10-08

## Context

Legacy refresh deliberately reloads a hidden, draft-free OnlyFans tab. Onboarding
must attach to an existing tab without disrupting its document, scroll, draft or
focus. A quiet existing document may emit no identity request, so observation
alone cannot promise success. Reloading that document is not an acceptable fallback.

## Decision

Add `captureMode: 'observe-only'` to the provider and Chrome factory. The existing
default is `safe-reload`, preserving behavior for older clients. Observe-only
passes `reload: false` to both operation creation and identity capture, including
refresh after revision mismatch. Capture timeout, context loss, cancellation,
signature failure, unsupported revision and account mismatch never change that
policy. Packaged-rule reproduction, differential proof, account checks, document
fencing and conditional activation remain mandatory.

If the consuming extension decides a helper is needed, the Chrome factory accepts
`ownedHelper: { helperPagePath, onCreated }`. The host itself creates one inactive
tab at the extension's empty packaged page and records ownership through the
callback before proceeding. Only this creation path mints private, one-use
initial-navigation authority. Caller-provided tab IDs, booleans and restored
ownership records cannot authorize navigation.

The host waits for its own extension context using a subscribed `tabs.onUpdated`
listener and a snapshot, with bounded cancellation and no polling. After the
initial extension page finishes loading, it records the browser-supplied document
ID. Before the one fixed navigation to
`https://onlyfans.com/`, it registers identity observation, checks that the tab is
still inactive, and verifies the exact extension URL and document ID through
`runtime.getContexts`. The response must complete in the resulting top-level
OnlyFans document; all later proofs and reads stay bound to that document.
Failure consumes the initial-navigation capability; retry never navigates again.

`tabs.get` can omit even the extension's own page URL without the broad `tabs`
permission. `runtime.getContexts` avoids adding that permission and requires
Chrome 116 or later. Existing-document observation and legacy behavior retain
the Chrome 106 baseline. A helper request on an unsupported browser fails before
creating a tab. The product's Chrome 132 minimum supports both paths.

The extension owns the decision to create at most one helper, its durable ownership
record, consent/account generations, user-interaction cancellation, close/reuse
policy and eventual cleanup. The signer never focuses, closes, or reopens tabs.
A late creation callback still records ownership after cancellation, but cannot
start navigation. Chrome has no atomic conditional-navigation API: the final
metadata check and `tabs.update` are separate calls. A consumer must cancel when
the helper is touched; that race must not be represented as atomic safety.

## Consequences and qualification

- Existing user tabs receive no navigation, reload, visibility change or draft
  inspection in observe-only mode. A quiet tab times out honestly.
- Signing material stays inside extension-owned memory/persistence. No hosted
  onboarding payload, navigation reference or diagnostic gains signing headers.
- The additional APIs are structural optional fields, so existing injected hosts
  and Promise-only proxies remain compatible. Helper consumers must forward
  `runtime.getContexts`, `tabs.onUpdated`, `tabs.create/get/update`.
- Synthetic browser tests use the installed package and actual browser APIs,
  verify draft/scroll/focus/document preservation, and record tab operations.
  They do not claim live-account or current-platform-rule qualification.
- Release evidence must bind the candidate's exact committed bytes. Historical
  receipts for earlier versions cannot qualify this capability.

See [the integration contract](../specs/observe-only-capture.md) and the
[existing release gates](../specs/release-qualification.md).
