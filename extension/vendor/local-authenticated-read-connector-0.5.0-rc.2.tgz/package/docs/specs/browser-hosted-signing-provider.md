# Browser-hosted signing provider

## Purpose

The browser-hosted provider is the production-facing boundary intended for a Chrome MV3 extension. It keeps the authenticated session in the creator's normal browser, prepares renewable signatures locally, performs only typed reads in the OnlyFans MAIN world, and returns validated response data to its caller in memory.

The existing CDP commands remain development tools and the live-validation oracle. A production extension does not enable remote debugging, create a dedicated profile, or run the CLI.

## Public module

The package exposes the browser-safe implementation at:

```js
import {
  createChromeBrowserSigningProvider,
} from 'local-authenticated-read-connector/browser-signing';
import { PACKAGED_SIGNING_RULE } from './packaged-signing-rule.js';

const signer = await createChromeBrowserSigningProvider({
  chromeApi: chrome,
  packagedRule: PACKAGED_SIGNING_RULE,
  expectedIdentity: verifiedPlatformCreatorId,
});
const controller = new AbortController();
const result = await signer.read({
  operation: 'conversations',
  parameters: { query: { limit: 10 } },
  refreshMode: 'allow',
  signal: controller.signal,
});

if (result.success) {
  await ingestTypedConversationResponse(result.data);
}
```

The package import and `PACKAGED_SIGNING_RULE` must be bundled into the extension. A packaged rule
uses schema `local-packaged-signing-rule/v1` and contains exactly `source_revision`, `static_param`,
and `format`. The factory rejects a missing rule. The rule is an executable release input,
not remotely hosted configuration.

```js
export const PACKAGED_SIGNING_RULE = Object.freeze({
  schema: 'local-packaged-signing-rule/v1',
  source_revision: '<exact-supported-x-of-rev>',
  static_param: '<reviewed-static-parameter>',
  format: {
    prefix: '<reviewed-prefix>',
    suffix: '<reviewed-suffix>',
    checksum_indexes: [/* reviewed indexes from 0 through 39 */],
    checksum_constant: 0,
  },
});
```

Do not put `accept`, `app-token`, `x-bc`, `sign`, `time`, `user-id`, cookies, or account data in this
artifact. The host observes the non-cookie per-browser values during explicit history setup.

## Host requirements

The reference Chrome host requires these MV3 permissions:

```json
{
  "permissions": ["storage", "scripting", "webRequest"],
  "host_permissions": ["https://onlyfans.com/*"]
}
```

The signer calls `chrome.tabs.query` and `chrome.tabs.reload`, but it does not require the broad `tabs` permission. Chrome exposes those methods without that declaration, and the exact OnlyFans host permission supplies the URL access needed by the query. A consuming extension should retain `tabs` only if another feature needs unrestricted sensitive tab metadata.

`webRequest` is observation-only. It captures the approved non-cookie identity headers during rule refresh. It does not use `webRequestBlocking`, alter browser traffic, export cookies, or observe arbitrary origins.

`chrome.scripting.executeScript` uses a closure-free ISOLATED-world top-frame probe to obtain
Chrome-owned document metadata, and document-targeted MAIN-world functions for typed reads,
safe-refresh inspection, and cancellation. The reference host requires Chrome 106+ document
metadata; missing metadata fails closed rather than falling back to tab-only targeting. HTTP reads
remain restricted to `identity`, `conversations`, and `message-page`. Production never inspects
webpack state, invokes page-loaded module factories, or derives executable logic from the site.
See [browser document context](browser-document-context.md) for operation binding, the consumer
proxy contract, identity enforcement, and the non-atomic check-to-reload boundary.

The typed executor uses browser-managed credentials. It rejects arbitrary destinations, mutation methods, cookie headers, authorization headers, transport headers, and unknown candidate headers.

## Permission constraints

| Permission or capability | Signer requirement | Constraint |
| --- | --- | --- |
| `storage` | Required | Signing state is small and fits ordinary `chrome.storage.local`; do not request `unlimitedStorage` for the signer. |
| `scripting` | Required by the reference host | Needed for direct result-returning MAIN-world execution. A static MAIN-world content script could replace it, but would require a separately secured message bridge. |
| `webRequest` | Required by the reference host | Used only while observing one identity request. It may increase Chrome Web Store privacy scrutiny even though no request is changed. |
| `https://onlyfans.com/*` | Required | Chrome host match patterns cannot meaningfully narrow access to API path prefixes. This is the principal user-facing site-access grant. |
| `tabs` | Not required by the signer | Keep it only when another extension feature needs unrestricted tab URL/title metadata. |
| `cookies` | Prohibited | Cookies stay browser-managed and are never read or exported. |
| `debugger`, `nativeMessaging`, `webRequestBlocking` | Not required | Production integration must not inherit the CDP development mechanism or traffic-modification privileges. |
| `alarms`, `offscreen` | Not required by the signer | A consuming extension may need scheduling separately, but should not add either merely to keep a worker alive. |

For the lowest-friction install, declare the single-domain OnlyFans host permission directly because the extension cannot function without it. Moving it to `optional_host_permissions` trades the install-time site warning for an additional user gesture and runtime permission prompt during connection.

Production builds should remove localhost and placeholder origins, use exact HTTPS/WSS backend origins, and restrict `externally_connectable` to the exact analytics application origin. None of those backend permissions are required by this signer package itself.

## Refresh lifecycle

1. Select one inactive OnlyFans tab and its current top-level document; verify hidden/draft-free safety.
2. Register capture observers, recheck the same document and reload safety, then dispatch one reload. Correlate the exact `GET /api2/v2/users/me` capture to its active top-level document and confirm that document is current.
3. Keep only the approved candidate headers; cookies and browser transport headers are discarded at capture time.
4. Require the request and response `x-of-rev` values to match an exact build-packaged rule.
5. Reproduce the observed browser signature independently with the packaged rule. For native page reloads where `GET /api2/v2/users/me` is issued without a `user-id` header, reproduction uses internal bootstrap signing identity `'0'` and requires a bounded positive decimal `expectedIdentity`.
6. Target the captured document for the candidate identity read and corrupted-sign comparison; verify the returned document metadata and every successful identity response.
7. Require the [bounded differential proof policy](failure-classification-and-proof.md), including fresh sign-only HTTP 400 rejection and candidate/control revision agreement.
8. Check context around the conditional store activation. Preserve the single-writer and non-cancelable-save limits; a context check and a storage write are not atomic.

### Native identity bootstrap

Page-native reload traffic for `GET /api2/v2/users/me` emits a four-field signature but omits the `user-id` request header (both in ordinary network events and wire extra-info). To support native bootstrap without weakening session security:

- **Mandatory expected identity for missing-header bootstrap**: When page-native reload captures omit the `user-id` header, `expectedIdentity` is mandatory and establishes the positive identity of the generation. It must be a safe positive integer or a bounded positive decimal string of up to `MAX_IDENTIFIER_LENGTH` (256 ASCII characters) with no leading zero (rejecting `'0'`, `0`, negative numbers, floats, leading zeros, or opaque/invalid formats). If `expectedIdentity` is omitted or invalid for absent-header bootstrap, refresh fails closed with `packaged_rule_mismatch` before any proof requests or state activation. For captures containing an explicit positive `user-id` header, constructor options accept `expectedIdentity` (including non-empty opaque string identifiers), where any mismatch against the captured identity yields `account_mismatch`.
- **Internal bootstrap signing identity**: Signature reproduction for absent-`user-id` captures uses internal bootstrap identity `'0'`, which matches the native site's 4-field signing input (`static_param\ntime\npath\n0`).
- **No zero in ordinary sessions or headers**: The derived generation context sets its session `userId` to `expectedIdentity`. `'0'` is strictly forbidden in stored generations, session validation (`validateSigningSession`), ordinary signing inputs (`createSigningInput`), and outgoing request headers. A capture containing an explicit header `user-id: '0'` is rejected with `TypeError`.
- **Identity verification during proof**: The candidate read sends typed requests using the derived generation (`userId = expectedIdentity`). The response must return `200` with the matching positive account identity. Any identity mismatch fails closed immediately with `account_mismatch`, preventing generation activation and aborting proof before the negative control request is issued.

Unbound refreshes are coalesced within one provider instance. A read already bound to a document keeps that context during recovery instead of joining an unrelated refresh or selecting a different tab. Canceling one waiter does not cancel a refresh still needed by another waiter. Missing/non-packaged state or a successful typed response with a missing/different revision permits one refresh, including bootstrap in that budget. Unsuccessful responses (including 401/403, 429 and 5xx) do not establish signing drift and are returned without automatic refresh. A successful page still lacking revision agreement after recovery is not returned. `refreshMode: "never"` reports that refresh is required without capturing or reloading. An unrecognized revision returns `unsupported_revision` and requires an extension update; there is no remote rule feed, background watcher, or unbounded retry.

## Private state

The standalone Chrome persistence adapter stores one `browser_signing_state_v1` document containing only the active and previous generations. One `chrome.storage.local.set` replaces the complete document, so a failed write cannot partially update pointers. Startup validates the entire stored document before use. Product integrations may instead pass an explicit `{ load, save }` persistence adapter to `createChromeBrowserSigningProvider`; this is how account-partitioned hosts keep signing generations in the account's own durable store and avoid installation-global account state.

The factory requests `TRUSTED_CONTEXTS` storage access when the Chrome version supports it. Observed non-cookie signing headers and authenticated user context remain private extension state. They are never sent to content scripts, page messages, the analytics backend, logs, or status reports.

## Response-data boundary

Unlike the diagnostic CDP probe, a successful browser-hosted read returns the parsed typed response as `result.data`. This is necessary for a separate extension to normalize and enqueue analytics observations.

Successful response objects are exact schemas. Unknown top-level or nested fields, conflicting
aliases, malformed identifiers/timestamps, pages above 100 items, and message text above the
bounded entity budget make the response semantically invalid. Accepted upstream aliases are
reduced immediately to these canonical in-memory entities:

```text
identity:     { id }
conversation: { id, platform_user_id, display_name, updated_at, head_message_id?, head_sent_at? }
message:      { id, chat_id, sender_platform_user_id, text, sent_at, direction }
page:         { items, continuation, boundary }
```

For message pages, `chat_id` comes from the requested conversation id; it is null only when that
request context is unavailable, never because of a response-side fallback. A conflicting response
chat-id alias rejects the page. `direction` may be null when the consuming account-bound adapter
cannot derive it from the verified creator identity. No raw response wrapper or unrecognized field
crosses this boundary.

A successful result includes only the typed `data`, the active generation identifier, whether and why one refresh occurred, and a bounded public response summary. The response also includes additive, allowlisted `failure_code` and `validation_error` diagnostics outside `data`. For `429`, `response.retry_after_ms` is clamped to at most one hour; it is null for other statuses. Callers may cancel reads, refreshes, or rollback validation with an `AbortSignal`.

Before the typed MAIN-world executor calls `fetch`, it validates the signed `time` header as a
canonical decimal spelling (no leading zeros; `0` itself is syntactically valid) and rejects a
request unless `abs(pageClock − signerTimestamp) <= 30 s`; exactly 30 seconds is accepted. A page
clock running behind the signer widens the effective acceptance window. That is the final
no-transmit check, so an extension-worker suspension or delay between provider preparation and
MAIN-world execution cannot send a stale request. The diagnostic CDP probe carries the same check
inside its serialized, dispatched browser function immediately before `fetch`, rather than
checking before `Runtime.evaluate` dispatch. The 30-second value is derived
solely from this repository's
`SimulatedPlatform` request-age check (`src/simulated-platform.js`); it is not a verified
OnlyFans acceptance window.

After this check, resolving `url.toString()`, `controller.signal`, and `fetch` still touches
page-realm globals that page code can replace or delay; this boundary is not intrinsic-hardened.

The signer itself:

- never persists response bodies;
- never prints response bodies;
- drops bodies for unsuccessful or semantically invalid responses;
- does not define analytics schemas, pairing, backend transport, ingestion, or account enrollment.

Those responsibilities belong to the consuming application. This repository provides only authenticated typed reads and signing-rule lifecycle management.

## Service-worker restart behavior

MV3 service workers may stop at any time. On the next wake, construct the provider again. It reloads and validates the active/previous document from `chrome.storage.local`; an ordinary read then proceeds without capture or reload. If state is missing or invalid, the provider fails closed or performs the normal strongly validated bootstrap.

The reference identity-capture timeout is 20 seconds, below Chrome's normal idle-worker window. Identity traffic should occur immediately after reload; a missing request fails visibly rather than attempting to keep the worker alive. Signature reproduction and proof use packaged logic and bounded Chrome API activity.

`chrome.storage.local` is appropriate for the two small signing generations, but not for an analytics message archive or durable full-history outbox. The consuming extension should place bulk conversation data in IndexedDB and keep only compact coordination state in extension storage.

Typed response bodies cross the MAIN-world execution boundary as structured results. Callers should use bounded page sizes and incremental pagination to avoid large single execution results.

## Integration acceptance criteria

Before a consuming extension adopts this provider, its integration tests must prove:

1. signer code and the supported rule are bundled locally and no remote executable code is loaded;
2. signing storage is unavailable to content scripts;
3. the MAIN-world call always uses `world: "MAIN"` and a typed operation;
4. passive or proactive response data is normalized before durable ingestion;
5. the extension does not expose a mutation command through the signer;
6. service-worker restart reuses a validated generation;
7. logged-out or unavailable browser state preserves the last-known-good generation;
8. no cookie, observed signing header, user ID, or response body enters logs or backend protocol frames;
9. an unsupported `x-of-rev` fails closed and no runtime/webpack discovery module exists in the shipped executable surface.
