# Observe-only capture integration

This additive API first ships in candidate `0.2.1-rc.1`, built directly on released
`0.2.0` (`672ba94db26aa582451c817ec72a04304a2a238c`). It preserves the canonical
conversation/message records and excludes the intervening typed-history changes
from the separate `0.5` development line. Existing APIs/default behavior remain.

## Release history

`0.5.0-rc.2` retains the history event kinds from `0.5.0-rc.1` and adds
observe-only capture mode for products that opt in. `safe-reload` remains the
default. This combined prerelease includes the observe-only changes from #18
alongside the history event kinds already on main. The separately published
`0.2.1-rc.1` remains unchanged.

## Existing tab first

```js
const signer = await createChromeBrowserSigningProvider({
  chromeApi, packagedRule, persistence, expectedIdentity,
  tabId: onlyFansTabId,
  captureMode: 'observe-only',
  captureTimeoutMs: 5000,
  signal,
});
await signer.read({ operation: 'identity', signal });
```

The host observes a future native identity request from the current top-level
document. It does not trigger page navigation or inspect page signing internals.
A stored, currently proved generation can execute a typed read immediately.
An idle document without a generation may time out. Never interpret timeout as
permission to reload; the extension may select its single owned helper below.

## One owned helper when needed

Package an empty `signing-helper.html` inside the extension (no remote script or
web-accessible-resource declaration is needed). The extension's recovery owner
must serialize this decision and restore existing ownership after worker restart.

```js
const signer = await createChromeBrowserSigningProvider({
  chromeApi, packagedRule, persistence, expectedIdentity,
  captureMode: 'observe-only',
  ownedHelper: {
    helperPagePath: 'signing-helper.html',
    onCreated: async (tabId) => persistOwnedHelper({ tabId }),
  },
  signal,
});
await signer.read({ operation: 'identity', signal });
```

`ownedHelper` cannot be combined with `tabId` or `safe-reload`. The callback is
mandatory, runs before navigation, and can run after cancellation if Chrome's
creation acknowledgement arrives late. Keep it reliable and idempotent. A failed
callback aborts setup; the signer does not delete a tab whose ownership is uncertain.

`ChromeMainWorldSigningHost.createForOwnedHelper` exposes the same capability for
consumers constructing `BrowserSigningProvider` directly. Its `tabId` identifies
the created tab. New helper creation is not restart recovery: a restored helper
uses the normal constructor with `tabId` and observe-only, without navigation.

The owned helper requires Chrome 116+ `runtime.getContexts`, plus normal tab
creation/update APIs and `tabs.onUpdated`. Broad `tabs` permission is unnecessary.
The extension still needs the existing OnlyFans host permission, `webRequest`
and `scripting` consent before capture. Browser-owned document metadata and
packaged signing rules remain required. Account, document or consent changes
must cancel the consumer's operation and retire its results.

## User-facing state and limits

The extension explains its background tab once, including what closing it does.
Closing it is respected; recovery does not reopen it automatically. The signer
does not own that copy or lifecycle. No capture result itself establishes the
application's consent or account authority.

An absent `user-id` on native bootstrap is valid only through the existing
packaged-rule bootstrap policy. A wrong expected identity can therefore produce
`activation_proof_failed` rather than `account_mismatch`; both refuse activation.
Keep user-facing creator identity based on the consumer's verified identity facts.

The scope of synthetic qualification is exact API behavior and refusal/preservation
properties. Live platform behavior, unknown upstream revisions, packaged rule
updates and the consuming extension's complete recovery journey require their
separate existing qualification gates.
