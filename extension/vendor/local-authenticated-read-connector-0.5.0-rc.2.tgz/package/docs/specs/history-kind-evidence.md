# History kind evidence

`readHistoryWithEvidence()` wraps the ordinary provider history read and an
aligned, bounded observation sidecar. Every accepted record in either method
also carries the separate [client-parity kind](history-event-kind.md) under
`event_kind`. The observation contract below remains immutable; its legacy
interpretation remains unknown and must not override the new per-record kind.

## Read interface

Use the public installed-package import shown in [history record kind](history-event-kind.md),
then call `provider.readHistoryWithEvidence({ parameters: { conversationId },
refreshMode: 'never', signal })`. It fixes the operation to `message-page` and
returns `{ schema: "browser-signing-history-evidence-read/v1", read, evidence }`.

A failed read has null data and evidence. A successful read has exactly one
evidence row per returned record, in order; an empty page has an empty list.
Projection failure never rejects, filters or reorders accepted records. The
provider diagnostic observes the inner read once and receives no source values.
Only the final accepted attempt supplies returned data and evidence after the
existing cancellation, account and signing-revision checks.

Public declarations include `HistoryWithEvidenceRequest`,
`HistoryWithEvidenceResult`, `HistoryKindEvidence` and
`HistoryKindFieldObservation`. Source extraction runs after whole-page parsing,
while the bounded original response is still available. The standalone parser,
Chrome transport and canonical acceptance limits remain unchanged.

## Immutable observation contract

The sidecar has schema `connector-event-kind/v2`, lexical mapping
`onlyfans-event-kind/0.2.0`, and legacy status `no-positive-rules-approved`.
This schema is distinct from `connector-history-kind/v1`; a mapping string alone
is insufficient to select an interpretation. The v2 interpretation remains
`{ kind: "unknown", rule_id: "U0-no-approved-rule", reason_code }`.

`context` holds normalized `account_id`, requested `conversation_id`, a bounded
`generation_id` mirror, method `GET`, endpoint template
`/api2/v2/chats/{id}/messages`, and surface `native-rest-message-page`,
`reduced-message-page` or `unavailable`. These are identifying record metadata,
not anonymous diagnostics. An unbounded legacy generation ID longer than 256
characters has a null mirror and unavailable observations. `read.generation_id`
remains authoritative.

Items contain `record_index`, canonical `record_id`, `source_kind_evidence` and
`interpretation`. Persist evidence atomically with its record and context. An
index is meaningful within this response only. IDs establish neither chronology
nor coverage. `source_kind_evidence` contains `availability`,
`representations` (a `list` entry and a separate `messages` entry when supplied),
and `alias_comparisons` for each selected field.

| Own source state | Observation |
| --- | --- |
| Absent | `present: false`, null type/token |
| Explicit null | `present: true`, type `null`, null token |
| Exact string `responseType: "message"` | String type, token `literal-message` |
| Recognized system string | String type, fixed `literal-<value>` token |
| Other/empty string | String type, null token |
| Boolean, finite number, array, object | Actual JSON type, null token |

System tokens cover `call_requested`, `call_missed`, `call_approved`, `call_paid`,
`call_ended`, `call_declined`, `call_disconnected`. This sidecar records lexical
observations without changing its legacy interpretation. Absence, null, false,
zero and empty string do not collapse into a semantic default. Text, sender,
direction, media, queue, price, tips and deletion flags are not kind evidence.

Only own data properties are observed; accessors are never invoked. Descriptor
failures and non-JSON scalars make all observations unavailable. Arrays and
objects stay opaque: no traversal, arbitrary keys, serialization or raw-value
hashes. Alias comparison happens before lossy projection: `equal` for identical
primitives or two absences, `different` for presence/primitive differences,
`indeterminate` for complex values, and `not-applicable` without a second alias.
Identical opaque tokens do not prove source equality.

Available rows retain legacy reasons `conflicting_source_evidence`,
`missing_kind_evidence`, `unsupported_kind_evidence` or
`no_positive_rules_approved`. Unavailable rows use `source_evidence_unavailable`,
`unsupported_source_scope`, `projection_unavailable` or
`evidence_budget_exceeded`. Fallbacks contain no representations and
indeterminate comparisons, not invented absent properties.

The observation sidecar has an independent 131,072-byte UTF-8 JSON limit, with
at most 100 records, two representations and two fields. Overflow returns a
compact whole-page unavailable fallback. Canonical parsing retains its existing
2,097,152-byte limit and the transport retains its 8 MiB limit. The additive
per-record metadata is attached after those canonical acceptance checks.

Missing/unsupported versions and unavailable evidence remain unknown for kind
consumers. Potentially later or unresolved tied unknowns block unqualified
latest-message and no-reply conclusions. Cutoff, coverage, ordering, visibility
and invalidation remain consumer responsibilities. Displaying accepted inbox
records and attributing their senders does not require kind certification.
