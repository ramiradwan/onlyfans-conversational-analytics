// Classification follows a version-pinned client category, not a server invariant.
export const HISTORY_KIND_MAPPING = 'onlyfans-event-kind/0.2.0';
export const CLIENT_MODULE_HASHES = Object.freeze({
  '557720': '059c2cd4b5c3eeabd809cd9fafd85bb3d791b3362cdf0177afcc8a083e33b234',
  '872603': 'a10beef282df4a5ac644f6a32dbfcb6a921071a48d4a6fd56de104bc8fcf12b7',
});
export const CLIENT_SYSTEM_LABELS = Object.freeze([
  'call_requested', 'call_missed', 'call_approved', 'call_paid',
  'call_ended', 'call_declined', 'call_disconnected',
]);
export const CLIENT_BEHAVIOUR_FINGERPRINT = '4076a3294f8d081b8cab5cddd695d214640b24dea2794e07ee2f80ca9fabaac6';
export const CLIENT_MODULE_PIN_SETS = Object.freeze([
  Object.freeze({ version: 'onlyfans-client-parity-pins/2026-10-03.1',
    behaviour_fingerprint: CLIENT_BEHAVIOUR_FINGERPRINT,
    dispatch: Object.freeze({ module: '557720', sha256: CLIENT_MODULE_HASHES['557720'] }),
    labels: Object.freeze({ module: '872603', sha256: CLIENT_MODULE_HASHES['872603'] }),
  }),
  Object.freeze({ version: 'onlyfans-client-parity-pins/2026-10-04.1',
    behaviour_fingerprint: CLIENT_BEHAVIOUR_FINGERPRINT,
    dispatch: Object.freeze({ module: '600318', sha256: '64b0a8c055fcaa44ef7820c3a77f73bed866056f57e705ca46d8c4a918bc3673' }),
    labels: Object.freeze({ module: '872603', sha256: '58d3d5b0a77156753844554605b7627f8d82d1cca82d91d2b176dc0c560f5e97' }),
  }),
]);
export const CURRENT_CLIENT_PIN_SET = CLIENT_MODULE_PIN_SETS[1];
const SYSTEM_TOKENS = new Set(CLIENT_SYSTEM_LABELS.map((value) => `literal-${value}`));

function classify(evidence, row) {
  const source = row.source_kind_evidence;
  if (source.availability !== 'available') {
    return { kind: 'unknown', rule_id: 'U-UNAVAILABLE', evidence_state: 'unavailable' };
  }
  if (Object.values(source.alias_comparisons).includes('different')) {
    return { kind: 'unknown', rule_id: 'U-CONFLICT', evidence_state: 'conflicting' };
  }
  if (evidence.schema !== 'connector-event-kind/v2' || evidence.mapping_version !== HISTORY_KIND_MAPPING
    || evidence.context.surface !== 'native-rest-message-page' || evidence.context.method !== 'GET'
    || evidence.context.endpoint !== '/api2/v2/chats/{id}/messages'
    || source.representations.length !== 1 || source.representations[0].root !== 'list') {
    return { kind: 'unknown', rule_id: 'U-SCOPE', evidence_state: 'out_of_scope' };
  }
  const { responseType, systemType } = source.representations[0].fields;
  if (!responseType.present || responseType.value_type !== 'string' || responseType.value_token !== 'literal-message') {
    return { kind: 'unknown', rule_id: 'U-RESPONSE', evidence_state: responseType.present ? 'unsupported' : 'missing' };
  }
  if (!systemType.present) {
    return { kind: 'human_message', rule_id: 'CP-H1', evidence_state: 'supported' };
  }
  if (systemType.value_type === 'string' && SYSTEM_TOKENS.has(systemType.value_token)) {
    return { kind: 'non_message_event', rule_id: 'CP-S1', evidence_state: 'supported' };
  }
  return { kind: 'unknown', rule_id: 'U-SYSTEM', evidence_state: 'unsupported' };
}

// Internal: consume only the bounded projector output from the same accepted attempt.
// Keep the immutable observation sidecar's interpretation unchanged.
export function attachHistoryEventKinds(data, evidence) {
  return { ...data, items: data.items.map((item, index) => {
    const row = evidence.items[index];
    return { ...item, event_kind: {
      schema: 'connector-history-kind/v1',
      mapping_version: HISTORY_KIND_MAPPING,
      evidence_standard: 'client-parity',
      client_pin_set_version: CURRENT_CLIENT_PIN_SET.version,
      ...classify(evidence, row),
      context: evidence.context,
      source_kind_evidence: row.source_kind_evidence,
    } };
  }) };
}
