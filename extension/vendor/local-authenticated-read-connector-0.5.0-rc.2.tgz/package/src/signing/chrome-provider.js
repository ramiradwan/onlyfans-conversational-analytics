import { observeSigningOperation, validateDiagnosticCallback } from './diagnostics.js';
import { runAbortable, throwIfAborted, validateTimeout, DEFAULT_TRANSPORT_TIMEOUT_MS } from './async-operation.js';
import { ChromeMainWorldSigningHost } from './chrome-host.js';
import {
  createChromeSigningGenerationStore,
  restrictSigningStorageToTrustedContexts,
} from './chrome-storage.js';
import { BrowserSigningProvider } from './provider.js';

export async function createChromeBrowserSigningProvider(options = {}) {
  const callback = validateDiagnosticCallback(options.onDiagnostic);
  return observeSigningOperation(callback, { event: 'initialize', signal: options.signal },
    () => createChromeProvider(options));
}

async function createChromeProvider({
  chromeApi = globalThis.chrome,
  packagedRule,
  storageKey,
  now,
  idFactory,
  sha1Hex,
  captureTimeoutMs,
  tabId,
  expectedIdentity = null,
  captureMode = 'safe-reload',
  ownedHelper = null,
  persistence = null,
  onDiagnostic = null,
  signal = null,
  transportTimeoutMs = DEFAULT_TRANSPORT_TIMEOUT_MS,
} = {}) {
  throwIfAborted(signal);
  validateTimeout(transportTimeoutMs);
  if (!['safe-reload', 'observe-only'].includes(captureMode)) {
    throw new TypeError('Browser signing captureMode must be safe-reload or observe-only.');
  }
  if (ownedHelper !== null && (captureMode !== 'observe-only' || tabId != null)) {
    throw new TypeError('Owned helper capture requires observe-only mode and cannot target an existing tab.');
  }
  if (persistence === null) {
    await runAbortable(signal, () => restrictSigningStorageToTrustedContexts(chromeApi));
  }
  const store = createChromeSigningGenerationStore({
    chromeApi,
    key: storageKey,
    now,
    idFactory,
    ...(persistence === null ? {} : { persistence }),
  });
  await runAbortable(signal, () => store.initialize());
  throwIfAborted(signal);
  const hostOptions = {
    chromeApi,
    captureTimeoutMs,
    transportTimeoutMs,
    tabId,
    ...(idFactory ? { idFactory } : {}),
  };
  const host = ownedHelper === null ? new ChromeMainWorldSigningHost(hostOptions)
    : await ChromeMainWorldSigningHost.createForOwnedHelper({ ...hostOptions,
      helperPagePath: ownedHelper.helperPagePath, onCreated: ownedHelper.onCreated, signal });
  return new BrowserSigningProvider({
    store,
    host,
    packagedRule,
    ...(now ? { now } : {}),
    ...(sha1Hex ? { sha1Hex } : {}),
    expectedIdentity,
    captureMode,
    transportTimeoutMs,
    onDiagnostic,
  });
}
