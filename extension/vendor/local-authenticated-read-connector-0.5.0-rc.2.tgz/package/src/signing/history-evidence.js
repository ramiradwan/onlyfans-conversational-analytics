// Internal evidence projection. It observes parser-accepted records; it never
// changes parser acceptance and contains no positive semantic classification.
import { utf8ByteLength } from './validation-limits.js';

const MAX_EVIDENCE_BYTES = 128 * 1024;
const FIELD_NAMES = ['responseType', 'systemType'];
const SYSTEM_TOKENS = new Map([
  'call_requested', 'call_missed', 'call_approved', 'call_paid',
  'call_ended', 'call_declined', 'call_disconnected',
].map((value) => [value, `literal-${value}`]));
const ENDPOINT = '/api2/v2/chats/{id}/messages';

// Never invoke an optional source-field accessor. Descriptor/proxy failures are
// handled by the whole-page unavailable fallback below.
function own(object, key) {
  const descriptor = Object.getOwnPropertyDescriptor(object, key);
  if (descriptor === undefined) return { present: false, value: undefined };
  if (!Object.hasOwn(descriptor, 'value')) throw new TypeError('Unavailable source property.');
  return { present: true, value: descriptor.value };
}

function observe(record, field) {
  const source = own(record, field);
  if (!source.present) return { source, observation: { present: false, value_type: null, value_token: null } };
  const value = source.value;
  const type = value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
  if (!['null', 'string', 'boolean', 'number', 'array', 'object'].includes(type)
    || (type === 'number' && !Number.isFinite(value))) {
    throw new TypeError('Unavailable source value.');
  }
  const token = field === 'responseType'
    ? value === 'message' ? 'literal-message' : null
    : typeof value === 'string' ? SYSTEM_TOKENS.get(value) ?? null : null;
  return { source, observation: { present: true, value_type: type, value_token: token } };
}

function compare(left, right) {
  if (right === undefined) return 'not-applicable';
  if (!left.present && !right.present) return 'equal';
  // Presence itself is exact evidence; one representation cannot fill another.
  if (!left.present || !right.present) return 'different';
  const primitive = (value) => value === null || ['string', 'number', 'boolean'].includes(typeof value);
  if (!primitive(left.value) || !primitive(right.value)) return 'indeterminate';
  return Object.is(left.value, right.value) ? 'equal' : 'different';
}

function interpretation(reason) {
  return { kind: 'unknown', rule_id: 'U0-no-approved-rule', reason_code: reason };
}

function envelope(context, items) {
  return {
    schema: 'connector-event-kind/v2',
    mapping_version: 'onlyfans-event-kind/0.2.0',
    review_status: 'no-positive-rules-approved',
    context,
    items,
  };
}

function unavailable(context, items, reason) {
  return envelope(context, items.map((item, index) => ({
    record_index: index,
    record_id: item.id,
    source_kind_evidence: {
      availability: 'unavailable',
      representations: [],
      alias_comparisons: { responseType: 'indeterminate', systemType: 'indeterminate' },
    },
    interpretation: interpretation(reason),
  })));
}

function supportedRequest(request, conversationId) {
  if (own(request, 'operation').value !== 'message-page' || own(request, 'method').value !== 'GET') return false;
  const rawUrl = own(request, 'url').value;
  if (typeof rawUrl !== 'string' || /[\x00-\x20\x7f]/.test(rawUrl)) return false;
  const url = new URL(rawUrl);
  if (url.origin !== 'https://onlyfans.com' || url.username || url.password || url.hash
    || url.pathname !== `/api2/v2/chats/${conversationId}/messages`) return false;
  const keys = [...url.searchParams.keys()];
  return keys.every((key) => ['limit', 'offset', 'id', 'order'].includes(key))
    && new Set(keys).size === keys.length && url.searchParams.get('order') === 'desc'
    && !(url.searchParams.has('id') && url.searchParams.has('offset'));
}

/**
 * Internal: data is a freshly projected, already accepted canonical page and
 * request/context come from the same actual provider attempt. This function is
 * intentionally not part of the package's public exports.
 */
export function buildHistoryKindEvidence({ body, data, request, accountId, conversationId, generationId }) {
  // Canonical IDs are permitted metadata, not discriminator values or diagnostics.
  // Generation IDs were historically unbounded: do not change their acceptance.
  const generationAvailable = typeof generationId === 'string' && generationId.length > 0 && generationId.length <= 256;
  const context = {
    account_id: accountId,
    conversation_id: conversationId,
    generation_id: generationAvailable ? generationId : null,
    method: 'GET',
    endpoint: ENDPOINT,
    surface: 'unavailable',
  };
  const fallback = (reason) => unavailable(context, data.items, reason);
  try {
    if (!generationAvailable) return fallback('projection_unavailable');
    if (!supportedRequest(request, conversationId)) return fallback('unsupported_source_scope');
    const native = own(body, 'hasMore');
    if (!native.present) {
      context.surface = 'reduced-message-page';
      return fallback('source_evidence_unavailable');
    }
    const list = own(body, 'list');
    const alias = own(body, 'messages');
    if (typeof native.value !== 'boolean' || !list.present || !Array.isArray(list.value)
      || list.value.length !== data.items.length
      || (alias.present && (!Array.isArray(alias.value) || alias.value.length !== data.items.length))) {
      return fallback('projection_unavailable');
    }
    context.surface = 'native-rest-message-page';
    const roots = [['list', list.value], ...(alias.present ? [['messages', alias.value]] : [])];
    const items = data.items.map((item, index) => {
      const sources = roots.map(([root, records]) => {
        const record = own(records, String(index));
        if (!record.present || record.value === null || typeof record.value !== 'object') {
          throw new TypeError('Unavailable source record.');
        }
        const fields = Object.fromEntries(FIELD_NAMES.map((field) => [field, observe(record.value, field)]));
        return { root, fields };
      });
      const comparisons = Object.fromEntries(FIELD_NAMES.map((field) => [field,
        compare(sources[0].fields[field].source, sources[1]?.fields[field].source)]));
      const observations = sources.flatMap(({ fields }) => FIELD_NAMES.map((field) => fields[field].observation));
      const reason = Object.values(comparisons).includes('different') ? 'conflicting_source_evidence'
        : observations.every((field) => !field.present) ? 'missing_kind_evidence'
          : Object.values(comparisons).includes('indeterminate')
            || observations.some((field) => field.present && field.value_token === null) ? 'unsupported_kind_evidence'
            : 'no_positive_rules_approved';
      return {
        record_index: index,
        record_id: item.id,
        source_kind_evidence: {
          availability: 'available',
          representations: sources.map(({ root, fields }) => ({ root,
            fields: Object.fromEntries(FIELD_NAMES.map((field) => [field, fields[field].observation])) })),
          alias_comparisons: comparisons,
        },
        interpretation: interpretation(reason),
      };
    });
    const result = envelope(context, items);
    // This measures only newly constructed bounded values, never raw source data.
    if (utf8ByteLength(JSON.stringify(result), MAX_EVIDENCE_BYTES) > MAX_EVIDENCE_BYTES) {
      return fallback('evidence_budget_exceeded');
    }
    return result;
  } catch {
    // Optional evidence must never change a successfully parsed canonical page.
    return fallback('projection_unavailable');
  }
}
