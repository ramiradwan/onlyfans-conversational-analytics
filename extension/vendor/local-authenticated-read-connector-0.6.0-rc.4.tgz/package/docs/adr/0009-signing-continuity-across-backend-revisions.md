# ADR 0009: Preserve signing continuity across backend revisions

- Status: accepted for implementation
- Date: 2026-10-14

Request-side signing revision and backend response revision identify different
things. Bounded maintainer observations established overlapping acceptance of
different signing calculations at one backend deployment. They do not establish
a permanent grace period or universal account/history compatibility.

This decision supersedes request/response revision equality in ADR 0005 and the
initial parameter-delivery plan. Exact native request revision to parameter-object
matching, native signature reproduction and signed publication authority remain
required. A backend marker cannot select a rule, rewrite its source revision,
withdraw authority, or authorize a refresh.

A successful typed read preserves its eligible generation on the document where
it was activated. The reference Chrome operation host exposes an optional,
read-only `documentIdentity` obtained from browser-owned metadata. Activation
stores that identity as `summary.activation_document` in account-scoped state.
Replacement or unknown documents require fresh observation, exact rule matching
and proof. Hosts without stable document identity support operation-local proof
only. Construction and status do not observe or mutate state.

Proof policy 3 requires candidate identity success, the authorised request
revision, a fresh timestamp, and a digest-focused sign-only control. The control
changes one digest character while preserving framing and recomputing checksum.
Candidate and control must report the same nonempty backend revision, which need
not equal the request revision. Context replacement, expiry, withdrawal and weak
comparisons prevent activation. Stored policy-2 proof is never relabelled on load.

Rollback proves the exact previous rule. If its document binding differs, native
reproduction must establish that the current frontend still uses that rule before
any candidate is sent. The immutable maintainer store creates a newly proved
generation when revalidation changes the document binding; pointer swaps alone
do not rewrite historical proof records.

Publication formats, roots, publisher custody, resolver DTOs and consumer network
boundaries are unchanged. Broader fallback after observing a different frontend
is outside this decision. Product integration and installed acquisition
qualification remain separately owned.
