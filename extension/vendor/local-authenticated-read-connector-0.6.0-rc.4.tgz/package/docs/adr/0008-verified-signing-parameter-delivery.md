# ADR 0008: Verify independently published signing parameters

- Status: accepted for implementation
- Date: 2026-10-13

ADR 0005 remains the contract for packaged executable computation, exact platform
revision matching, observed-signature reproduction and account-bound differential
proof. This decision supersedes only its requirement that parameter authority
comes from one unsigned rule embedded by a software build.

An explicit verified-source mode accepts bounded data from an injected resolver.
The packaged connector verifies an offline-root-authorized publisher keyset and
signed catalog before accepting the catalog's exact revision/digest/size mapping.
An explicit static `packagedRule` mode remains available. Mixed construction is
invalid; failed dynamic verification cannot select an unsigned static fallback.

The resolver transports bytes. It cannot appoint roots, execute instructions,
select arbitrary operations, authorize account access or declare proof successful.
The connector has no distribution URL, companion RPC name, deployment origin or
repository credential. Private derivation tooling remains outside the package.

Publication checkpoints and generic data caches have one persistence owner,
separate from per-account signing state. Accepted sequences never decrease;
conflicting payloads at the same sequence fail closed. Withdrawal takes effect
when authenticated metadata is durably accepted, even if a replacement object is
unavailable. Expiry or corrupt storage refuses signed requests. Neither condition
authorizes browser recovery, account changes or a return to earlier authority.

Renewal of the same parameter digest does not repeat platform proof or rewrite a
signing generation. A changed digest requires fresh reproduction and proof. Each
request and activation rechecks current publication eligibility, account identity,
document context and cancellation. A save already entered can finish, but a
generation withdrawn during that save remains ineligible for subsequent use.

Consumer transport, app lifecycle, recovery allowances, scheduling, customer copy
and installed Product qualification remain Consumer-owned. The signer supplies
the executable contract and vectors defined in the
[publication specification](../specs/signing-parameter-delivery.md).
