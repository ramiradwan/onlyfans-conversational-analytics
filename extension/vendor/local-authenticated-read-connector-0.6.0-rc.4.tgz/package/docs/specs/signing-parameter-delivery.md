# Verified signing parameter publication and delivery v1

## Publication profile

`publication/` contains normative schemas and deterministic synthetic vectors.
No fixture describes a live account or production publication key.

The supported platform is `onlyfans`; the packaged engine profile is
`onlyfans-sha1-checksum/v1`; the inner object retains
`local-packaged-signing-rule/v1`. Revisions are opaque, case-sensitive ASCII
strings of 1–128 visible characters. They are never ordered as software versions.
The object must name the exact selected revision. No wildcard, cross-revision
reuse, executable payload, URL or algorithm instruction is permitted.

Catalog and keyset use compact JWS: three canonical unpadded base64url segments.
The protected header has exactly `alg`, `kid`, `typ`; `alg` is always `ES256`.
The fixed types are `signing-parameter-catalog+jws` and
`signing-publisher-keyset+jws`. Key identifiers contain 1–64 ASCII letters,
digits, periods, underscores or hyphens and begin with a letter or digit.
`jku`, `jwk`, `x5u`, `crit`, `b64` and additional header fields are prohibited.
JWKs contain exactly `kty: EC`, `crv: P-256`, and canonical 32-byte `x` and `y`.

Signed header and payload bytes are UTF-8 JSON with recursively sorted object
member names, compact separators, no BOM and no trailing newline. Arrays retain
their order. Duplicate keys (including escaped aliases), unknown fields,
unpaired Unicode surrogates, unsafe integers, invalid UTF-8 and nesting beyond
16 levels are rejected. Verify the signature over the original encoded header
and payload before interpreting the payload. ES256 signatures contain exactly
64 bytes, unsigned big-endian `R || S`, as specified by
[RFC 7518 section 3.4](https://www.rfc-editor.org/rfc/rfc7518.html#section-3.4).
Use native [WebCrypto](https://www.w3.org/TR/WebCryptoAPI/) or the established
Python cryptography library; never implement ECDSA arithmetic.

The catalog contains exactly `schema`, `sequence`, `issued_at`, `expires_at`,
`platform`, `engine`, `parameter_schema`, `rules`. Each sorted, unique revision
mapping has exactly `source_revision`, lowercase raw-byte `sha256`, `size`.
An empty mapping list withdraws all rules. Its maximum is 128 mappings.
The catalog schema is `signing-parameter-catalog/v1`.

The root-signed keyset contains exactly `schema`, `sequence`, `issued_at`,
`expires_at`, `keys`. Each unique publisher entry contains exactly `kid`, `jwk`,
`not_before`, `not_after`. The keyset schema is `signing-publisher-keyset/v1`.
Catalog issue/expiry must fit within the signing publisher's authorization
window. Root trust is supplied separately as `signing-publication-trust/v1`
with 1–4 fixed root entries (`kid`, `jwk`); a resolver cannot replace that trust.
Up to eight publisher entries permit bounded overlap during rotation. Removing
a publisher removes its authorization; retained keys support still-valid
catalogs. A compromised root requires a separately trusted software/recovery
release. Commercial authorization keys have no role here.

Timestamps are safe integer Unix seconds. Issue time may be at most 300 seconds
ahead of the local clock. Expiry has no grace: at `now >= expires_at`, refuse
new signed work. Catalog lifetime is at most seven days; keyset lifetime at most
366 days. Preserve a durable maximum observed clock with the checkpoints;
rollback beyond 300 seconds fails closed. A small rollback never extends expiry:
use the maximum observed clock for eligibility. Extreme forward skew may expire
metadata; transport cannot repair that by resetting sequence or clock state.

Object limit: 16 KiB. Decoded catalog: 32 KiB. Decoded keyset: 16 KiB.
Complete UTF-8 resolver response, including base64 expansion: strictly below
256 KiB. Bounds are checked before decoding, parsing and cryptographic work.
Inner object bytes are immutable; their digest authenticates their full byte
representation, not reserialized JSON. A second object signature is unnecessary.

## Acceptance and persistence

Accept root-authorized keyset, then its catalog, then verify the selected object
size, raw digest and exact revision. Only supported engine/schema objects can
drive packaged computation. Checkpoint payload digests identify signed content;
ECDSA signature randomness does not create a same-sequence content conflict.
Reject lower sequences and a different payload digest at the same sequence.

Commit verified metadata/checkpoints before promoting a usable object cache.
A newer withdrawal remains authoritative if object acquisition fails. Preserve
checkpoints when cached objects are deleted. Corrupt/missing authoritative
state is refusal or an owner-controlled recovery, never a sequence reset.
Expired signed metadata can reconstruct existing checkpoints after restart,
but never authorize requests. No remote work runs inside a persistence save.
Injected persistence requires a single owner; it is not a distributed lock.

## Transport-independent resolver contract

The dedicated DTO names only the fixed schema/engine, exact observed revision,
accepted catalog/keyset sequence and optional known object digest. It receives
an abort signal separately. It must never receive browser headers, identity,
cookies, captures, signatures, URLs, account data or message content.

Closed results are `available`, `not_modified`, `pending`, `not_published`,
`unavailable`, `unsupported_engine`. Available carries unchanged compact catalog
and keyset strings and the exact object encoded as canonical base64url.
Metadata describing a new publication decision accompanies that decision.
`not_modified` applies only to an exact, locally verified and still eligible
cache identity. Pending/missing results release the browser operation promptly;
bounded retry advice is dependency scheduling, never HTTP-429 metadata or account
authorization. Invalid or rejected publications use fixed error codes.

Construction loads state without resolver calls or platform observation. Status
also performs no retrieval, proof or authentication. `refreshMode: never` allows
cached eligibility checks only. A known pending/missing revision is checked with
the resolver before another browser observation. Captured headers are not saved
for deferred proof: resumed work obtains a fresh permitted observation.

A corrupt or failed authority load produces an unavailable, owned source without
resetting sequences or contacting the resolver. Runtime construction can finish;
signed work refuses until the persistence owner repairs the checkpoint and
replaces the drained source. Missing disposable object bytes can be fetched
against the preserved checkpoint. Null load is reserved for genuine first use.

The same provider and lifecycle owner survive publication changes. Before each
platform dispatch and activation, recheck eligibility and account/document scope.
An unchanged digest under renewed authorization reuses the proved generation;
a changed digest requires a newly proved generation. Restored credentials alone
are insufficient authority. Dynamic mode has no unsigned packaged fallback.

## Maintenance policy

Publish unchanged catalog renewals daily with a seven-day lifetime. Consumer
fetch scheduling (startup and approximately every six hours with jitter), bounded
negative caches, coalescing and capped five-minute dependency retries belong to
the Consumer service. Maintain separate publisher alarms for expiring metadata
and unavailable controlled derivation sessions. Changing engine/schema semantics
requires a software release. Routine compatible publication does not.
