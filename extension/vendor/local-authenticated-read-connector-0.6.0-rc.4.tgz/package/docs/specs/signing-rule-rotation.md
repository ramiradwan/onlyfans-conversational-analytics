# Signing-rule rotation

## Developer workflow

Run a typed read with automatic bootstrap and rotation:

```powershell
npm run dev:read -- --operation identity
```

Optional commands:

```powershell
npm run dev:status
npm run dev:refresh
npm run dev:rollback
```

All commands accept `--cdp` and a private `--state-root`. `dev:read` also accepts `--params` for conversations and explicitly selected message pages.

The tools never launch the browser or automate sign-in. If the dedicated authenticated tab is unavailable they leave signing state unchanged and print the exact browser action required.

## Private generation state

The default root is `.local/signing/`:

```text
active.json
previous.json
pending.json                 # exists only during a pointer transaction
refresh.lock/owner-<UUID>.json # ownership for all state access
generations/<generation>/
  capture.private.json
  config.private.json
  context.private.json
  candidate.private.json
  proof.json
  manifest.json
```

Generation directories are immutable after creation. `active.json` and `previous.json` contain only generation IDs, timestamps, and revision fingerprints. A valid pending pointer transaction is completed under ownership on the next state access, after both target generations are validated. Corrupt state is retained for inspection. Unreferenced generation directories are pruned after successful mutations; unrelated files and links are not followed.

## Refresh transaction

1. Acquire the private refresh lock; concurrent callers reuse the generation activated by the lock holder.
2. Reload the dedicated OnlyFans tab and capture a current identity request.
3. Inspect the loaded runtime, derive current rules and authenticated session context, and reproduce the browser signature.
4. Prepare a fresh local identity candidate.
5. Require a valid identity candidate before sending a fresh sign-only control; apply the [bounded proof policy](failure-classification-and-proof.md).
6. Require candidate and control to report the same nonempty backend revision; the request revision still identifies the extracted parameters.
7. Write an immutable generation, record the old active generation as previous, and atomically update the active pointer.
8. Remove generations other than current and previous.

Any failure before step 7 leaves active and previous unchanged.

## Automatic read behavior

`dev:read` bootstraps missing/obsolete state or a changed document once. It uses
CDP frame/loader metadata to bind the maintainer generation. Backend revision
changes preserve successful reads without rotation or retry. Unsuccessful
responses retain the existing failure policy. There is no second refresh loop.

Raw response revisions are compared only in memory. Reports and pointer files contain fingerprints. Response bodies continue to be summarized and discarded.

## Rollback

`dev:rollback` prepares a fresh identity request from the previous generation and requires policy-3 strong proof with stable backend metadata. A different document first requires native reproduction; revalidation creates a new immutable generation rather than rewriting the previous manifest. Only then are active and previous swapped. A stale or invalid previous generation remains inactive.

## Private-tool ownership

See [Private development state](private-development-state.md) for filesystem permissions,
link resistance, byte ceilings, owner-aware lock recovery, and the journal commit
point. Refresh and rollback share ownership through proof; rollback conditionally
swaps the exact generation it proved. A late failure after durable journal creation
may be completed by the next owner and is not a guarantee that state is unchanged.
