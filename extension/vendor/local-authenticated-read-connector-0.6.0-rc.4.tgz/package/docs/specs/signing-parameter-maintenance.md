# Maintainer publication workflow

The fixed customer origin serves anonymous HTTPS GETs beneath one reviewed base
path. It must provide immutable conditional creates (`If-None-Match: *`), strong
ETags, and conditional pointer writes (`If-Match`). Redirects are refused. This
is artifact storage, not a signing or code-computation service. Configure its
upload credential as `SIGNER_DISTRIBUTION_UPLOAD_TOKEN`; customers never receive
that credential, a publisher private key, or a private repository token.

## One-time setup

Provision a separate offline P-256 publication root and an online P-256 publisher.
The intended R2 target, verified resource status and blocking provisioning steps
are in [R2 provisioning](../../deployment/README.md), a maintainer file excluded
from the installed connector archive.
Root and publisher points/identifiers must differ. Keep the root private key
offline. Consumer software pins the public root trust; this repository's vector
roots are public synthetic test material and must never be used for deployment.

Create bounded public root trust and publisher keyset payload files beneath `.local/`.
Keep the root private PEM on the isolated offline volume outside every repository.
Emit the root-authorized keyset offline:

```text
npm run dev:emit-rule -- --keyset-payload .local/keyset-payload.json --trust .local/publication-trust.json --root-key <absolute-external-offline-root.pem> --root-kid <root-id> --out .local/publisher-keyset.jws
```

The distribution configuration contains exactly `schema`, `origin`, `base_path`,
`trust`, `keyset_path`, `publisher_key_path`, `publisher_kid`. Schema is
`signing-parameter-distribution/v1`; origin is one HTTPS origin without a path,
query, credentials or custom port; base path is a bounded absolute directory
path. Trust is the reviewed `signing-publication-trust/v1` document. File paths
for online material remain private under `.local/`; the root key is external and
CI access is refused. Do not commit live rule/configuration histories
or private keys. Synthetic vectors are separate declared package data.

Initialize a distribution once, optionally with no rule seed:

```text
npm run dev:publish-rule -- --distribution-config .local/distribution.json --deployment-config deployment/signing-parameters.production.json --renew-catalog --initialize-distribution
```

This starts at catalog sequence one only when the remote pointers and retained
checkpoint permit first setup. Missing pointers after prior publication are
not permission to restart sequences. Preserve `.local/parameter-publisher/`
as authoritative maintainer state; protect it with the private filesystem policy.

## Routine derivation and publication

Use the existing dedicated authenticated browser and one command:

```text
npm run dev:refresh -- --state-root .local/signing --distribution-config .local/distribution.json --deployment-config deployment/signing-parameters.production.json
```

The command runs the existing capture/reproduction/differential proof transaction,
emits the existing publication byte representation with a 16 KiB ceiling, checks
fresh proof, uploads the digest-named object, reads every byte back, stages signed
metadata immutably, and promotes the catalog conditionally. The raw browser
material stays private. A lost acknowledgement is reconciled by exact readback;
no upload is blindly repeated and no ambiguous artifact is overwritten.

An already emitted file can use `dev:publish-rule -- --rule <private-file>
--state-root <proved-state> --distribution-config <private-config>`. Its exact
bytes must match the fresh strongly proved generation. `dev:emit-rule` accepts
`--parameter-object` to enforce the narrower customer object ceiling.

The controlled browser must remain authenticated and the existing extraction
procedure must still reproduce its signature. Expired sessions or a broken
procedure fail the maintainer job; they do not start customer browser recovery.

## Renewal, withdrawal and publisher rotation

When the online publisher key is held only by the protected GitHub environment,
use the [owner-proved immutable release path](signing-rule-publication.md#verification-and-interrupted-publication)
after local derivation. The job retrieves exact rule/proof coordinates and uses
the existing producer, conditional promotion and retained checkpoint. Browser
credentials stay local; the online private key stays in its publication job.

Daily renewal requires no controlled browser observation and keeps object bytes:

```text
npm run dev:publish-rule -- --distribution-config .local/distribution.json --deployment-config deployment/signing-parameters.production.json --renew-catalog
```

Catalogs last at most seven days. The daily job fails well before catalog expiry
when renewal or publisher authorization cannot complete. Retain normal maintainer
workflow failure notifications; do not turn these into customer reinstall prompts.

For withdrawal, pass `--withdraw .local/revisions.json`, a bounded JSON array of
exact revisions. Routine renewal preserves previously approved mappings. A newly
proved object for another revision gets its own bytes and digest; its embedded
revision cannot be reused under another mapping.

Supported rotation supplies a higher-sequence root-signed keyset and switches
the configured online publisher. Retain old verification keys while their valid
catalogs need them. Removal takes effect before replacement object availability.
If a removed publisher signed the current catalog, preserving its mappings
requires explicit review; `--replace-rules` permits a reviewed replacement set
instead. The transport cannot replace the offline trust roots.

## Interrupted promotion and automation

A durable `pending.json` records the exact promotion intent. The next ordinary
command refuses to overwrite it. Verify the exact stored artifact read-only:

```text
npm run dev:publish-rule -- --distribution-config .local/distribution.json --deployment-config deployment/signing-parameters.production.json --verify-existing
```

Verification sends no PUT. Missing, different or superseded remote bytes remain
unconfirmed and require maintainer inspection, preserving the pending record.
Repair a genuinely unexecuted staging failure offline under exclusive ownership;
do not delete checkpoints or roll back an accepted withdrawal to obtain a retry.

The daily `renew-signing-parameters.yml` job runs only on reviewed `main` and
only after distribution configuration exists. Configure the public configuration
and signed keyset as repository/environment variables and the online key/upload
credential as protected secrets. The configuration variable contains exactly
`origin`, `base_path`, `trust`, `publisher_kid`. No root private key enters CI.
The job serializes publication, retains its checkpoint across runs, and refuses
a missing/evicted checkpoint outside explicit initial setup. Cache eviction is
not authority to reset a sequence. Restore verified maintainer state before
continuing; cached interrupted intent follows the read-only recovery procedure.
The manual job's `verify_existing` option performs this read-only reconciliation
without loading a publisher private key.

The private GitHub rule asset remains an optional maintainer provenance input.
Routine compatible publication does not rebuild Consumer software or its grants.
Changing engine/schema behavior requires a reviewed software release. Production
commands additionally require `--deployment-config <reviewed-release-bound-file>`;
production packaging and renewal reject known synthetic trust. The deployment
gate binds the exact origin and dedicated root/publisher public material, and
refuses uploads unless endpoint, permissions and trust readiness are recorded
and verified. Use `--synthetic-distribution` only for controlled
loopback or `.invalid` fixtures.
