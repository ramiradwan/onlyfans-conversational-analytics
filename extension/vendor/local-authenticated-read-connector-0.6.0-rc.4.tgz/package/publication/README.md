# Signing publication conformance data v1

These schemas and deterministic vectors are normative data for independent
consumers of the signing publication profile. `vectors.json` contains public
synthetic keys, ES256 JWS bytes and synthetic parameter bytes. None is production
trust material. Developer generation and independent Python verification tooling
is excluded from the package.

Run `npm run test:publication-conformance` with Python and cryptography installed
to compare real JavaScript and independent Python verification of identical bytes.
See `docs/specs/signing-parameter-delivery.md` for acceptance order, limits and
the persistence/lifecycle contract. Signature validity alone does not bypass
sequence, withdrawal, clock, engine, account or local-proof checks.
