// Publication JSON is deliberately stricter than JSON.parse: duplicate members,
// unsafe numbers, unpaired surrogates and excessive nesting fail before use.
// Never include rejected input in an exception.
export function parsePublicationJson(text) {
  if (typeof text !== 'string') throw new Error('Invalid publication JSON.');
  let offset = 0;
  const invalid = () => { throw new Error('Invalid publication JSON.'); };
  const space = () => { while (/[\x20\t\r\n]/.test(text[offset] ?? '') && offset < text.length) offset++; };
  function string() {
    const start = offset++;
    while (offset < text.length) {
      const character = text[offset++];
      if (character === '"') {
        let value;
        try { value = JSON.parse(text.slice(start, offset)); } catch { invalid(); }
        for (let i = 0; i < value.length; i++) {
          const unit = value.charCodeAt(i);
          if (unit >= 0xd800 && unit <= 0xdbff) {
            const next = value.charCodeAt(++i);
            if (!(next >= 0xdc00 && next <= 0xdfff)) invalid();
          } else if (unit >= 0xdc00 && unit <= 0xdfff) invalid();
        }
        return value;
      }
      if (character === '\\') offset++;
    }
    invalid();
  }
  function value(depth) {
    if (depth > 16) invalid();
    space();
    const character = text[offset];
    if (character === '"') return string();
    if (character === '{' || character === '[') {
      const object = character === '{';
      const result = object ? Object.create(null) : [];
      const seen = new Set();
      const close = object ? '}' : ']';
      offset++;
      space();
      if (text[offset] === close) { offset++; return result; }
      while (true) {
        space();
        let key;
        if (object) {
          if (text[offset] !== '"') invalid();
          key = string();
          if (seen.has(key)) invalid();
          seen.add(key);
          space();
          if (text[offset++] !== ':') invalid();
        }
        const child = value(depth + 1);
        if (object) result[key] = child;
        else result.push(child);
        space();
        if (text[offset] === close) { offset++; return result; }
        if (text[offset++] !== ',') invalid();
      }
    }
    for (const [literal, decoded] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(literal, offset)) { offset += literal.length; return decoded; }
    }
    const match = text.slice(offset).match(/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/);
    if (!match) invalid();
    offset += match[0].length;
    const number = Number(match[0]);
    if (!Number.isFinite(number) || (Number.isInteger(number) && !Number.isSafeInteger(number))) invalid();
    return number;
  }
  const result = value(0);
  space();
  if (offset !== text.length) invalid();
  return result;
}

export function closedObject(value, fields) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    && Object.keys(value).length === fields.length
    && fields.every((field) => Object.hasOwn(value, field));
}

export function freezePublication(value) {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freezePublication(child);
    Object.freeze(value);
  }
  return value;
}

export function canonicalPublicationJson(value) {
  if (Array.isArray(value)) return '[' + value.map(canonicalPublicationJson).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort().map((key) => JSON.stringify(key) + ':' + canonicalPublicationJson(value[key])).join(',') + '}';
  }
  return JSON.stringify(value);
}
