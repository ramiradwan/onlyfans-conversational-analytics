import { abortError, awaitWithAbort, createTransportOperation, runAbortable, throwIfAborted } from './async-operation.js';
import { PACKAGED_SIGNING_RULE_SCHEMA, generationMatchesPackagedRule } from './packaged-rule.js';
import { canonicalPublicationJson, closedObject, freezePublication } from './publication-json.js';
import { MAX_REVISION_LENGTH, utf8ByteLength } from './validation-limits.js';
import {
  decodePublicationBase64url, PARAMETER_ENGINE, ParameterPublicationError, PUBLICATION_LIMITS,
  publicationSha256, validatePublicationTrust, verifyParameterCatalog, verifyParameterObject, verifyPublisherKeyset,
} from './parameter-publication.js';

const sources = new WeakSet();
const owners = new WeakMap();
const STATE_SCHEMA = 'signing-parameter-state/v1';
const MAX_CACHE_OBJECTS = 16;
const MAX_STATE_BYTES = 512 * 1024;
const encoder = new TextEncoder();
const revisionValid = (value) => typeof value === 'string' && value.length >= 1 && value.length <= MAX_REVISION_LENGTH && !/[^\x21-\x7e]/.test(value);
const digestValid = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const integer = (value) => Number.isSafeInteger(value) && value >= 0;

export class ParameterSourceError extends Error {
  constructor(code, retryAfterMs = null) {
    super('Signing parameter dependency is not ready.');
    this.name = 'ParameterSourceError';
    this.code = code;
    // Dedicated dependency advice, never connector HTTP retry metadata.
    this.parameter_retry_after_ms = retryAfterMs;
  }
}
const rejected = () => { throw new ParameterPublicationError(); };
const unavailable = () => { throw new ParameterSourceError('parameters_unavailable'); };

function snapshotEnvelope(input) {
  try { return readEnvelope(input); } catch { rejected(); }
}

function readEnvelope(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)
    || ![Object.prototype, null].includes(Object.getPrototypeOf(input))) rejected();
  const result = Object.create(null);
  const keys = Reflect.ownKeys(input);
  if (keys.length > 7) rejected();
  for (const key of keys) {
    if (typeof key !== 'string') rejected();
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !Object.hasOwn(descriptor, 'value') || !descriptor.enumerable) rejected();
    const value = descriptor.value;
    if (value !== null && !['string', 'number'].includes(typeof value)) rejected();
    if (typeof value === 'string' && value.length > PUBLICATION_LIMITS.responseBytes) rejected();
    result[key] = value;
  }
  if (utf8ByteLength(JSON.stringify(result), PUBLICATION_LIMITS.responseBytes) > PUBLICATION_LIMITS.responseBytes) rejected();
  const common = ['schema', 'status', 'keyset', 'catalog'];
  const fields = {
    available: [...common, 'object'], not_modified: [...common, 'sha256'],
    pending: [...common, 'retry_after_ms'], not_published: [...common, 'retry_after_ms'],
    unavailable: [...common, 'retry_after_ms', 'reason'], unsupported_engine: common,
  }[result.status];
  if (!fields || !closedObject(result, fields) || result.schema !== 'signing-parameter-resolution/v1') rejected();
  if ((result.keyset === null) !== (result.catalog === null)) rejected();
  if (result.keyset !== null && (typeof result.keyset !== 'string' || typeof result.catalog !== 'string')) rejected();
  if (['available', 'not_modified', 'not_published', 'unsupported_engine'].includes(result.status) && result.keyset === null) rejected();
  if (Object.hasOwn(result, 'retry_after_ms') && (!integer(result.retry_after_ms) || result.retry_after_ms < 1000 || result.retry_after_ms > 300000)) rejected();
  if (result.status === 'unavailable' && !['network', 'freshness', 'storage', 'verification'].includes(result.reason)) rejected();
  if (result.status === 'not_modified' && !digestValid(result.sha256)) rejected();
  return result;
}

class ParameterSource {
  #trust;
  #trustDigest;
  #resolver;
  #persistence;
  #now;
  #timeout;
  #state;
  #keyset = null;
  #catalog = null;
  #objects = new Map();
  #chain = Promise.resolve();
  #operations = new Map();
  #closed = false;
  #busy = false;
  #failure = false;
  #epoch = 0;
  #clock = 0;
  #neededRevision = null;
  #lastState = 'empty';

  constructor({ trust, resolver, persistence, now = Date.now, resolveTimeoutMs = 5000 }) {
    this.#trust = validatePublicationTrust(trust);
    if (typeof resolver !== 'function' || typeof persistence?.load !== 'function'
      || typeof persistence?.save !== 'function' || typeof now !== 'function'
      || !Number.isSafeInteger(resolveTimeoutMs) || resolveTimeoutMs < 1 || resolveTimeoutMs > 10000) {
      throw new TypeError('Verified parameter source requires resolver, persistence and bounded clock/timeout configuration.');
    }
    if (owners.has(persistence)) throw new TypeError('Publication persistence already has an owner; share its verified source.');
    this.#resolver = resolver;
    this.#persistence = persistence;
    this.#now = now;
    this.#timeout = resolveTimeoutMs;
    owners.set(persistence, this);
  }

  #time() {
    const now = Math.floor(this.#now() / 1000);
    if (!integer(now) || now + PUBLICATION_LIMITS.clockToleranceSeconds < this.#clock) unavailable();
    this.#clock = Math.max(this.#clock, now);
    return this.#clock;
  }

  async initialize(signal) {
    try {
      this.#trustDigest = await publicationSha256(encoder.encode(canonicalPublicationJson(this.#trust)));
      const loading = createTransportOperation(signal, this.#timeout);
      let loaded;
      try { loaded = await runAbortable(loading.signal, () => this.#persistence.load()); }
      finally { loading.dispose(); }
      throwIfAborted(signal);
      if (loaded === null || loaded === undefined) {
        this.#state = { schema: STATE_SCHEMA, trust_sha256: this.#trustDigest, clock_high_water: this.#time(), keyset: null, catalog: null, objects: [] };
        return;
      }
      if (utf8ByteLength(JSON.stringify(loaded), MAX_STATE_BYTES) > MAX_STATE_BYTES) unavailable();
      const state = structuredClone(loaded);
      if (!closedObject(state, ['schema', 'trust_sha256', 'clock_high_water', 'keyset', 'catalog', 'objects'])
        || state.schema !== STATE_SCHEMA || state.trust_sha256 !== this.#trustDigest || !integer(state.clock_high_water)
        || !Array.isArray(state.objects) || state.objects.length > MAX_CACHE_OBJECTS) unavailable();
      this.#clock = state.clock_high_water;
      const now = this.#time();
      const checkRecord = (record, verified) => {
        if (!closedObject(record, ['jws', 'sequence', 'payload_sha256']) || record.sequence !== verified.payload.sequence
          || record.payload_sha256 !== verified.payload_sha256) unavailable();
      };
      if (state.keyset !== null) {
        this.#keyset = await verifyPublisherKeyset(state.keyset.jws, this.#trust, { now, allowExpired: true });
        checkRecord(state.keyset, this.#keyset);
      }
      if (state.catalog !== null) {
        if (this.#keyset === null || !closedObject(state.catalog, ['jws', 'sequence', 'payload_sha256', 'keyset_jws'])) unavailable();
        const retained = await verifyPublisherKeyset(state.catalog.keyset_jws, this.#trust, { now, allowExpired: true });
        this.#catalog = await verifyParameterCatalog(state.catalog.jws, retained, { now, allowExpired: true });
        if (retained.payload.sequence > this.#keyset.payload.sequence
          || (retained.payload.sequence === this.#keyset.payload.sequence && retained.payload_sha256 !== this.#keyset.payload_sha256)
          || state.catalog.sequence !== this.#catalog.payload.sequence
          || state.catalog.payload_sha256 !== this.#catalog.payload_sha256) unavailable();
      }
      this.#state = state;
      for (const object of state.objects) {
        if (!closedObject(object, ['sha256', 'object']) || !digestValid(object.sha256) || typeof object.object !== 'string') unavailable();
        const entry = this.#catalog?.payload.rules.find((value) => value.sha256 === object.sha256);
        if (!entry) continue;
        try {
          const rule = await verifyParameterObject(decodePublicationBase64url(object.object, PUBLICATION_LIMITS.objectBytes), entry);
          this.#objects.set(entry.sha256, rule);
        } catch { /* Disposable object corruption never discards trust checkpoints. */ }
      }
      this.#lastState = this.#objects.size > 0 ? 'ready' : 'empty';
      throwIfAborted(signal);
    } catch (error) {
      if (signal?.aborted) {
        owners.delete(this.#persistence);
        throw abortError(signal);
      }
      // A broken authority store refuses signed work, but must not prevent the
      // application's runtime/companion session from being constructed. Keep
      // ownership and poison eligibility until the persistence owner repairs
      // state and replaces this drained source. Never initialize zero sequences.
      this.#failure = true;
      this.#lastState = 'unavailable';
    }
  }

  #assertOpen() {
    if (this.#closed || this.#failure) unavailable();
  }

  #currentCatalog() {
    this.#assertOpen();
    const now = this.#time();
    if (this.#busy || !this.#keyset || !this.#catalog || now >= this.#keyset.payload.expires_at
      || now >= this.#catalog.payload.expires_at) return null;
    const signer = this.#keyset.payload.keys.find((key) => key.kid === this.#catalog.kid);
    if (!signer || this.#catalog.payload.issued_at < signer.not_before || this.#catalog.payload.expires_at > signer.not_after) return null;
    // A reused kid is not authority for a different key's historical signature.
    const retained = this.#state.catalog.keyset_jws.split('.')[1];
    const oldKeys = JSON.parse(new TextDecoder().decode(decodePublicationBase64url(retained, PUBLICATION_LIMITS.keysetBytes))).keys;
    const oldSigner = oldKeys.find((key) => key.kid === this.#catalog.kid);
    if (canonicalPublicationJson(signer.jwk) !== canonicalPublicationJson(oldSigner?.jwk)) return null;
    return this.#catalog;
  }

  cached(revision) {
    if (!revisionValid(revision)) rejected();
    const catalog = this.#currentCatalog();
    if (!catalog) return null;
    if (catalog.payload.engine !== PARAMETER_ENGINE || catalog.payload.parameter_schema !== PACKAGED_SIGNING_RULE_SCHEMA) {
      throw new ParameterSourceError('parameter_engine_unsupported');
    }
    const entry = catalog.payload.rules.find((value) => value.source_revision === revision);
    const rule = entry ? this.#objects.get(entry.sha256) : null;
    return rule ? freezePublication({ rule, provenance: { sha256: entry.sha256, source_revision: revision, engine: PARAMETER_ENGINE }, epoch: this.#epoch }) : null;
  }

  inspect(revision) {
    if (!revisionValid(revision)) rejected();
    const catalog = this.#currentCatalog();
    if (catalog === null) return 'unavailable';
    if (catalog.payload.engine !== PARAMETER_ENGINE || catalog.payload.parameter_schema !== PACKAGED_SIGNING_RULE_SCHEMA) return 'unsupported_engine';
    const entry = catalog.payload.rules.find((value) => value.source_revision === revision);
    return !entry ? 'not_published' : this.#objects.has(entry.sha256) ? 'eligible' : 'object_missing';
  }

  hasAlternativeRevision(revision) {
    if (!revisionValid(revision)) rejected();
    const catalog = this.#currentCatalog();
    return catalog !== null && catalog.payload.engine === PARAMETER_ENGINE
      && catalog.payload.parameter_schema === PACKAGED_SIGNING_RULE_SCHEMA
      && catalog.payload.rules.some((entry) => entry.source_revision !== revision);
  }

  #fingerprint() {
    const catalog = this.#catalog;
    const key = this.#keyset?.payload.keys.find((value) => value.kid === catalog?.kid);
    return canonicalPublicationJson({ rules: catalog?.payload.rules ?? null, engine: catalog?.payload.engine ?? null,
      schema: catalog?.payload.parameter_schema ?? null, key: key?.jwk ?? null, not_before: key?.not_before ?? null, not_after: key?.not_after ?? null });
  }

  #mutate(task, signal, authority = false) {
    const pending = this.#chain.then(async () => {
      this.#assertOpen();
      throwIfAborted(signal);
      const before = this.#fingerprint();
      const next = task(structuredClone(this.#state));
      if (next === null) return;
      next.clock_high_water = this.#time();
      if (utf8ByteLength(JSON.stringify(next), MAX_STATE_BYTES) > MAX_STATE_BYTES) unavailable();
      this.#busy = authority;
      try {
        // Save is non-cancelable once entered. An uncertain write poisons this
        // owner rather than allowing its older in-memory authority to resume.
        await this.#persistence.save(structuredClone(next));
        this.#state = next;
        const retainedObjects = new Set(next.objects.map((object) => object.sha256));
        for (const digest of this.#objects.keys()) if (!retainedObjects.has(digest)) this.#objects.delete(digest);
        if (next.keyset !== null) this.#keyset = await verifyPublisherKeyset(next.keyset.jws, this.#trust, { now: this.#time(), allowExpired: true });
        if (next.catalog !== null) {
          const retained = await verifyPublisherKeyset(next.catalog.keyset_jws, this.#trust, { now: this.#time(), allowExpired: true });
          this.#catalog = await verifyParameterCatalog(next.catalog.jws, retained, { now: this.#time(), allowExpired: true });
        }
        if (before !== this.#fingerprint()) this.#epoch++;
      } catch {
        this.#failure = true;
        unavailable();
      } finally { this.#busy = false; }
      throwIfAborted(signal);
    });
    this.#chain = pending.catch(() => undefined);
    return pending;
  }

  #record(verified) {
    return { jws: verified.jws, sequence: verified.payload.sequence, payload_sha256: verified.payload_sha256 };
  }

  #monotonic(previous, next) {
    if (previous && (next.sequence < previous.sequence
      || (next.sequence === previous.sequence && next.payload_sha256 !== previous.payload_sha256))) rejected();
    return previous?.sequence !== next.sequence;
  }

  async #acceptMetadata(envelope, signal) {
    if (envelope.keyset === null) return;
    const keyset = await runAbortable(signal, () => verifyPublisherKeyset(envelope.keyset, this.#trust, { now: this.#time() }));
    await this.#mutate((state) => {
      const record = this.#record(keyset);
      if (!this.#monotonic(state.keyset, record)) return null;
      state.keyset = record;
      return state;
    }, signal, true);
    const catalog = await runAbortable(signal, () => verifyParameterCatalog(envelope.catalog, keyset, { now: this.#time() }));
    await this.#mutate((state) => {
      if (state.keyset.payload_sha256 !== keyset.payload_sha256) rejected();
      const record = this.#record(catalog);
      if (!this.#monotonic(state.catalog, record)) return null;
      state.catalog = { ...record, keyset_jws: keyset.jws };
      const digests = new Set(catalog.payload.rules.map((value) => value.sha256));
      state.objects = state.objects.filter((value) => digests.has(value.sha256));
      return state;
    }, signal, true);
    throwIfAborted(signal);
  }

  async authorize(provenance, { signal = null, epoch = null } = {}) {
    throwIfAborted(signal);
    this.assertEligible(provenance, epoch);
    const now = this.#time();
    await this.#mutate((state) => state.clock_high_water < now ? state : null, signal);
    this.assertEligible(provenance, epoch);
  }

  assertEligible(provenance, epoch = null) {
    if (!provenance || !digestValid(provenance.sha256) || provenance.engine !== PARAMETER_ENGINE
      || !revisionValid(provenance.source_revision)) rejected();
    const cached = this.cached(provenance.source_revision);
    if (!cached || cached.provenance.sha256 !== provenance.sha256 || (epoch !== null && epoch !== this.#epoch)) {
      throw new ParameterSourceError('parameters_unavailable');
    }
    return cached;
  }

  matchesGeneration(generation) {
    const provenance = generation?.summary?.parameter_provenance;
    const cached = provenance ? this.assertEligible(provenance) : null;
    return cached !== null && generationMatchesPackagedRule(generation, { get: (revision) => revision === provenance.source_revision ? cached.rule : null });
  }

  async #performResolve(revision, signal) {
    this.#neededRevision = revision;
    let retryWithoutDigest = false;
    for (let attempt = 0; attempt < 2; attempt++) {
      this.#assertOpen();
      let cached = null;
      try { cached = this.cached(revision); }
      catch (error) { if (error.code !== 'parameter_engine_unsupported') throw error; }
      const request = freezePublication({ schema: 'signing-parameter-request/v1', engine: PARAMETER_ENGINE,
        parameter_schema: PACKAGED_SIGNING_RULE_SCHEMA, source_revision: revision,
        catalog_sequence: this.#state.catalog?.sequence ?? 0, keyset_sequence: this.#state.keyset?.sequence ?? 0,
        object_sha256: retryWithoutDigest ? null : cached?.provenance.sha256 ?? null });
      let rawEnvelope;
      try {
        rawEnvelope = await runAbortable(signal, () => this.#resolver(request, { signal }));
      } catch {
        throwIfAborted(signal);
        throw new ParameterSourceError('parameters_unavailable');
      }
      const envelope = snapshotEnvelope(rawEnvelope);
      throwIfAborted(signal);
      await this.#acceptMetadata(envelope, signal);
      const catalog = this.#currentCatalog();
      if (catalog && (catalog.payload.engine !== PARAMETER_ENGINE || catalog.payload.parameter_schema !== PACKAGED_SIGNING_RULE_SCHEMA)) {
        throw new ParameterSourceError('parameter_engine_unsupported');
      }
      const entry = catalog?.payload.rules.find((value) => value.source_revision === revision);
      if (envelope.status === 'available') {
        if (!entry) rejected();
        const rule = await runAbortable(signal, () => verifyParameterObject(
          decodePublicationBase64url(envelope.object, PUBLICATION_LIMITS.objectBytes), entry));
        const epoch = this.#epoch;
        await this.#mutate((state) => {
          if (epoch !== this.#epoch || state.catalog.payload_sha256 !== catalog.payload_sha256) rejected();
          state.objects = state.objects.filter((value) => value.sha256 !== entry.sha256);
          state.objects.push({ sha256: entry.sha256, object: envelope.object });
          state.objects = state.objects.slice(-MAX_CACHE_OBJECTS);
          return state;
        }, signal);
        this.#objects.set(entry.sha256, rule);
      } else if (envelope.status === 'not_modified') {
        const match = this.cached(revision);
        if (!match || match.provenance.sha256 !== envelope.sha256 || request.object_sha256 !== envelope.sha256) {
          if (attempt !== 0) rejected();
          retryWithoutDigest = true;
          continue;
        }
      } else if (envelope.status === 'unsupported_engine') {
        // Advice cannot manufacture incompatibility with verified compatible data.
        rejected();
      } else if (envelope.status === 'unavailable') {
        this.#neededRevision = revision;
        this.#lastState = 'unavailable';
        throw new ParameterSourceError('parameters_unavailable', envelope.retry_after_ms);
      } else {
        if (envelope.status === 'not_published' && entry) rejected();
        this.#neededRevision = revision;
        this.#lastState = envelope.status;
        throw new ParameterSourceError('parameters_pending', envelope.retry_after_ms);
      }
      const eligible = this.cached(revision);
      if (!eligible) unavailable();
      await this.authorize(eligible.provenance, { signal, epoch: eligible.epoch });
      this.#neededRevision = null;
      this.#lastState = 'ready';
      return eligible;
    }
    rejected();
  }

  async resolve(revision, { signal = null, allowFetch = true, refresh = false } = {}) {
    throwIfAborted(signal);
    this.#assertOpen();
    let cached = null;
    try { cached = this.cached(revision); }
    catch (error) { if (error.code !== 'parameter_engine_unsupported' || !refresh || !allowFetch) throw error; }
    if (cached && !refresh) {
      await this.authorize(cached.provenance, { signal, epoch: cached.epoch });
      return cached;
    }
    if (!allowFetch) throw new ParameterSourceError('parameters_unavailable');
    let operation = this.#operations.get(revision);
    if (!operation || operation.controller.signal.aborted) {
      operation = { controller: new AbortController(), waiters: 0, promise: null };
      const transport = createTransportOperation(operation.controller.signal, this.#timeout);
      operation.promise = runAbortable(transport.signal, () => this.#performResolve(revision, transport.signal))
        .catch((error) => {
          if (operation.controller.signal.aborted) throw abortError(operation.controller.signal);
          if (transport.signal.aborted) throw new ParameterSourceError('parameters_unavailable');
          throw error;
        }).finally(() => {
          transport.dispose();
          if (this.#operations.get(revision) === operation) this.#operations.delete(revision);
        });
      this.#operations.set(revision, operation);
    }
    operation.waiters++;
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      operation.waiters--;
      if (signal?.aborted && operation.waiters === 0) operation.controller.abort(abortError(signal));
    };
    try { return await awaitWithAbort(operation.promise, signal, release); }
    finally { release(); }
  }

  async resume({ signal = null } = {}) {
    if (this.#neededRevision !== null) await this.resolve(this.#neededRevision, { signal, refresh: true });
  }

  status() {
    let state = this.#lastState;
    try {
      const catalog = this.#currentCatalog();
      if (!catalog) state = this.#catalog ? 'unavailable' : 'empty';
      else if (catalog.payload.engine !== PARAMETER_ENGINE || catalog.payload.parameter_schema !== PACKAGED_SIGNING_RULE_SCHEMA) state = 'unsupported_engine';
    }
    catch { state = 'unavailable'; }
    return Object.freeze({ schema: 'signing-parameter-source-status/v1', mode: 'verified', state });
  }

  async close() {
    this.#closed = true;
    for (const operation of this.#operations.values()) operation.controller.abort(new DOMException('Parameter source closed.', 'AbortError'));
    await Promise.allSettled([...this.#operations.values()].map((operation) => operation.promise));
    await this.#chain;
    if (owners.get(this.#persistence) === this) owners.delete(this.#persistence);
  }
}

export async function createVerifiedSigningParameterSource(options, { signal = null } = {}) {
  throwIfAborted(signal);
  const source = new ParameterSource(options);
  await source.initialize(signal);
  const api = Object.freeze(Object.fromEntries(['cached', 'inspect', 'hasAlternativeRevision', 'resolve', 'authorize', 'assertEligible', 'matchesGeneration', 'resume', 'status', 'close']
    .map((name) => [name, source[name].bind(source)])));
  sources.add(api);
  return api;
}

export function isVerifiedSigningParameterSource(source) { return sources.has(source); }
