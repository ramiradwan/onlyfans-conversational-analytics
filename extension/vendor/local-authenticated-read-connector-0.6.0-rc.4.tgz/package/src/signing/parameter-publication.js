import { PACKAGED_SIGNING_RULE_SCHEMA, validatePackagedSigningRule } from './packaged-rule.js';
import { MAX_REVISION_LENGTH } from './validation-limits.js';
import { canonicalPublicationJson, closedObject, freezePublication, parsePublicationJson } from './publication-json.js';

export const PARAMETER_ENGINE = 'onlyfans-sha1-checksum/v1';
export const PUBLICATION_LIMITS = Object.freeze({
  objectBytes: 16 * 1024, catalogBytes: 32 * 1024, keysetBytes: 16 * 1024,
  responseBytes: 256 * 1024 - 1, revisions: 128, publisherKeys: 8, roots: 4,
  clockToleranceSeconds: 300, catalogLifetimeSeconds: 7 * 24 * 3600,
  keysetLifetimeSeconds: 366 * 24 * 3600,
});
export const PUBLICATION_TYPES = Object.freeze({
  catalog: 'signing-parameter-catalog+jws', keyset: 'signing-publisher-keyset+jws',
});
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
const identifier = (value) => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(value);
const revision = (value) => typeof value === 'string' && value.length >= 1 && value.length <= MAX_REVISION_LENGTH && !/[^\x21-\x7e]/.test(value);
const integer = (value, minimum = 0) => Number.isSafeInteger(value) && value >= minimum;
const verifiedKeysets = new WeakSet();

export class ParameterPublicationError extends Error {
  constructor(code = 'parameter_publication_rejected') {
    super('Signing parameter publication is not eligible.');
    this.name = 'ParameterPublicationError';
    this.code = code;
  }
}
const reject = () => { throw new ParameterPublicationError(); };

export function publicationBase64url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
}

export function decodePublicationBase64url(text, maximum) {
  if (typeof text !== 'string' || !/^[A-Za-z0-9_-]+$/.test(text)
    || text.length > Math.ceil(maximum * 4 / 3) || text.length % 4 === 1) reject();
  let bytes;
  try {
    const binary = atob(text.replaceAll('-', '+').replaceAll('_', '/'));
    bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
  } catch { reject(); }
  if (bytes.length > maximum || publicationBase64url(bytes) !== text) reject();
  return bytes;
}

export async function publicationSha256(bytes) {
  return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)),
    (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function jwk(value) {
  if (!closedObject(value, ['kty', 'crv', 'x', 'y']) || value.kty !== 'EC' || value.crv !== 'P-256') reject();
  if (decodePublicationBase64url(value.x, 32).length !== 32 || decodePublicationBase64url(value.y, 32).length !== 32) reject();
  return value;
}

export function validatePublicationTrust(input) {
  // Snapshot trusted configuration; the raw-envelope resolver never supplies it.
  let trust;
  try { trust = structuredClone(input); } catch { reject(); }
  if (!closedObject(trust, ['schema', 'roots']) || trust.schema !== 'signing-publication-trust/v1'
    || !Array.isArray(trust.roots) || trust.roots.length < 1 || trust.roots.length > PUBLICATION_LIMITS.roots) reject();
  const seen = new Set();
  for (const root of trust.roots) {
    if (!closedObject(root, ['kid', 'jwk']) || !identifier(root.kid) || seen.has(root.kid)) reject();
    seen.add(root.kid);
    jwk(root.jwk);
  }
  return freezePublication(trust);
}

function lifetime(payload, now, maximum) {
  if (!integer(now) || !integer(payload.issued_at) || !integer(payload.expires_at, 1)
    || payload.expires_at <= payload.issued_at || payload.expires_at - payload.issued_at > maximum
    || payload.issued_at > now + PUBLICATION_LIMITS.clockToleranceSeconds
    || now >= payload.expires_at) reject();
}

async function signature(jws, typ, keys, maximum) {
  if (typeof jws !== 'string' || jws.length > Math.ceil(maximum * 4 / 3) + 1024) reject();
  const parts = jws.split('.');
  if (parts.length !== 3) reject();
  const headerBytes = decodePublicationBase64url(parts[0], 512);
  const payloadBytes = decodePublicationBase64url(parts[1], maximum);
  const signatureBytes = decodePublicationBase64url(parts[2], 64);
  let header;
  try {
    const text = decoder.decode(headerBytes);
    header = parsePublicationJson(text);
    if (canonicalPublicationJson(header) !== text) reject();
  } catch { reject(); }
  if (!closedObject(header, ['alg', 'kid', 'typ']) || header.alg !== 'ES256'
    || header.typ !== typ || !identifier(header.kid) || signatureBytes.length !== 64) reject();
  const signer = keys.find((key) => key.kid === header.kid);
  if (!signer) reject();
  try {
    const key = await crypto.subtle.importKey('jwk', jwk(signer.jwk), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    if (!await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, signatureBytes,
      encoder.encode(parts[0] + '.' + parts[1]))) reject();
  } catch { reject(); }
  // Authenticate the exact bytes before parsing or making publication decisions.
  let payload;
  try {
    const text = decoder.decode(payloadBytes);
    payload = parsePublicationJson(text);
    if (canonicalPublicationJson(payload) !== text) reject();
  } catch { reject(); }
  return { payload, payload_sha256: await publicationSha256(payloadBytes), kid: header.kid, jws };
}

export async function verifyPublisherKeyset(jws, trust, { now = Math.floor(Date.now() / 1000), allowExpired = false } = {}) {
  const pinnedTrust = validatePublicationTrust(trust);
  const verified = await signature(jws, PUBLICATION_TYPES.keyset, pinnedTrust.roots, PUBLICATION_LIMITS.keysetBytes);
  const value = verified.payload;
  if (!closedObject(value, ['schema', 'sequence', 'issued_at', 'expires_at', 'keys'])
    || value.schema !== 'signing-publisher-keyset/v1' || !integer(value.sequence, 1)
    || !Array.isArray(value.keys) || value.keys.length < 1 || value.keys.length > PUBLICATION_LIMITS.publisherKeys) reject();
  // Expired metadata may only reconstruct an existing rollback checkpoint.
  lifetime(value, allowExpired ? Math.min(now, value.expires_at - 1) : now, PUBLICATION_LIMITS.keysetLifetimeSeconds);
  const seen = new Set();
  for (const key of value.keys) {
    if (!closedObject(key, ['kid', 'jwk', 'not_before', 'not_after']) || !identifier(key.kid)
      || seen.has(key.kid) || !integer(key.not_before) || !integer(key.not_after, 1)
      || key.not_before < value.issued_at || key.not_after > value.expires_at || key.not_after <= key.not_before) reject();
    seen.add(key.kid);
    jwk(key.jwk);
    if (pinnedTrust.roots.some((root) => root.kid === key.kid || canonicalPublicationJson(root.jwk) === canonicalPublicationJson(key.jwk))) reject();
    try { await crypto.subtle.importKey('jwk', key.jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']); }
    catch { reject(); }
  }
  const result = freezePublication(verified);
  verifiedKeysets.add(result);
  return result;
}

export async function verifyParameterCatalog(jws, keyset, { now = Math.floor(Date.now() / 1000), allowExpired = false } = {}) {
  // Verification material is a verifier result, never a resolver-owned key list.
  if (!verifiedKeysets.has(keyset)) reject();
  const verified = await signature(jws, PUBLICATION_TYPES.catalog, keyset.payload.keys, PUBLICATION_LIMITS.catalogBytes);
  const value = verified.payload;
  if (!closedObject(value, ['schema', 'sequence', 'issued_at', 'expires_at', 'platform', 'engine', 'parameter_schema', 'rules'])
    || value.schema !== 'signing-parameter-catalog/v1' || !integer(value.sequence, 1)
    || value.platform !== 'onlyfans' || typeof value.engine !== 'string' || !/^[\x21-\x7e]{1,64}$/.test(value.engine)
    || typeof value.parameter_schema !== 'string' || !/^[\x21-\x7e]{1,64}$/.test(value.parameter_schema)
    || !Array.isArray(value.rules) || value.rules.length > PUBLICATION_LIMITS.revisions) reject();
  lifetime(value, allowExpired ? Math.min(now, value.expires_at - 1) : now, PUBLICATION_LIMITS.catalogLifetimeSeconds);
  const signer = keyset.payload.keys.find((key) => key.kid === verified.kid);
  if (value.issued_at < signer.not_before || value.expires_at > signer.not_after
    || (!allowExpired && now >= keyset.payload.expires_at)) reject();
  let previous = null;
  for (const rule of value.rules) {
    if (!closedObject(rule, ['source_revision', 'sha256', 'size']) || !revision(rule.source_revision)
      || (previous !== null && previous >= rule.source_revision) || typeof rule.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(rule.sha256)
      || !integer(rule.size, 1) || rule.size > PUBLICATION_LIMITS.objectBytes) reject();
    previous = rule.source_revision;
  }
  return freezePublication(verified);
}

export async function verifyParameterObject(input, entry) {
  if (!(input instanceof Uint8Array) || input.byteLength < 1 || input.byteLength > PUBLICATION_LIMITS.objectBytes) reject();
  const bytes = new Uint8Array(input);
  if (bytes.length !== entry.size || await publicationSha256(bytes) !== entry.sha256) reject();
  let rule;
  try { rule = validatePackagedSigningRule(parsePublicationJson(decoder.decode(bytes))); } catch { reject(); }
  if (rule.schema !== PACKAGED_SIGNING_RULE_SCHEMA || rule.source_revision !== entry.source_revision) reject();
  return rule;
}
