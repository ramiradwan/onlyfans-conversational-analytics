import { createSignatureFromDigest, validateRenewableSigningConfig } from './renewable-signing.js';

export const DIGEST_CONTROL_KIND = 'digest-with-recomputed-checksum';

/** Keep valid framing/checksum; change only the digest, and therefore sign. */
export function createDigestNegativeControl(config, sign) {
  const validated = validateRenewableSigningConfig(config);
  if (typeof sign !== 'string') throw new TypeError('Digest control requires a signature.');
  const digest = sign.slice(validated.format.prefix.length + 1, validated.format.prefix.length + 41);
  if (!/^[0-9a-f]{40}$/.test(digest)
    || createSignatureFromDigest({ config: validated, digest }) !== sign) {
    throw new TypeError('Digest control requires the configured signature framing and checksum.');
  }
  const changed = `${digest[0] === '0' ? '1' : '0'}${digest.slice(1)}`;
  return createSignatureFromDigest({ config: validated, digest: changed });
}
