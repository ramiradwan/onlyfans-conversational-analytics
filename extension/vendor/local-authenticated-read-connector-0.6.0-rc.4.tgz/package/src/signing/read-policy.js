/** Backend revision metadata never establishes a need to replace request signing data. */
export function requiresSigningRefresh() {
  return false;
}
