import { observeSigningOperation, validateDiagnosticCallback } from './diagnostics.js';
import { buildHistoryKindEvidence } from './history-evidence.js';
import { attachHistoryEventKinds } from './history-event-kind.js';
import { signingStatus } from './provider-status.js';
import { isVerifiedSigningParameterSource } from './parameter-source.js';
import {
  abortError, awaitWithAbort, runAbortable, throwIfAborted,
  DEFAULT_TRANSPORT_TIMEOUT_MS, validateTimeout, withTransport,
} from './async-operation.js';
import { transitionPrecondition } from './generation-store.js';
import { createDigestNegativeControl, DIGEST_CONTROL_KIND } from './digest-control.js';
import {
  canRunNegativeControl,
  CURRENT_PROOF_POLICY_VERSION,
  hasCurrentGenerationProof,
} from './proof-policy.js';
import { buildOperationRequest, snapshotOperationParameters } from './operations.js';
import {
  createGenerationFromPackagedRule,
  createPackagedSigningRuleRegistry,
  generationMatchesPackagedRule,
} from './packaged-rule.js';
import {
  createPortableRenewableAdapter,
  webCryptoSha1Hex,
} from './renewable-signing.js';
import {
  classifyDifferentialProof,
  normalizeIdentifier,
  parseTypedResponse,
  publicResponseSummary,
} from './response.js';

// Retained for public compatibility; these statuses alone do not authorize refresh.
const AUTHORIZATION_STATUSES = new Set([401, 403]);

export class BrowserSigningError extends Error {
  constructor(code, message, options = {}) {
    super(message, options);
    this.name = 'BrowserSigningError';
    this.code = code;
  }
}

export async function prepareGenerationRequest({
  generation,
  operation,
  parameters = {},
  sha1Hex = webCryptoSha1Hex,
  now = Date.now,
  signal = null,
}) {
  throwIfAborted(signal);
  const request = buildOperationRequest(operation, parameters);
  const adapter = createPortableRenewableAdapter({
    config: generation.config,
    sha1Hex,
  });
  const prepared = await runAbortable(signal, () => adapter.prepare({
    method: request.method,
    url: request.url,
    session: generation.context.session,
    now,
  }));
  throwIfAborted(signal);
  return {
    operation,
    method: request.method,
    url: request.url.toString(),
    headers: prepared.headers,
    controlHeaders: prepared.controlHeaders,
  };
}

export class BrowserSigningProvider {
  #parameterSource;
  #neededParameterRevision = null;

  constructor({
    store,
    host,
    packagedRule,
    parameterSource = null,
    sha1Hex = webCryptoSha1Hex,
    now = Date.now,
    expectedIdentity = null,
    captureMode = 'safe-reload',
    transportTimeoutMs = DEFAULT_TRANSPORT_TIMEOUT_MS,
    onDiagnostic = null,
  }) {
    if (!store?.active || !store?.activate || !store?.rollback || !store?.readState) {
      throw new TypeError('Browser signing provider requires a generation store.');
    }
    if (!host?.captureIdentity || !host?.executeTypedRead) {
      throw new TypeError('Browser signing provider requires a browser host adapter.');
    }
    this.onDiagnostic = validateDiagnosticCallback(onDiagnostic);
    this.transportTimeoutMs = validateTimeout(transportTimeoutMs);
    this.store = store;
    this.host = host;
    if (parameterSource !== null && (packagedRule !== undefined || !isVerifiedSigningParameterSource(parameterSource))) {
      throw new TypeError('Choose one explicit packaged rule or a verified parameter source.');
    }
    this.#parameterSource = parameterSource;
    this.packagedRuleRegistry = parameterSource === null ? createPackagedSigningRuleRegistry([packagedRule])
      : Object.freeze({ get: (revision) => parameterSource.cached(revision)?.rule ?? null });
    this.sha1Hex = sha1Hex;
    this.now = now;
    if (expectedIdentity !== null && normalizeIdentifier(expectedIdentity) === null) {
      throw new TypeError('Browser signing provider expected identity is invalid.');
    }
    this.expectedIdentity = expectedIdentity === null ? null : normalizeIdentifier(expectedIdentity);
    if (!['safe-reload', 'observe-only'].includes(captureMode)) {
      throw new TypeError('Browser signing captureMode must be safe-reload or observe-only.');
    }
    this.captureMode = captureMode;
    this.refreshOperation = null;
    this.lifecycleChain = Promise.resolve();
  }

  async read(options) {
    return observeSigningOperation(this.onDiagnostic, {
      event: 'read', operation: options?.operation, signal: options?.signal,
    }, () => this.#read(options));
  }

  async readHistoryWithEvidence(options) {
    // The observer still receives exactly the legacy read result. Evidence is
    // local to this invocation and assigned only after the final accepted attempt.
    let evidence = null;
    const read = await observeSigningOperation(this.onDiagnostic, {
      event: 'read', operation: 'message-page', signal: options?.signal,
    }, () => {
      const { parameters, refreshMode = 'allow', signal = null } = options;
      return this.#read({ operation: 'message-page', parameters, refreshMode, signal },
        (value) => { evidence = value; });
    });
    return { schema: 'browser-signing-history-evidence-read/v1', read, evidence };
  }

  async #read({ operation, parameters = {}, refreshMode = 'allow', signal = null }, evidenceSink = null) {
    throwIfAborted(signal);
    if (!['allow', 'never'].includes(refreshMode)) {
      throw new TypeError('Browser signing read refreshMode must be allow or never.');
    }
    parameters = snapshotOperationParameters(operation, parameters);
    let generation = await runAbortable(signal, () => this.store.active());
    let refreshed = false;
    let refreshReason = null;
    let operationHost = null;
    let parameterRevisionChanged = false;
    if (this.#parameterSource !== null && this.#neededParameterRevision !== null) {
      if (generation !== null) this.#assertGenerationIdentity(generation);
      await this.#parameterSource.resolve(this.#neededParameterRevision, { signal, allowFetch: refreshMode !== 'never' });
      parameterRevisionChanged = generation !== null && generation.config.source_revision !== this.#neededParameterRevision;
      this.#neededParameterRevision = null;
      throwIfAborted(signal);
    }
    if (this.#parameterSource !== null && generation !== null && !parameterRevisionChanged) {
      this.#assertGenerationIdentity(generation);
      const revision = generation.config.source_revision;
      if (this.#parameterSource.inspect(revision) === 'not_published' && this.#parameterSource.hasAlternativeRevision(revision)) {
        if (refreshMode === 'never') throw new BrowserSigningError('parameters_unavailable', 'Stored parameters are no longer authorized.');
        parameterRevisionChanged = true;
      } else {
        try { await this.#parameterSource.resolve(revision, { signal, allowFetch: refreshMode !== 'never' }); }
        catch (error) {
          // Withdrawal forbids using the old generation, not observation of the
          // current document. One fresh permitted observation can discover B
          // even when the old A mapping was withdrawn before this read.
          if (refreshMode !== 'never' && error?.code === 'parameters_pending' && this.#parameterSource.inspect(revision) === 'not_published'
            && this.#parameterSource.hasAlternativeRevision(revision)) {
            parameterRevisionChanged = true;
          } else throw error;
        }
      }
      throwIfAborted(signal);
    }
    if (generation !== null && !parameterRevisionChanged && this.#matchesGeneration(generation)
      && hasCurrentGenerationProof(generation)) operationHost = await this.#openHost(false, signal);
    const generationReason = generation === null
      ? 'missing-active-generation'
      : parameterRevisionChanged ? 'parameter-authority-changed'
        : !this.#matchesGeneration(generation)
        ? 'active-generation-not-packaged'
        : !hasCurrentGenerationProof(generation)
          ? 'active-generation-proof-obsolete'
          : this.#matchesDocument(generation, operationHost) ? null : 'active-generation-document-changed';
    if (generationReason !== null) {
      if (refreshMode === 'never') this.#refreshRequired(generationReason);
      const refresh = await this.#refresh({ reason: generationReason, signal }, operationHost);
      generation = refresh.result.generation;
      operationHost = refresh.host;
      refreshed = true;
      refreshReason = generationReason;
    }
    this.#assertGeneration(generation);

    operationHost ??= await this.#openHost(false, signal);
    const attempt = await this.#attempt(generation, operation, parameters, signal, operationHost, evidenceSink !== null);
    // Successful typed responses remain usable across backend metadata changes.
    // Error/retry policy remains with callers; revision metadata grants no authority.

    throwIfAborted(signal);

    if (evidenceSink !== null) evidenceSink(attempt.evidence);
    return {
      schema: 'browser-signing-read/v1',
      operation,
      generation_id: generation.id,
      refreshed,
      refresh_reason: refreshReason,
      success: attempt.summary.semantic_success,
      response: publicResponseSummary({
        ...attempt.summary,
        retry_after_ms: attempt.retryAfterMs,
      }),
      data: attempt.data,
    };
  }

  async refresh(options = {}) {
    return observeSigningOperation(this.onDiagnostic, {
      event: 'refresh', signal: options?.signal,
    }, async () => (await this.#refresh(options)).result);
  }

  // Unbound callers may share capture/proof and adopt that operation's host.
  // A recovery already bound to a document must not join an unrelated refresh.
  async #refresh({ reason = 'manual', signal = null } = {}, operationHost = null) {
    throwIfAborted(signal);
    const scoped = operationHost !== null && operationHost !== this.host;
    if (this.refreshOperation?.controller.signal.aborted) this.refreshOperation = null;
    let operation = scoped ? null : this.refreshOperation;
    const reused = operation !== null;
    if (!reused) {
      operation = {
        controller: new AbortController(),
        waiters: 0,
        promise: null,
        host: operationHost,
      };
      operation.promise = this.#runLifecycle(
        async () => {
          // Select only when this lifecycle starts, not while it waits in queue.
          if (this.#parameterSource !== null && this.#neededParameterRevision !== null) {
            await this.#parameterSource.resolve(this.#neededParameterRevision, { signal: operation.controller.signal });
            this.#neededParameterRevision = null;
          }
          throwIfAborted(operation.controller.signal);
          operation.host ??= await this.#openHost(true, operation.controller.signal);
          return this.#performRefresh(reason, operation.controller.signal, operation.host);
        },
        operation.controller.signal,
      ).finally(() => {
        if (this.refreshOperation === operation) this.refreshOperation = null;
      });
      if (!scoped) this.refreshOperation = operation;
    }

    operation.waiters += 1;
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      operation.waiters -= 1;
      if (signal?.aborted && operation.waiters === 0) {
        // Retire synchronously, including private document-bound recoveries.
        if (this.refreshOperation === operation) this.refreshOperation = null;
        operation.controller.abort(abortError(signal));
      }
    };
    try {
      const generation = await awaitWithAbort(operation.promise, signal, release);
      return {
        result: { generation, refreshed: !reused, reused, reason },
        host: operation.host,
      };
    } finally {
      release();
    }
  }

  // Existing injected hosts remain valid. Browser hosts implementing this hook
  // return an operation-local adapter, never a persisted account/generation epoch.
  async #openHost(reload, signal) {
    if (typeof this.host.openOperation !== 'function') return this.host;
    let host;
    try {
      host = await this.#transport(signal, (transportSignal) => (
        this.host.openOperation({ reload: reload && this.captureMode === 'safe-reload', signal: transportSignal })
      ));
    } catch (cause) {
      throwIfAborted(signal);
      if (cause?.name === 'AbortError' || ['transport_timeout', 'context_lost', 'refresh_unsafe'].includes(cause?.code)) throw cause;
      throw new BrowserSigningError(
        'browser_unavailable',
        'Open an authenticated OnlyFans tab and retry the operation.',
        { cause },
      );
    }
    if (!host?.captureIdentity || !host?.executeTypedRead || !host?.assertContext) {
      throw new TypeError('Browser operation host is invalid.');
    }
    return host;
  }

  async #assertContext(host, signal) {
    if (typeof host.assertContext === 'function') {
      await this.#transport(signal, (transportSignal) => host.assertContext({ signal: transportSignal }));
    }
    throwIfAborted(signal);
  }

  #documentIdentity(host) {
    const id = host?.documentIdentity;
    return typeof id === 'string' && /^[\x21-\x7e]{1,128}$/.test(id) ? id : null;
  }

  #matchesDocument(generation, host) {
    const id = this.#documentIdentity(host);
    return id !== null && generation.summary?.activation_document === id;
  }

  async #reproducePrevious(previous, host, signal) {
    const capture = await this.#transport(signal, (innerSignal) => host.captureIdentity({ reload: false, signal: innerSignal }));
    const capturedDocument = this.#documentIdentity(host);
    const rule = this.packagedRuleRegistry.get(previous.config.source_revision);
    let derived;
    try {
      derived = await runAbortable(signal, () => createGenerationFromPackagedRule({
        rule, capture, sha1Hex: this.sha1Hex, expectedIdentity: this.expectedIdentity,
      }));
    } catch (cause) {
      throwIfAborted(signal);
      if (cause?.name === 'AbortError') throw cause;
      throw new BrowserSigningError('rollback_revision_stale', 'The current native signer does not reproduce the previous rule.', { cause });
    }
    const headers = derived.config.headers;
    if (derived.context.session.userId !== previous.context.session.userId
      || Object.keys(headers).length !== Object.keys(previous.config.headers).length
      || Object.entries(headers).some(([key, value]) => previous.config.headers[key] !== value)) {
      throw new BrowserSigningError('rollback_revision_stale', 'The previous signing context requires fresh activation.');
    }
    await this.#assertContext(host, signal);
    this.#assertDocumentIdentity(host, capturedDocument);
    return capturedDocument;
  }

  #assertDocumentIdentity(host, expected) {
    if (this.#documentIdentity(host) !== expected) throw new BrowserSigningError('context_lost', 'Signing document changed.');
  }

  async rollback(options = {}) {
    return observeSigningOperation(this.onDiagnostic, {
      event: 'rollback', signal: options?.signal,
    }, () => this.#rollback(options));
  }

  async #rollback({ signal = null } = {}) {
    throwIfAborted(signal);
    return awaitWithAbort(this.#runLifecycle(() => this.#performRollback(signal), signal), signal);
  }

  // Only lifecycle operations share this queue. Reads use detached, validated
  // generation snapshots and do not wait for capture or proof network requests.
  #runLifecycle(operation, signal) {
    const pending = this.lifecycleChain.then(() => {
      throwIfAborted(signal);
      return runAbortable(signal, operation);
    });
    this.lifecycleChain = pending.then(() => undefined, () => undefined);
    return pending;
  }

  async #performRollback(signal) {
    throwIfAborted(signal);
    const state = await runAbortable(signal, () => this.store.readState());
    const expected = transitionPrecondition(state);
    const previous = state.previous;
    if (previous === null) {
      throw new BrowserSigningError('no_previous', 'No previous signing generation is available.');
    }
    if (this.#parameterSource !== null) {
      this.#assertGenerationIdentity(previous);
      await this.#parameterSource.resolve(previous.config.source_revision, { signal });
    }
    this.#assertGeneration(previous);
    const lease = this.#parameterSource?.assertEligible(previous.summary.parameter_provenance) ?? null;
    const operationHost = await this.#openHost(false, signal);
    const documentIdentity = this.#matchesDocument(previous, operationHost)
      ? this.#documentIdentity(operationHost) : await this.#reproducePrevious(previous, operationHost, signal);
    const validation = await this.#prove(previous, signal, operationHost, lease, documentIdentity);
    if (validation.proof.outcome !== 'strong') {
      throw new BrowserSigningError(
        'rollback_proof_failed',
        'The previous signing generation failed strong proof and was not activated.',
      );
    }
    throwIfAborted(signal);
    await this.#assertContext(operationHost, signal);
    await this.#authorizeParameters(previous, signal, operationHost, lease);
    const generation = await this.store.rollback({ expected, proof: validation.proof, signal,
      documentIdentity,
      eligibilityGuard: () => {
        this.#assertDocumentIdentity(operationHost, documentIdentity);
        if (lease !== null) this.#parameterSource.assertEligible(lease.provenance, lease.epoch);
      } });
    await this.#assertContext(operationHost, signal);
    this.#assertDocumentIdentity(operationHost, documentIdentity);
    this.#assertGeneration(generation);
    return { generation, proof: validation.proof };
  }

  async status() {
    return observeSigningOperation(this.onDiagnostic, { event: 'status' }, async () => {
      const state = await this.store.readState();
      const browser = this.host.status ? await this.host.status() : null;
      if (this.#parameterSource === null) return signingStatus(state, browser, this.packagedRuleRegistry, this.expectedIdentity);
      let supported = false;
      try { supported = state.active !== null && this.#matchesGeneration(state.active); } catch {}
      const status = signingStatus(state, browser, { get: () => null }, this.expectedIdentity);
      status.schema = 'browser-signing-status/v2';
      status.readiness.supported_rule = state.active === null ? null : supported;
      status.readiness.ready = !supported || status.readiness.tab_available === false
        || status.readiness.current_proof === false || status.readiness.expected_identity_matches === false ? false : null;
      status.parameters = this.#parameterSource.status();
      if (supported) status.parameters = Object.freeze({ ...status.parameters, state: 'ready' });
      return status;
    });
  }

  async #performRefresh(reason, signal, operationHost) {
    throwIfAborted(signal);
    const expected = transitionPrecondition(await runAbortable(signal, () => this.store.readState()));
    throwIfAborted(signal);
    let capture;
    try {
      capture = await this.#transport(signal, (transportSignal) => (
        operationHost.captureIdentity({ reload: this.captureMode === 'safe-reload', signal: transportSignal })
      ));
    } catch (cause) {
      if (signal?.aborted) throw abortError(signal);
      if (cause?.name === 'AbortError' || ['transport_timeout', 'context_lost', 'refresh_unsafe'].includes(cause?.code)) throw cause;
      throw new BrowserSigningError(
        'browser_unavailable',
        'Open an authenticated OnlyFans tab and retry the operation.',
        { cause },
      );
    }

    const captureDocument = this.#documentIdentity(operationHost);
    const requestRevision = capture?.headers?.['x-of-rev'];
    if (
      typeof requestRevision !== 'string' || requestRevision.length === 0 ||
      typeof capture.responseRevision !== 'string' || capture.responseRevision.length === 0
    ) {
      throw new BrowserSigningError(
        'activation_revision_mismatch',
        'The capture requires request and backend revision metadata.',
      );
    }
    if (this.#parameterSource !== null) this.#neededParameterRevision = requestRevision;
    const lease = this.#parameterSource === null ? null : await this.#parameterSource.resolve(requestRevision, { signal });
    if (this.#parameterSource !== null) this.#neededParameterRevision = null;
    if (lease !== null) {
      await this.#assertContext(operationHost, signal);
      this.#parameterSource.assertEligible(lease.provenance, lease.epoch);
    }
    const rule = lease === null ? this.packagedRuleRegistry.get(requestRevision) : lease.rule;
    if (rule === null) this.#unsupportedRevision(requestRevision);

    let derived;
    try {
      derived = await runAbortable(signal, () => createGenerationFromPackagedRule({
        rule,
        capture,
        sha1Hex: this.sha1Hex,
        expectedIdentity: this.expectedIdentity,
      }));
    } catch (cause) {
      if (signal?.aborted) throw abortError(signal);
      if (cause?.name === 'AbortError' || ['transport_timeout', 'context_lost', 'refresh_unsafe'].includes(cause?.code)) throw cause;
      throw new BrowserSigningError(
        'packaged_rule_mismatch',
        'The packaged signing rule did not reproduce the observed identity request.',
        { cause },
      );
    }
    const transient = { config: derived.config, context: derived.context,
      summary: lease === null ? {} : { parameter_provenance: lease.provenance } };
    this.#assertGeneration(transient);
    await this.#assertContext(operationHost, signal);
    if (captureDocument !== this.#documentIdentity(operationHost)) throw new BrowserSigningError('context_lost', 'Capture document changed.');
    const validation = await this.#prove(transient, signal, operationHost, lease, captureDocument);
    if (validation.proof.outcome !== 'strong') {
      throw new BrowserSigningError(
        'activation_proof_failed',
        'New signing rules failed strong differential proof and were not activated.',
      );
    }
    throwIfAborted(signal);
    await this.#assertContext(operationHost, signal);
    await this.#authorizeParameters(transient, signal, operationHost, lease);
    const generation = await this.store.activate({
      signal,
      expected,
      config: derived.config,
      context: derived.context,
      reason,
      proof: validation.proof,
      summary: { packaged_rule: derived.summary, activation_document: captureDocument,
        ...(lease === null ? {} : { parameter_provenance: lease.provenance }) },
      eligibilityGuard: () => {
        this.#assertDocumentIdentity(operationHost, captureDocument);
        if (lease !== null) this.#parameterSource.assertEligible(lease.provenance, lease.epoch);
      },
    });
    await this.#assertContext(operationHost, signal);
    this.#assertDocumentIdentity(operationHost, captureDocument);
    this.#assertGeneration(generation);
    return generation;
  }

  async #prove(generation, signal, operationHost, lease = null, expectedDocument = this.#documentIdentity(operationHost)) {
    throwIfAborted(signal);
    const proofDocument = expectedDocument;
    this.#assertDocumentIdentity(operationHost, proofDocument);
    const request = await prepareGenerationRequest({
      generation,
      operation: 'identity',
      sha1Hex: this.sha1Hex,
      now: this.now,
      signal,
    });
    await this.#authorizeParameters(generation, signal, operationHost, lease);
    this.#assertDocumentIdentity(operationHost, proofDocument);
    const candidate = await this.#transport(signal, (transportSignal) => (
      operationHost.executeTypedRead(request, { signal: transportSignal })
    ));
    if (this.#parameterSource !== null) this.#parameterSource.assertEligible(generation.summary.parameter_provenance, lease?.epoch ?? null);
    const candidateResult = parseTypedResponse({
      operation: 'identity',
      status: candidate.status,
      contentType: candidate.contentType,
      body: candidate.body,
      bodyError: candidate.bodyError,
    });
    await this.#assertContext(operationHost, signal);
    if (proofDocument !== this.#documentIdentity(operationHost)) throw new BrowserSigningError('context_lost', 'Proof document changed.');
    this.#assertIdentityResult(generation, candidateResult.data);
    const controlHeader = request.controlHeaders[0] ?? null;
    const context = {
      expectedRevision: generation.config.source_revision,
      requestRevision: request.headers['x-of-rev'],
      controlKind: DIGEST_CONTROL_KIND,
      candidateRevision: candidate.responseRevision ?? null,
      negativeRevision: null,
      controlHeader,
      timestamp: request.headers.time,
      now: this.now(),
    };
    let negative = null;
    if (canRunNegativeControl(candidateResult.summary, context)) {
      throwIfAborted(signal);
      await this.#authorizeParameters(generation, signal, operationHost, lease);
      this.#assertDocumentIdentity(operationHost, proofDocument);
      negative = await this.#transport(signal, (transportSignal) => operationHost.executeTypedRead({
        ...request,
        headers: {
          ...request.headers,
          [controlHeader]: createDigestNegativeControl(generation.config, request.headers[controlHeader]),
        },
      }, { signal: transportSignal }));
      if (this.#parameterSource !== null) this.#parameterSource.assertEligible(generation.summary.parameter_provenance, lease?.epoch ?? null);
    }
    const negativeResult = negative === null ? null : parseTypedResponse({
      operation: 'identity',
      status: negative.status,
      contentType: negative.contentType,
      body: negative.body,
      bodyError: negative.bodyError,
    });
    await this.#assertContext(operationHost, signal);
    if (proofDocument !== this.#documentIdentity(operationHost)) throw new BrowserSigningError('context_lost', 'Proof document changed.');
    if (negativeResult !== null) this.#assertIdentityResult(generation, negativeResult.data);
    return {
      proof: {
        ...classifyDifferentialProof(candidateResult.summary, negativeResult?.summary ?? null, {
          ...context,
          negativeRevision: negative?.responseRevision ?? null,
          now: this.now(),
        }),
        policy_version: CURRENT_PROOF_POLICY_VERSION,
      },
      responseRevision: candidate.responseRevision ?? null,
      candidateSucceeded: candidateResult.summary.semantic_success,
    };
  }

  #transport(signal, task) {
    return withTransport(signal, this.transportTimeoutMs, task);
  }

  async #attempt(generation, operation, parameters, signal, operationHost, includeEvidence = false) {
    throwIfAborted(signal);
    const request = await prepareGenerationRequest({
      generation,
      operation,
      parameters,
      sha1Hex: this.sha1Hex,
      now: this.now,
      signal,
    });
    await this.#authorizeParameters(generation, signal, operationHost);
    const readDocument = this.#documentIdentity(operationHost);
    if (Object.hasOwn(generation.summary ?? {}, 'activation_document') && generation.summary.activation_document !== readDocument) {
      throw new BrowserSigningError('context_lost', 'Read document no longer matches activation.');
    }
    const response = await this.#transport(signal, (transportSignal) => (
      operationHost.executeTypedRead(request, { signal: transportSignal })
    ));
    throwIfAborted(signal);
    if (this.#parameterSource !== null) this.#parameterSource.assertEligible(generation.summary.parameter_provenance);
    await this.#assertContext(operationHost, signal);
    if (readDocument !== this.#documentIdentity(operationHost)) throw new BrowserSigningError('context_lost', 'Read document changed.');
    const body = response.body;
    const parsed = parseTypedResponse({
      operation,
      parameters,
      status: response.status,
      contentType: response.contentType,
      body,
      bodyError: response.bodyError,
    });
    if (operation === 'identity') this.#assertIdentityResult(generation, parsed.data);
    const evidence = operation === 'message-page' && parsed.data !== null ? buildHistoryKindEvidence({
      body, data: parsed.data, request,
      accountId: this.#assertGenerationIdentity(generation),
      conversationId: parameters.conversationId,
      generationId: generation.id,
    }) : null;
    return {
      responseRevision: response.responseRevision ?? null,
      retryAfterMs: response.retryAfterMs ?? null,
      summary: parsed.summary,
      data: evidence === null ? parsed.data : attachHistoryEventKinds(parsed.data, evidence),
      evidence: includeEvidence ? evidence : null,
    };
  }

  #assertIdentityResult(generation, data) {
    if (data !== null && data.id !== this.#assertGenerationIdentity(generation)) {
      throw new BrowserSigningError(
        'account_mismatch',
        'The authenticated browser identity does not match the signing generation.',
      );
    }
  }

  #assertGeneration(generation) {
    if (!this.#matchesGeneration(generation)) {
      if (this.#parameterSource !== null) {
        throw new BrowserSigningError('parameters_unavailable', 'Authenticated signing parameters are no longer eligible.');
      }
      this.#unsupportedRevision(generation?.config?.source_revision ?? null);
    }
    return this.#assertGenerationIdentity(generation);
  }

  #matchesGeneration(generation) {
    if (this.#parameterSource === null) return generationMatchesPackagedRule(generation, this.packagedRuleRegistry);
    const provenance = generation?.summary?.parameter_provenance;
    const cached = this.#parameterSource.cached(generation?.config?.source_revision);
    return cached !== null && provenance?.sha256 === cached.provenance.sha256
      && provenance.engine === cached.provenance.engine && provenance.source_revision === cached.provenance.source_revision
      && generationMatchesPackagedRule(generation, this.packagedRuleRegistry);
  }

  async #authorizeParameters(generation, signal, operationHost, lease = null) {
    if (this.#parameterSource === null) return;
    this.#assertGenerationIdentity(generation);
    const provenance = generation.summary?.parameter_provenance;
    await this.#parameterSource.authorize(provenance, { signal, epoch: lease?.epoch ?? null });
    await this.#assertContext(operationHost, signal);
    this.#parameterSource.assertEligible(provenance, lease?.epoch ?? null);
    this.#assertGeneration(generation);
  }

  #assertGenerationIdentity(generation) {
    const identity = normalizeIdentifier(generation?.context?.session?.userId);
    if (identity === null || (this.expectedIdentity !== null && identity !== this.expectedIdentity)) {
      throw new BrowserSigningError(
        'account_mismatch',
        'The signing generation does not match the expected creator account.',
      );
    }
    return identity;
  }

  #unsupportedRevision(revision) {
    throw new BrowserSigningError(
      'unsupported_revision',
      'The observed signing revision is not supported by the packaged rule.',
    );
  }

  #refreshRequired(reason) {
    throw new BrowserSigningError(
      'refresh_required',
      `Signing state requires refresh (${reason}), but refresh is disabled for this read.`,
    );
  }
}

export { AUTHORIZATION_STATUSES };
