# Authenticated read connector contract

This specification is intentionally implementation-oriented and may evolve while ADR 0001 remains stable.

## Semantic intent

The public connector receives one named read operation with operation-specific typed parameters. It enforces:

- method is `GET`;
- path is constructed by the selected operation rather than supplied by the caller;
- path contains no traversal or embedded credentials;
- destination origin is fixed by construction;
- request body is absent.

The supported browser operations are `identity`, `conversations`, and `message-page`. Unknown
operations, parameters, or query fields reject before request preparation.

## Session context

```text
session_id          opaque identifier used by the local upstream session
creator_account_id  account discovered and verified in that session
```

The connector uses the context during request preparation but does not return it as authorization authority. A session change invalidates prepared requests.

## Authorization configuration

```text
revision      immutable identifier
secret        simulator-only key material
issued_at     configuration issuance time
```

Live adapters may use different configuration shapes. The surrounding connector depends only on revision identity, validation, atomic activation, and refresh behavior.

The runtime-derived development adapter keeps revision-specific rules and stable request-header values in a gitignored private configuration. The authenticated upstream user ID is kept separately in private session context. Each preparation computes a new timestamp and signature for the exact typed path and serialized query.

## Prepared request

```text
url       fixed origin plus validated path and canonical query
method    GET
headers   authorization adapter output
```

The simulator signs a canonical representation containing method, path, sorted query, issue time, session identifier, and configuration revision. This demonstrates binding and rotation without representing a live platform algorithm.

## Page contract

Each call validates exactly one page. The consumer owns the cross-page schedule, durable cursor,
retry budget, commit boundary, and coverage state. Successful normalized pages contain:

- `items`: observations in the page;
- `continuation`: opaque continuation cursor or `null`;
- `boundary`: explicit terminal evidence: `inventory_end` for conversations or `history_start` for messages.

Conversation items contain exactly `id`, `platform_user_id`, `display_name`, and nullable
`updated_at`. Message items contain exactly `id`, nullable `chat_id`, `sender_platform_user_id`,
`text`, `sent_at`, and nullable `direction`. Unknown wrapper/entity fields and conflicting aliases
reject the whole page. The connector never returns a trusted completion flag or content-derived
digest.

`updated_at` is null when the upstream record carries no conversation-scoped timestamp. Upstream
conversation records were observed to carry no `updated_at`, `updatedAt` or `changedAt` field at
all: the value is derived from the conversation's last message, and the platform omits that last
message for some conversations, including conversations that do have message history. Timestamps
that belong to the counterparty user rather than to the conversation are not substituted for it,
and no timestamp is synthesised. A page is still validated as a whole; a missing timestamp is a
null value, never a dropped or skipped item.

`direction` is derived for platform message pages from the `fromUser.id` and `chatUserId` fields
on the same record: a sender equal to the counterparty (`chatUserId`) is `inbound`; the other
participant is `outbound`. This inference is used only when every complete sender record in the
page has one counterparty and the sender set is either that counterparty alone or that
counterparty plus one other sender. A missing or malformed field, or any other participant shape,
leaves `direction` as null rather than making a confident classification.

## Fixture corpus coverage

The fixture corpus in `test/fixtures/onlyfans/` was captured from an account without earning
capability. `700000078` is that account: the corpus contains 17 self user records and 83
counterparty user records; all self records carry `canCreateLists`, `canSendChatToAll`,
`creditsMin`, `creditsMax`, `creditsMinAlternatives`, `hasStripe`, `isPaywallPassed`,
`isStripeExist`, and `payPalStatus`, while no counterparty record does, and all counterparty
records carry `subscribedBy`, `subscribedByExpire`, `subscribedByExpireDate`,
`subscribedByAutoprolong`, `subscribedIsExpiredNow`, `subscribedOnExpire`,
`subscribedOnExpiredNow`, `subscribedOnDuration`, `currentSubscribePrice`, `isPaywallRequired`,
`isRestricted`, and `canRestrict`, while no self record does. `subscribedOn` is the only
relationship field present on self records, and it is null wherever present; `subscriptionBundles`
is not self-only, because one counterparty carries it.

Counterparty `canEarn` does not determine either participant's role. Both participants in a
conversation may have `canEarn: true`, so the direction rule must not consult role:
`fromUser.id === chatUserId` inspects no role field and would be wrong for a conversation between
two earning accounts if it did.

The following regions are unexercised in this corpus:

- Subscription direction: all 23 counterparties have `subscribedBy: true` (23/23), and no reverse
  relationship appears (0/23).
- Tip state: `isTip` is `false` on all 45 real message items (45/45).
- Read/new state: `isOpened` and `isNew` are both `false` on all 45 real message items (45/45 each).
- Purchase reason: `canPurchaseReason` has only `""` and `"free"` across all 45 real message items
  (45/45; no other value).

This corpus does not establish that a message page captured from an account with earning
capability has the same shape, and these regions cannot be covered from this corpus.

For message pages, `chat_id` is the requested conversation id. It comes from the typed request,
not the response's `chatUserId`, which identifies the counterparty. A response `chat_id` alias is
only a consistency check: a conflicting value rejects the page. Without request context,
`chat_id` is null rather than falling back to a response alias.

`continuation = null` without valid operation-specific boundary evidence is invalid, not complete.

A continuation comes from the platform or not at all. Conversation pages carry a
platform-supplied continuation alongside the more-data flag, and that value is used as given.
Message pages carry the flag and the item list only; such a page is rejected with
`missing_page_continuation` rather than being given a continuation derived from the requested
window. Deriving one is unsound on this endpoint: distinct requested offsets were observed to
return byte-identical pages, increasing the offset did not always advance the window, and
advancing by the requested limit skipped messages that other windows did return. Until the
platform's own message pagination parameter is established, a message page that reports more data
has no safe successor, and the connector says so instead of guessing one.

The development simulator uses offline scripted page maps for the same reason. An `initial` page
serves a request without an `offset`; each later page is keyed by the supplied `offset`. A fixture
states its items and either its observed `nextCursor` or its terminal state. The simulator returns
that evidence verbatim and does not slice items or calculate a successor. If a nonterminal fixture
has no `nextCursor`, the response has no `next_cursor` field.

The more-data flag is terminal evidence in one direction only. A false flag marks the end, and
such a page may still carry items, so termination is read from the flag and never from an empty or
short page: pages shorter than the requested limit while the flag was true were common. A true
flag is not evidence that more data exists; it was observed on pages that had already returned
every message the conversation was ever seen to hold.

## Normalized failures

- `IntentValidationError`: request violates the connector boundary.
- `SessionError`: no valid local authenticated session is available.
- `AuthorizationError`: preparation or upstream authorization failed.
- `UpstreamResponseError`: upstream returned a non-authorization failure or malformed response.

## Adapter comparison criteria

Any future page-native or locally prepared adapter should be evaluated using the same fixture suite:

- identical observations for the same pages;
- deterministic cursor progression and termination;
- session/account binding;
- behavior across configuration rotation;
- explicit schema incompatibility;
- absence of credentials and authorization details in returned observations;
- bounded retry behavior.

The current renewable adapter satisfies the local preparation side of this comparison for `identity` and `conversations`. The development rotation runner owns private generation activation, detects revision or authorization failures, refreshes once, and retries once. Product integration can reuse the same bounded provider behavior without depending on the development CLI.
