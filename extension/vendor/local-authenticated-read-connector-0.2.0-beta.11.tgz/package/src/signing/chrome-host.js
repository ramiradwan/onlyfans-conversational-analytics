const ONLYFANS_ORIGIN = 'https://onlyfans.com';
const CAPTURE_HEADERS = new Set([
  'accept',
  'app-token',
  'sign',
  'time',
  'user-id',
  'x-bc',
  'x-of-rev',
]);

function callChrome(chromeApi, receiver, method, args) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      const error = chromeApi?.runtime?.lastError;
      if (error) reject(new Error(error.message));
      else resolve(value);
    };
    try {
      const returned = method.call(receiver, ...args, finish);
      if (returned?.then) returned.then(finish, reject);
    } catch (error) {
      reject(error);
    }
  });
}

function abortError(signal) {
  if (signal?.reason instanceof Error) return signal.reason;
  const error = new Error('Browser signing operation was aborted.');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError(signal);
}

function awaitWithAbort(value, signal, onAbort = null) {
  if (signal === undefined || signal === null) return Promise.resolve(value);
  if (signal.aborted) {
    onAbort?.();
    return Promise.reject(abortError(signal));
  }
  let listener;
  const aborted = new Promise((_, reject) => {
    listener = () => {
      onAbort?.();
      reject(abortError(signal));
    };
    signal.addEventListener('abort', listener, { once: true });
  });
  return Promise.race([Promise.resolve(value), aborted])
    .finally(() => signal.removeEventListener('abort', listener));
}

function headersToObject(headers, allowedNames = null) {
  const selected = {};
  for (const header of headers ?? []) {
    const name = typeof header?.name === 'string' ? header.name.toLowerCase() : '';
    if (!name || (allowedNames !== null && !allowedNames.has(name))) continue;
    if (typeof header.value !== 'string' || header.value.length === 0) continue;
    selected[name] = header.value;
  }
  return selected;
}

function isIdentityRequest(details, tabId) {
  if (details.tabId !== tabId || details.method !== 'GET') return false;
  try {
    const url = new URL(details.url);
    return (
      url.origin === ONLYFANS_ORIGIN &&
      url.pathname === '/api2/v2/users/me' &&
      url.search === ''
    );
  } catch {
    return false;
  }
}

// This function is intentionally closure-free for MAIN-world execution.
export async function executeTypedReadInPage(input) {
  // This must remain local to this closure-free MAIN-world function. The value mirrors the
  // simulator's only documented request-age check (src/simulated-platform.js), not a verified
  // platform acceptance window.
  const simulatorMaximumRequestAgeMs = 30_000;
  const definitions = {
    identity: /^\/api2\/v2\/users\/me\/?$/,
    conversations: /^\/api2\/v2\/chats\/?$/,
    'message-page': /^\/api2\/v2\/chats\/[A-Za-z0-9_-]+\/messages\/?$/,
  };
  const allowedHeaders = new Set([
    'accept',
    'app-token',
    'sign',
    'time',
    'user-id',
    'x-bc',
    'x-of-rev',
  ]);
  if (!input || input.method !== 'GET' || !definitions[input.operation]) {
    throw new TypeError('MAIN-world signer accepts typed GET reads only.');
  }
  const url = new URL(input.url);
  if (url.origin !== 'https://onlyfans.com' || !definitions[input.operation].test(url.pathname)) {
    throw new TypeError('MAIN-world signer destination is outside its typed operation.');
  }
  const queryKeys = [...new Set(url.searchParams.keys())];
  if (input.operation === 'identity' && queryKeys.length !== 0) {
    throw new TypeError('MAIN-world identity read does not accept a query.');
  }
  if (input.operation !== 'identity') {
    if (queryKeys.some((key) => !['limit', 'cursor', 'offset'].includes(key))) {
      throw new TypeError('MAIN-world signer query contains an unsupported field.');
    }
    if (queryKeys.some((key) => url.searchParams.getAll(key).length !== 1)) {
      throw new TypeError('MAIN-world signer query fields must not repeat.');
    }
    if (url.searchParams.has('limit')) {
      const rawLimit = url.searchParams.get('limit');
      const limit = Number(rawLimit);
      if (!/^[1-9]\d*$/.test(rawLimit) || !Number.isSafeInteger(limit) || limit > 100) {
        throw new TypeError('MAIN-world signer query limit is invalid.');
      }
    }
    if (url.searchParams.has('cursor')) {
      const cursor = url.searchParams.get('cursor');
      if (!cursor || cursor.length > 512 || !/^[A-Za-z0-9._~-]+$/.test(cursor)) {
        throw new TypeError('MAIN-world signer query cursor is invalid.');
      }
    }
    if (url.searchParams.has('offset')) {
      const offset = url.searchParams.get('offset');
      if (!/^\d{1,15}$/.test(offset)) {
        throw new TypeError('MAIN-world signer query offset is invalid.');
      }
    }
  }
  if (!input.headers || typeof input.headers !== 'object' || Array.isArray(input.headers)) {
    throw new TypeError('MAIN-world signer headers are invalid.');
  }
  const headers = {};
  for (const [rawName, value] of Object.entries(input.headers)) {
    const name = rawName.toLowerCase();
    if (!allowedHeaders.has(name) || typeof value !== 'string' || value.length === 0) {
      throw new TypeError('MAIN-world signer received a disallowed header.');
    }
    headers[name] = value;
  }
  // This predicate intentionally duplicates src/signing/request-freshness.js because this
  // executor is serialized into the MAIN world and cannot retain imported bindings.
  const timestampWasMinted = (timestamp) => {
    if (typeof timestamp !== 'string' || !/^(?:0|[1-9]\d*)$/.test(timestamp)) return false;
    const issuedAt = Number(timestamp);
    return Number.isSafeInteger(issuedAt) && issuedAt > 0;
  };
  const timestampIsFresh = (timestamp, pageClock) => {
    if (!timestampWasMinted(timestamp)) return false;
    const issuedAt = Number(timestamp);
    return (
      Number.isSafeInteger(pageClock) &&
      Math.abs(pageClock - issuedAt) <= simulatorMaximumRequestAgeMs
    );
  };
  if (!timestampWasMinted(headers.time)) {
    throw new TypeError('MAIN-world signer requires a valid signed request timestamp.');
  }
  if (
    input.request_id !== undefined
    && (typeof input.request_id !== 'string' || !/^[A-Za-z0-9._~-]{1,128}$/.test(input.request_id))
  ) {
    throw new TypeError('MAIN-world signer request identifier is invalid.');
  }
  const controller = new AbortController();
  const registryKey = '__LOCAL_AUTHENTICATED_READ_ABORTS_V1__';
  let registry = null;
  if (input.request_id !== undefined) {
    registry = globalThis[registryKey];
    if (!(registry instanceof Map)) {
      registry = new Map();
      globalThis[registryKey] = registry;
    }
    registry.set(input.request_id, controller);
  }
  try {
    // This is the authoritative freshness check: it runs in MAIN immediately before fetch,
    // so an extension-worker or frozen-tab delay before MAIN-world execution cannot transmit
    // a stale signed request. It intentionally matches the simulator's absolute-age rule.
    if (!timestampIsFresh(headers.time, Date.now())) {
      throw new Error('MAIN-world signer refused an expired signed request before fetch.');
    }
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers,
      credentials: 'include',
      cache: 'no-store',
      signal: controller.signal,
    });
    let body = null;
    try {
      body = await response.json();
    } catch {}
    let retryAfterMs = null;
    if (response.status === 429) {
      const rawRetryAfter = response.headers.get('retry-after');
      if (typeof rawRetryAfter === 'string' && rawRetryAfter.trim().length > 0) {
        const seconds = Number(rawRetryAfter);
        const milliseconds = Number.isFinite(seconds) && seconds >= 0
          ? seconds * 1_000
          : Date.parse(rawRetryAfter) - Date.now();
        if (Number.isFinite(milliseconds)) {
          retryAfterMs = Math.min(3_600_000, Math.max(0, Math.ceil(milliseconds)));
        }
      }
    }
    return {
      status: response.status,
      contentType: response.headers.get('content-type') || '',
      responseRevision: response.headers.get('x-of-rev') || null,
      retryAfterMs,
      body,
    };
  } finally {
    if (registry?.get(input.request_id) === controller) registry.delete(input.request_id);
  }
}

// This function is intentionally closure-free for MAIN-world execution.
export function abortTypedReadInPage(requestId) {
  const registry = globalThis.__LOCAL_AUTHENTICATED_READ_ABORTS_V1__;
  const controller = registry instanceof Map ? registry.get(requestId) : null;
  if (!(controller instanceof AbortController)) return false;
  controller.abort();
  registry.delete(requestId);
  return true;
}

// This function is intentionally closure-free for MAIN-world execution.
export function inspectSafeRefreshInPage() {
  const draftControls = [
    ...document.querySelectorAll('textarea, [contenteditable="true"]'),
  ];
  const hasDraft = draftControls.some((control) => {
    if (typeof control.value === 'string') return control.value.trim().length > 0;
    return (control.textContent ?? '').trim().length > 0;
  });
  if (document.visibilityState !== 'hidden') {
    return { safe: false, reason: 'tab_visible' };
  }
  if (hasDraft) return { safe: false, reason: 'composer_draft_present' };
  return { safe: true, reason: null };
}

export class ChromeMainWorldSigningHost {
  constructor({
    chromeApi = globalThis.chrome,
    captureTimeoutMs = 20_000,
    tabId = null,
    idFactory = () => crypto.randomUUID(),
  } = {}) {
    if (!chromeApi?.tabs || !chromeApi?.scripting || !chromeApi?.webRequest) {
      throw new TypeError('Chrome tabs, scripting, and webRequest APIs are required.');
    }
    this.chrome = chromeApi;
    this.captureTimeoutMs = captureTimeoutMs;
    this.tabId = tabId;
    this.idFactory = idFactory;
  }

  async status() {
    try {
      const tab = await this.#onlyFansTab();
      return { ready: true, tab_id: tab.id };
    } catch {
      return { ready: false, tab_id: null };
    }
  }

  async captureIdentity({ reload = true, signal = null } = {}) {
    throwIfAborted(signal);
    const tab = reload ? await this.#safeRefreshTab(signal) : await this.#onlyFansTab(signal);
    const capture = this.#observeIdentity(tab.id, signal);
    if (reload) {
      try {
        await awaitWithAbort(
          callChrome(this.chrome, this.chrome.tabs, this.chrome.tabs.reload, [tab.id, {
            bypassCache: true,
          }]),
          signal,
          () => capture.cancel(abortError(signal)),
        );
      } catch (error) {
        capture.cancel(error);
        return capture.promise;
      }
    }
    return awaitWithAbort(capture.promise, signal, () => capture.cancel(abortError(signal)));
  }

  async executeTypedRead(request, { signal = null } = {}) {
    throwIfAborted(signal);
    const tab = await this.#onlyFansTab(signal);
    const requestId = this.idFactory();
    const execution = callChrome(
      this.chrome,
      this.chrome.scripting,
      this.chrome.scripting.executeScript,
      [{
        target: { tabId: tab.id },
        world: 'MAIN',
        func: executeTypedReadInPage,
        args: [{
          operation: request.operation,
          method: request.method,
          url: request.url,
          headers: request.headers,
          request_id: requestId,
        }],
      }],
    );
    const cancelInPage = () => {
      void callChrome(
        this.chrome,
        this.chrome.scripting,
        this.chrome.scripting.executeScript,
        [{
          target: { tabId: tab.id },
          world: 'MAIN',
          func: abortTypedReadInPage,
          args: [requestId],
        }],
      ).catch(() => undefined);
    };
    const results = await awaitWithAbort(execution, signal, cancelInPage);
    const value = results?.[0]?.result;
    if (
      !value ||
      !Number.isInteger(value.status) ||
      typeof value.contentType !== 'string'
    ) {
      throw new Error('Chrome MAIN-world typed read returned an invalid result.');
    }
    return value;
  }

  async #onlyFansTab(signal = null) {
    const tabs = await awaitWithAbort(
      callChrome(this.chrome, this.chrome.tabs, this.chrome.tabs.query, [{
        url: ['https://onlyfans.com/*'],
      }]),
      signal,
    );
    const tab = (tabs ?? []).find((candidate) => candidate.id === this.tabId) ??
      (tabs ?? []).find((candidate) => candidate.active && Number.isInteger(candidate.id)) ??
      (tabs ?? []).find((candidate) => Number.isInteger(candidate.id));
    if (!tab) throw new Error('No authenticated OnlyFans tab is open.');
    this.tabId = tab.id;
    return tab;
  }

  async #safeRefreshTab(signal = null) {
    const tabs = await awaitWithAbort(
      callChrome(this.chrome, this.chrome.tabs, this.chrome.tabs.query, [{
        url: ['https://onlyfans.com/*'],
      }]),
      signal,
    );
    const inactive = (tabs ?? []).filter((candidate) => (
      Number.isInteger(candidate.id) && candidate.active !== true
    ));
    const tab = inactive.find((candidate) => candidate.id === this.tabId) ?? inactive[0];
    if (!tab) {
      throw new Error('Safe signing refresh requires an inactive OnlyFans tab.');
    }
    const results = await awaitWithAbort(
      callChrome(
        this.chrome,
        this.chrome.scripting,
        this.chrome.scripting.executeScript,
        [{
          target: { tabId: tab.id },
          world: 'MAIN',
          func: inspectSafeRefreshInPage,
        }],
      ),
      signal,
    );
    const safety = results?.[0]?.result;
    if (safety?.safe !== true) {
      const reason = typeof safety?.reason === 'string' ? safety.reason : 'safety_unproven';
      throw new Error(`OnlyFans tab refresh is unsafe (${reason}).`);
    }
    this.tabId = tab.id;
    return tab;
  }

  #observeIdentity(tabId, signal = null) {
    throwIfAborted(signal);
    const webRequest = this.chrome.webRequest;
    let selectedRequestId = null;
    let request = null;
    let responseRevision = null;
    let responseStatus = null;
    let responseContentType = '';
    let settled = false;
    let timeout;
    let rejectPromise;

    const cleanup = () => {
      clearTimeout(timeout);
      signal?.removeEventListener('abort', aborted);
      webRequest.onBeforeSendHeaders.removeListener(beforeHeaders);
      webRequest.onHeadersReceived.removeListener(receivedHeaders);
      webRequest.onCompleted.removeListener(completed);
      webRequest.onErrorOccurred.removeListener(failed);
    };
    const finish = (resolve, reject, error = null) => {
      if (settled) return;
      settled = true;
      cleanup();
      if (error) reject(error);
      else resolve({
        method: request.method,
        url: request.url,
        headers: request.headers,
        responseRevision,
        response: {
          status: responseStatus ?? 0,
          contentType: responseContentType,
        },
      });
    };
    const beforeHeaders = (details) => {
      if (selectedRequestId !== null || !isIdentityRequest(details, tabId)) return;
      selectedRequestId = details.requestId;
      request = {
        method: details.method,
        url: details.url,
        headers: headersToObject(details.requestHeaders, CAPTURE_HEADERS),
      };
    };
    const receivedHeaders = (details) => {
      if (details.requestId !== selectedRequestId) return;
      const headers = headersToObject(details.responseHeaders);
      responseRevision = headers['x-of-rev'] ?? null;
      responseContentType = headers['content-type'] ?? '';
      responseStatus = details.statusCode;
    };
    let resolvePromise;
    const completed = (details) => {
      if (details.requestId !== selectedRequestId || request === null) return;
      responseStatus ??= details.statusCode;
      finish(resolvePromise, rejectPromise);
    };
    const failed = (details) => {
      if (details.requestId !== selectedRequestId) return;
      finish(resolvePromise, rejectPromise, new Error('The captured identity request failed.'));
    };
    const aborted = () => finish(resolvePromise, rejectPromise, abortError(signal));
    const promise = new Promise((resolve, reject) => {
      resolvePromise = resolve;
      rejectPromise = reject;
      const filter = { urls: ['https://onlyfans.com/api2/v2/users/me*'], tabId };
      webRequest.onBeforeSendHeaders.addListener(beforeHeaders, filter, ['requestHeaders', 'extraHeaders']);
      webRequest.onHeadersReceived.addListener(receivedHeaders, filter, ['responseHeaders', 'extraHeaders']);
      webRequest.onCompleted.addListener(completed, filter);
      webRequest.onErrorOccurred.addListener(failed, filter);
      timeout = setTimeout(() => {
        finish(resolve, reject, new Error('No completed identity request was observed before timeout.'));
      }, this.captureTimeoutMs);
      signal?.addEventListener('abort', aborted, { once: true });
    });
    return {
      promise,
      cancel: (error = new Error('Identity capture was cancelled.')) => (
        finish(resolvePromise, rejectPromise, error)
      ),
    };
  }
}

export { CAPTURE_HEADERS };
