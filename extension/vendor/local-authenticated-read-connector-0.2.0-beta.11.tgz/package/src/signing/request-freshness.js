export const MAXIMUM_SIGNED_REQUEST_AGE_MS = 30_000;

export function isFreshSignedRequestTimestamp(timestamp, pageClock = Date.now()) {
  if (typeof timestamp !== 'string' || !/^(?:0|[1-9]\d*)$/.test(timestamp)) return false;
  const issuedAt = Number(timestamp);
  return (
    Number.isSafeInteger(issuedAt) &&
    issuedAt > 0 &&
    Number.isSafeInteger(pageClock) &&
    Math.abs(pageClock - issuedAt) <= MAXIMUM_SIGNED_REQUEST_AGE_MS
  );
}
