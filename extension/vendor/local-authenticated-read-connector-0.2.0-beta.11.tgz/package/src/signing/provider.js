import { buildOperationRequest } from './operations.js';
import {
  createGenerationFromPackagedRule,
  createPackagedSigningRuleRegistry,
  generationMatchesPackagedRule,
} from './packaged-rule.js';
import {
  createPortableRenewableAdapter,
  webCryptoSha1Hex,
} from './renewable-signing.js';
import {
  classifyDifferentialProof,
  normalizeIdentifier,
  parseTypedResponse,
  publicResponseSummary,
} from './response.js';

const AUTHORIZATION_STATUSES = new Set([401, 403]);

function abortError(signal) {
  if (signal?.reason instanceof Error) return signal.reason;
  const error = new Error('Browser signing operation was aborted.');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError(signal);
}

function awaitWithAbort(value, signal) {
  if (signal === undefined || signal === null) return Promise.resolve(value);
  throwIfAborted(signal);
  let listener;
  const aborted = new Promise((_, reject) => {
    listener = () => reject(abortError(signal));
    signal.addEventListener('abort', listener, { once: true });
  });
  return Promise.race([Promise.resolve(value), aborted])
    .finally(() => signal.removeEventListener('abort', listener));
}

export class BrowserSigningError extends Error {
  constructor(code, message, options = {}) {
    super(message, options);
    this.name = 'BrowserSigningError';
    this.code = code;
  }
}

function corrupt(value) {
  if (typeof value !== 'string' || value.length === 0) {
    throw new TypeError('Invalid comparison requires a non-empty header value.');
  }
  const replacement = value[0] === '0' ? '1' : '0';
  return `${replacement}${value.slice(1)}`;
}

export async function prepareGenerationRequest({
  generation,
  operation,
  parameters = {},
  sha1Hex = webCryptoSha1Hex,
  now = Date.now,
  signal = null,
}) {
  throwIfAborted(signal);
  const request = buildOperationRequest(operation, parameters);
  const adapter = createPortableRenewableAdapter({
    config: generation.config,
    sha1Hex,
  });
  const prepared = await adapter.prepare({
    method: request.method,
    url: request.url,
    session: generation.context.session,
    now,
  });
  throwIfAborted(signal);
  return {
    operation,
    method: request.method,
    url: request.url.toString(),
    headers: prepared.headers,
    controlHeaders: prepared.controlHeaders,
  };
}

export class BrowserSigningProvider {
  constructor({
    store,
    host,
    packagedRule,
    sha1Hex = webCryptoSha1Hex,
    now = Date.now,
    expectedIdentity = null,
  }) {
    if (!store?.active || !store?.activate || !store?.rollback) {
      throw new TypeError('Browser signing provider requires a generation store.');
    }
    if (!host?.captureIdentity || !host?.executeTypedRead) {
      throw new TypeError('Browser signing provider requires a browser host adapter.');
    }
    this.store = store;
    this.host = host;
    this.packagedRuleRegistry = createPackagedSigningRuleRegistry([packagedRule]);
    this.sha1Hex = sha1Hex;
    this.now = now;
    if (expectedIdentity !== null && normalizeIdentifier(expectedIdentity) === null) {
      throw new TypeError('Browser signing provider expected identity is invalid.');
    }
    this.expectedIdentity = expectedIdentity === null ? null : normalizeIdentifier(expectedIdentity);
    this.refreshOperation = null;
  }

  async read({ operation, parameters = {}, refreshMode = 'allow', signal = null }) {
    throwIfAborted(signal);
    if (!['allow', 'never'].includes(refreshMode)) {
      throw new TypeError('Browser signing read refreshMode must be allow or never.');
    }
    let generation = await this.store.active();
    let refreshed = false;
    let refreshReason = null;
    const generationReason = generation === null
      ? 'missing-active-generation'
      : generationMatchesPackagedRule(generation, this.packagedRuleRegistry)
        ? null
        : 'active-generation-not-packaged';
    if (generationReason !== null) {
      if (refreshMode === 'never') this.#refreshRequired(generationReason);
      const refresh = await this.refresh({ reason: generationReason, signal });
      generation = refresh.generation;
      refreshed = true;
      refreshReason = generationReason;
    }
    this.#assertGeneration(generation);

    let attempt = await this.#attempt(generation, operation, parameters, signal);
    const authorizationFailure =
      !attempt.summary.semantic_success && AUTHORIZATION_STATUSES.has(attempt.summary.status);
    const revisionMismatch =
      !authorizationFailure &&
      attempt.responseRevision !== generation.config.source_revision;

    if (revisionMismatch || authorizationFailure) {
      refreshReason = authorizationFailure ? 'authorization-failure' : 'response-revision-mismatch';
      if (refreshMode === 'never') this.#refreshRequired(refreshReason);
      const refresh = await this.refresh({ reason: refreshReason, signal });
      generation = refresh.generation;
      this.#assertGeneration(generation);
      refreshed = true;
      attempt = await this.#attempt(generation, operation, parameters, signal);
      if (
        attempt.summary.semantic_success &&
        attempt.responseRevision !== generation.config.source_revision
      ) {
        this.#unsupportedRevision(attempt.responseRevision);
      }
    }

    throwIfAborted(signal);

    return {
      schema: 'browser-signing-read/v1',
      operation,
      generation_id: generation.id,
      refreshed,
      refresh_reason: refreshReason,
      success: attempt.summary.semantic_success,
      response: publicResponseSummary({
        ...attempt.summary,
        retry_after_ms: attempt.retryAfterMs,
      }),
      data: attempt.data,
    };
  }

  async refresh({ reason = 'manual', signal = null } = {}) {
    throwIfAborted(signal);
    const reused = this.refreshOperation !== null;
    if (!reused) {
      const operation = {
        controller: new AbortController(),
        waiters: 0,
        promise: null,
      };
      operation.promise = this.#performRefresh(reason, operation.controller.signal)
        .finally(() => {
          if (this.refreshOperation === operation) this.refreshOperation = null;
        });
      this.refreshOperation = operation;
    }

    const operation = this.refreshOperation;
    operation.waiters += 1;
    try {
      return {
        generation: await awaitWithAbort(operation.promise, signal),
        refreshed: !reused,
        reused,
        reason,
      };
    } finally {
      operation.waiters -= 1;
      if (signal?.aborted && operation.waiters === 0 && this.refreshOperation === operation) {
        operation.controller.abort(abortError(signal));
      }
    }
  }

  async rollback({ signal = null } = {}) {
    throwIfAborted(signal);
    const previous = await this.store.previous();
    if (previous === null) {
      throw new BrowserSigningError('no_previous', 'No previous signing generation is available.');
    }
    this.#assertGeneration(previous);
    const validation = await this.#prove(previous, signal);
    if (validation.proof.outcome !== 'strong') {
      throw new BrowserSigningError(
        'rollback_proof_failed',
        'The previous signing generation failed strong proof and was not activated.',
      );
    }
    if (
      validation.responseRevision !== previous.config.source_revision
    ) {
      throw new BrowserSigningError(
        'rollback_revision_stale',
        'The previous signing generation does not match the current upstream revision.',
      );
    }
    throwIfAborted(signal);
    return { generation: await this.store.rollback(), proof: validation.proof };
  }

  async status() {
    const state = await this.store.status();
    const browser = this.host.status ? await this.host.status() : { ready: null };
    return { schema: 'browser-signing-status/v1', ...state, browser };
  }

  async #performRefresh(reason, signal) {
    throwIfAborted(signal);
    let capture;
    try {
      capture = await this.host.captureIdentity({ reload: true, signal });
    } catch (cause) {
      if (signal?.aborted || cause?.name === 'AbortError') throw abortError(signal);
      throw new BrowserSigningError(
        'browser_unavailable',
        'Open an authenticated OnlyFans tab and retry the operation.',
        { cause },
      );
    }

    const requestRevision = capture?.headers?.['x-of-rev'];
    if (
      typeof requestRevision !== 'string' ||
      typeof capture.responseRevision !== 'string' ||
      capture.responseRevision !== requestRevision
    ) {
      throw new BrowserSigningError(
        'activation_revision_mismatch',
        'The captured response revision does not match the captured signing headers.',
      );
    }
    const rule = this.packagedRuleRegistry.get(requestRevision);
    if (rule === null) this.#unsupportedRevision(requestRevision);

    let derived;
    try {
      derived = await createGenerationFromPackagedRule({
        rule,
        capture,
        sha1Hex: this.sha1Hex,
      });
    } catch (cause) {
      if (signal?.aborted || cause?.name === 'AbortError') throw abortError(signal);
      throw new BrowserSigningError(
        'packaged_rule_mismatch',
        'The packaged signing rule did not reproduce the observed identity request.',
        { cause },
      );
    }
    this.#assertGeneration(derived);

    const transient = { config: derived.config, context: derived.context };
    const validation = await this.#prove(transient, signal);
    if (validation.proof.outcome !== 'strong') {
      throw new BrowserSigningError(
        'activation_proof_failed',
        'New signing rules failed strong differential proof and were not activated.',
      );
    }
    if (
      validation.responseRevision !== derived.config.source_revision
    ) {
      throw new BrowserSigningError(
        'activation_revision_mismatch',
        'The packaged signing revision changed before activation completed.',
      );
    }

    throwIfAborted(signal);
    return this.store.activate({
      config: derived.config,
      context: derived.context,
      reason,
      proof: validation.proof,
      summary: { packaged_rule: derived.summary },
    });
  }

  async #prove(generation, signal = null) {
    throwIfAborted(signal);
    const request = await prepareGenerationRequest({
      generation,
      operation: 'identity',
      sha1Hex: this.sha1Hex,
      now: this.now,
      signal,
    });
    const candidate = await this.host.executeTypedRead(request, { signal });
    const candidateResult = parseTypedResponse({
      operation: 'identity',
      status: candidate.status,
      contentType: candidate.contentType,
      body: candidate.body,
    });
    if (candidateResult.data !== null) {
      const generationIdentity = this.#assertGenerationIdentity(generation);
      if (candidateResult.data.id !== generationIdentity) {
        throw new BrowserSigningError(
          'account_mismatch',
          'The authenticated browser identity does not match the signing generation.',
        );
      }
    }
    const controlHeader = request.controlHeaders[0] ?? null;
    let negative = null;
    if (controlHeader !== null) {
      throwIfAborted(signal);
      negative = await this.host.executeTypedRead({
        ...request,
        headers: {
          ...request.headers,
          [controlHeader]: corrupt(request.headers[controlHeader]),
        },
      }, { signal });
    }
    const negativeSummary = negative === null ? null : parseTypedResponse({
      operation: 'identity',
      status: negative.status,
      contentType: negative.contentType,
      body: negative.body,
    }).summary;
    return {
      proof: classifyDifferentialProof(candidateResult.summary, negativeSummary),
      responseRevision: candidate.responseRevision ?? null,
    };
  }

  async #attempt(generation, operation, parameters, signal = null) {
    throwIfAborted(signal);
    const request = await prepareGenerationRequest({
      generation,
      operation,
      parameters,
      sha1Hex: this.sha1Hex,
      now: this.now,
      signal,
    });
    const response = await this.host.executeTypedRead(request, { signal });
    throwIfAborted(signal);
    const parsed = parseTypedResponse({
      operation,
      parameters,
      status: response.status,
      contentType: response.contentType,
      body: response.body,
    });
    return {
      responseRevision: response.responseRevision ?? null,
      retryAfterMs: response.retryAfterMs ?? null,
      summary: parsed.summary,
      data: parsed.data,
    };
  }

  #assertGeneration(generation) {
    if (!generationMatchesPackagedRule(generation, this.packagedRuleRegistry)) {
      this.#unsupportedRevision(generation?.config?.source_revision ?? null);
    }
    return this.#assertGenerationIdentity(generation);
  }

  #assertGenerationIdentity(generation) {
    const identity = normalizeIdentifier(generation?.context?.session?.userId);
    if (identity === null || (this.expectedIdentity !== null && identity !== this.expectedIdentity)) {
      throw new BrowserSigningError(
        'account_mismatch',
        'The signing generation does not match the expected creator account.',
      );
    }
    return identity;
  }

  #unsupportedRevision(revision) {
    const detail = typeof revision === 'string' && revision.length > 0
      ? ` (${revision})`
      : '';
    throw new BrowserSigningError(
      'unsupported_revision',
      `History sync is unavailable for this OnlyFans revision${detail}; update the extension.`,
    );
  }

  #refreshRequired(reason) {
    throw new BrowserSigningError(
      'refresh_required',
      `Signing state requires refresh (${reason}), but refresh is disabled for this read.`,
    );
  }
}

export { AUTHORIZATION_STATUSES };
