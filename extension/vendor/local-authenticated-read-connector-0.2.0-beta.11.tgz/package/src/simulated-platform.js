import { createServer } from 'node:http';

import { verifyPreparedRequest } from './canonical-request.js';

function json(response, status, body) {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(body));
}
function pageKey(rawOffset) {
  return rawOffset === null ? 'initial' : rawOffset;
}

export class SimulatedPlatform {
  #authorizationRegistry;
  #sessions;
  #pagesByAccount;
  #server = null;
  #origin = null;
  #now;

  constructor({ authorizationRegistry, sessions, pagesByAccount, now = Date.now }) {
    this.#authorizationRegistry = authorizationRegistry;
    this.#sessions = new Map(Object.entries(sessions));
    this.#pagesByAccount = pagesByAccount;
    this.#now = now;
  }

  async start() {
    if (this.#server) return this.#origin;
    this.#server = createServer((request, response) => this.#handle(request, response));
    await new Promise((resolve, reject) => {
      this.#server.once('error', reject);
      this.#server.listen(0, '127.0.0.1', resolve);
    });
    const address = this.#server.address();
    this.#origin = `http://127.0.0.1:${address.port}`;
    return this.#origin;
  }

  async close() {
    if (!this.#server) return;
    await new Promise((resolve, reject) =>
      this.#server.close((error) => (error ? reject(error) : resolve())),
    );
    this.#server = null;
    this.#origin = null;
  }

  async #handle(request, response) {
    const url = new URL(request.url, this.#origin);
    const verification = verifyPreparedRequest({
      method: request.method,
      url,
      headers: new Headers(request.headers),
      config: this.#authorizationRegistry.current(),
      maximumAgeMs: 30_000,
      now: this.#now,
    });
    if (!verification.ok) {
      json(response, 401, { code: verification.code });
      return;
    }

    const creatorAccountId = this.#sessions.get(verification.sessionId);
    if (!creatorAccountId) {
      json(response, 401, { code: 'session_unknown' });
      return;
    }

    const match = url.pathname.match(/^\/api\/read\/conversations\/([^/]+)\/messages$/);
    if (!match) {
      json(response, 404, { code: 'resource_not_found' });
      return;
    }

    const conversationId = decodeURIComponent(match[1]);
    const accountPages = this.#pagesByAccount[creatorAccountId] ?? {};
    if (!Object.hasOwn(accountPages, conversationId)) {
      json(response, 404, { code: 'conversation_not_found' });
      return;
    }

    const offset = url.searchParams.get('offset');
    const limit = Number(url.searchParams.get('limit'));
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) {
      json(response, 400, { code: 'pagination_invalid' });
      return;
    }

    const pages = accountPages[conversationId];
    const key = pageKey(offset);
    if (!Object.hasOwn(pages, key)) {
      json(response, 400, { code: 'pagination_invalid' });
      return;
    }

    const page = pages[key];
    const terminal = page.terminal === true;
    const body = {
      items: page.items,
      boundary: {
        kind: terminal ? 'history_start' : null,
        reached: terminal,
      },
    };
    if (Object.hasOwn(page, 'nextCursor')) body.next_cursor = page.nextCursor;
    json(response, 200, body);
  }
}
