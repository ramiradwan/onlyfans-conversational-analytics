# Renewable signing adapter

## Purpose

The renewable adapter prepares fresh signed headers locally for the account owner's typed read requests. It does not copy cookies, automate sign-in, store API response bodies, accept arbitrary destinations, or provide mutation operations.

Revision-specific values and account context are private runtime artifacts. They must remain beneath gitignored `.local/` and must be regenerated when the authenticated browser profile or upstream revision changes.

## Components

### Browser runtime extraction

`dev:extract-config` connects to the loopback-only debugging endpoint and inspects the already loaded signing code in the authenticated OnlyFans tab. It:

1. discovers the loaded webpack runtime and SHA-1 implementation;
2. locates the request-signing module that depends on that implementation;
3. instruments fresh in-memory module instances without modifying the page's cached module;
4. observes the four-field digest input;
5. derives checksum index multiplicity and the checksum constant with synthetic digest values;
6. independently recomputes the observed signature;
7. writes the resulting rule configuration and session context beneath `.local/`.

The command does not inspect cookies, local storage, saved passwords, or API response bodies. Raw rule values and the user ID are not printed to stdout.

### Local preparation

`adapters/renewable-signing.js` accepts the private rule configuration plus a separate session context. For each request it:

- verifies that the method and URL match a supported typed read operation;
- serializes the exact pathname and query;
- obtains a fresh millisecond timestamp from the injected clock;
- computes the digest over static parameter, timestamp, path/query, and authenticated user ID;
- applies the runtime-derived checksum rule and framing;
- returns stable private headers plus fresh `user-id`, `time`, and `sign` values;
- selects `sign` for the invalid comparison request.

Browser-managed cookies and transport headers are added by the authenticated browser during `dev:probe` and are never returned by the adapter.

## Private artifacts

Rule configuration:

```json
{
  "schema": "local-renewable-signing-config/v1",
  "source_revision": "private revision value",
  "static_param": "private static parameter",
  "format": {
    "prefix": "private framing value",
    "suffix": "private framing value",
    "checksum_indexes": [0],
    "checksum_constant": 0
  },
  "headers": {
    "app-token": "private value",
    "x-bc": "profile-bound private value",
    "x-of-rev": "private revision value"
  }
}
```

Separate session context:

```json
{
  "session": {
    "userId": "private authenticated account identifier"
  }
}
```

The examples describe shape only. Never place real values in documentation, fixtures, tests, or tracked source.

## Workflow

Start from a fresh authenticated identity capture, then extract the current private configuration:

```powershell
npm run dev:extract-config -- `
  --capture .local/captures/identity-baseline.private.json `
  --config-out .local/renewable-signing-config.json `
  --context-out .local/renewable-session-context.json
```

Prepare a fresh candidate:

```powershell
npm run dev:prepare -- --operation identity `
  --adapter adapters/renewable-signing.js `
  --config .local/renewable-signing-config.json `
  --context .local/renewable-session-context.json `
  --private-out .local/candidates/renewable-identity.private.json `
  --summary-out .local/candidates/renewable-identity.summary.json
```

Run the differential proof:

```powershell
npm run dev:probe -- `
  --candidate .local/candidates/renewable-identity.private.json `
  --out .local/proofs/renewable-identity.json
```

Repeating `dev:prepare` must change only the timestamp-dependent headers when the configuration, session, operation, and query are unchanged.

## Refresh conditions

`dev:read` automatically runs the capture/extraction/strong-proof transaction when:

- `x-of-rev` changes;
- the dedicated browser profile changes or its `x-bc` value rotates;
- a different authenticated account is selected;
- a previously valid fresh candidate fails authorization;
- runtime discovery reports that the signing module can no longer be identified.

The requested read is retried once after a successful refresh. `dev:refresh` runs the same transaction explicitly. Never work around extraction failure by accepting arbitrary headers or destinations; the active generation remains unchanged and a major upstream implementation change requires a reviewed extractor update.

## Validation evidence

On 2026-07-18:

- three independent browser captures confirmed stable contextual headers and changing `time`/`sign` values;
- runtime extraction reproduced the loaded browser module's signature exactly;
- two independently prepared renewable identity candidates returned HTTP 200 with the expected `id` shape;
- a conversations candidate returned HTTP 200 with the expected `list` shape;
- a conversations candidate with `limit=1` proved query-bound signing and returned the expected shape;
- all four corrupted-sign comparisons returned HTTP 400 without the expected shape;
- each live differential proof was classified `strong`.

Message-page preparation uses the same typed path/query signing code and is covered by unit tests. A live message-page probe remains intentionally unperformed until a conversation is explicitly selected for that read.
