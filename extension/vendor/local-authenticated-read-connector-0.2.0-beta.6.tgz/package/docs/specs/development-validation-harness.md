# Development validation harness

## Purpose

This suite answers a narrow development question: does a candidate request-authorization adapter produce the header set accepted for a read operation in the account owner's existing browser session?

It does not automate sign-in, export cookies, discover unrelated accounts, send messages, mutate account state, or accept arbitrary destinations.

## Why browser-context probing

Running candidate requests inside an already authenticated OnlyFans tab separates request-authorization correctness from unrelated differences in cookie handling, browser networking, and session state. Cookies remain browser-managed and are never copied into harness artifacts.

## Artifact policy

Raw authorization headers can be sensitive and short-lived. Therefore:

- private captures and candidate requests must be written beneath `.local/`;
- `.local/` is gitignored;
- stdout and comparison reports contain only header names, lengths, and truncated SHA-256 fingerprints;
- Cookie, Set-Cookie, Authorization, CSRF, and browser-managed security or transport headers (including User-Agent) are never captured as candidate values;
- response bodies are hashed and summarized in memory, then discarded; summaries retain counts and expected-shape evidence, not response field names or values;
- no command accepts a raw cookie argument.

Delete `.local/` when a research session ends or when its browser session is invalidated.

## Supported operations

The harness has no arbitrary URL mode. It recognizes only these read operations:

| Operation | Upstream path | Semantic success evidence |
| --- | --- | --- |
| `identity` | `/api2/v2/users/me` | Exact typed identity object `{ id }` |
| `conversations` | `/api2/v2/chats` | Validated page with `list`, continuation, and `inventory_end` evidence |
| `message-page` | `/api2/v2/chats/{conversationId}/messages` | Validated page with `messages`, continuation, and `history_start` evidence |

The identity operation is the recommended first proof because it is minimal and read-only. Conversation history probes require explicit selection and parameters.

## Browser setup

Use a dedicated local Chrome/Edge profile that the creator controls. Start it with a loopback-only remote debugging port, sign in manually, and leave an OnlyFans tab open. The harness connects only to `127.0.0.1` or `localhost` CDP endpoints.

Example dedicated Edge launch from the repository root:

```powershell
& "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe" `
  --remote-debugging-port=9222 `
  --remote-debugging-address=127.0.0.1 `
  "--user-data-dir=$PWD\.local\edge-profile"
```

The profile contains browser-managed session state, so it must remain beneath `.local/` and must not be copied into source control. The suite does not launch the browser, automate sign-in, or manage profile cleanup.

## Workflow

### One-command workflow

With the dedicated authenticated tab open, the primary workflow is:

```powershell
npm run dev:read -- --operation identity
```

On first use it reloads the dedicated tab, captures and extracts current rules, requires strong proof, activates an immutable private generation, and performs the requested read. Later reads refresh and retry once when the response revision differs or an authorization-shaped response is observed. Use `dev:status`, `dev:refresh`, or `dev:rollback` for explicit inspection and recovery.

The lower-level workflow below remains available for diagnosis.

### 1. Capture a known-good request

Start capture, then reload or navigate in the authenticated tab so the selected request occurs:

```powershell
npm run dev:capture -- --operation identity --seconds 30 `
  --private-out .local/captures/identity-baseline.private.json `
  --summary-out .local/captures/identity-baseline.summary.json
```

The private artifact contains only the selected request-authorization headers, normalized path/query, and a sanitized response summary. It never contains cookies or response content.

### 2. Extract private renewable configuration

After the authenticated page finishes loading, derive the active rule configuration and separate session context from the page runtime:

```powershell
npm run dev:extract-config -- `
  --capture .local/captures/identity-baseline.private.json `
  --config-out .local/renewable-signing-config.json `
  --context-out .local/renewable-session-context.json
```

The extractor independently reproduces the observed browser-module signature before writing either file. It prints structural metadata only. See the [renewable signing adapter specification](renewable-signing-adapter.md) for its private artifact contract and refresh conditions.

### 3. Prepare a candidate request

Prepare fresh `time` and `sign` values through the renewable adapter:

```powershell
npm run dev:prepare -- --operation identity `
  --adapter adapters/renewable-signing.js `
  --config .local/renewable-signing-config.json `
  --context .local/renewable-session-context.json `
  --private-out .local/candidates/identity.private.json `
  --summary-out .local/candidates/identity.summary.json
```

For a non-renewable smoke test, replay the exact fresh capture through the captured-header adapter. It rejects a different path or query and automatically selects `sign` as the invalid comparison when that header is present:

```powershell
npm run dev:prepare -- --operation identity `
  --adapter adapters/captured-header-replay.js `
  --config .local/captures/identity-baseline.private.json `
  --private-out .local/candidates/identity.private.json `
  --summary-out .local/candidates/identity.summary.json
```

This proves the capture, comparison, and browser-probe plumbing only. Captured values are time-bound and are not a substitute for an adapter that prepares a fresh request.

For adapter-contract development, create a gitignored `.local/candidate-config.json`:

```json
{
  "headers": {
    "example-request-header": "candidate-value"
  },
  "controlHeaders": ["example-request-header"]
}
```

The included static adapter is useful for checking arbitrary candidate shapes. Other research adapters can implement the same `createAdapter({ config })` contract without changing capture, comparison, or proof tooling.

```powershell
npm run dev:prepare -- --operation identity `
  --adapter adapters/static-header-set.js `
  --config .local/candidate-config.json `
  --private-out .local/candidates/identity.private.json `
  --summary-out .local/candidates/identity.summary.json
```

### 4. Compare shapes

```powershell
npm run dev:compare -- `
  --baseline .local/captures/identity-baseline.private.json `
  --candidate .local/candidates/identity.private.json
```

The report shows missing, extra, equal, and changed headers using fingerprints only.

### 5. Probe from the authenticated tab

```powershell
npm run dev:probe -- `
  --candidate .local/candidates/identity.private.json `
  --out .local/proofs/identity-proof.json
```

The probe performs one candidate request. If `controlHeaders` names an included header, it also performs one deliberately invalid comparison request. The result is classified as:

- `strong`: candidate has the expected semantic response and the invalid comparison diverges;
- `inconclusive`: candidate succeeds but the comparison does not distinguish the selected header;
- `partial`: candidate succeeds but no comparison header was configured;
- `failed`: candidate lacks the expected semantic response.

This classification avoids the weak inference that every HTTP 200 proves correct authorization.

## Adapter contract

An adapter module exports:

```js
export function createAdapter({ config }) {
  return {
    id: 'descriptive-id',
    async prepare({ method, url, session, now }) {
      return {
        headers: { /* candidate request headers */ },
        controlHeaders: ['header-safe-to-vary-for-one-comparison-request'],
        diagnostics: { revision: 'non-sensitive revision label' }
      };
    }
  };
}
```

`diagnostics` must not contain credentials, authorization values, or raw request material. The harness filters it to simple scalar metadata.

## Evidence ladder

Use increasingly strong evidence:

1. Candidate shape matches a fresh browser capture.
2. Candidate succeeds semantically inside the authenticated browser session.
3. A deliberately invalid comparison diverges.
4. The result repeats across fresh requests and a configuration revision change.
5. Pagination and coverage behavior remain correct through the higher-level connector suite.

No single successful response should be treated as sufficient proof of a maintainable implementation.

## Live validation baseline

On 2026-07-18, the capture/replay baseline and renewable adapter were exercised in a dedicated authenticated Edge profile controlled by the account owner:

- the browser capture returned HTTP 200 with the expected `id` shape;
- the exact captured candidate matched the selected request-header fingerprints;
- runtime extraction reproduced the browser module's signature before writing private configuration;
- two separately prepared renewable identity candidates changed only `time` and `sign` and both returned HTTP 200 with the expected `id` shape;
- renewable conversations candidates, both without a query and with `limit=1`, returned HTTP 200 with the expected `list` shape;
- each comparison request with a corrupted `sign` value returned HTTP 400 without the expected shape;
- all renewable differential proofs were classified `strong`.

This baseline validates fresh local preparation, authenticated browser transport, negative-control behavior, a second typed path, and query-bound signing. It does not yet validate a live message-page selection or automatic activation after an authorization revision change.
