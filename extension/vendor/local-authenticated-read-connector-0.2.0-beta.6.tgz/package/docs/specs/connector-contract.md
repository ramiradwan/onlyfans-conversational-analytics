# Authenticated read connector contract

This specification is intentionally implementation-oriented and may evolve while ADR 0001 remains stable.

## Semantic intent

The public connector receives one named read operation with operation-specific typed parameters. It enforces:

- method is `GET`;
- path is constructed by the selected operation rather than supplied by the caller;
- path contains no traversal or embedded credentials;
- destination origin is fixed by construction;
- request body is absent.

The supported browser operations are `identity`, `conversations`, and `message-page`. Unknown
operations, parameters, or query fields reject before request preparation.

## Session context

```text
session_id          opaque identifier used by the local upstream session
creator_account_id  account discovered and verified in that session
```

The connector uses the context during request preparation but does not return it as authorization authority. A session change invalidates prepared requests.

## Authorization configuration

```text
revision      immutable identifier
secret        simulator-only key material
issued_at     configuration issuance time
```

Live adapters may use different configuration shapes. The surrounding connector depends only on revision identity, validation, atomic activation, and refresh behavior.

The runtime-derived development adapter keeps revision-specific rules and stable request-header values in a gitignored private configuration. The authenticated upstream user ID is kept separately in private session context. Each preparation computes a new timestamp and signature for the exact typed path and serialized query.

## Prepared request

```text
url       fixed origin plus validated path and canonical query
method    GET
headers   authorization adapter output
```

The simulator signs a canonical representation containing method, path, sorted query, issue time, session identifier, and configuration revision. This demonstrates binding and rotation without representing a live platform algorithm.

## Page contract

Each call validates exactly one page. The consumer owns the cross-page schedule, durable cursor,
retry budget, commit boundary, and coverage state. Successful normalized pages contain:

- `items`: observations in the page;
- `continuation`: opaque continuation cursor or `null`;
- `boundary`: explicit terminal evidence: `inventory_end` for conversations or `history_start` for messages.

Conversation items contain exactly `id`, `platform_user_id`, `display_name`, and `updated_at`.
Message items contain exactly `id`, nullable `chat_id`, `sender_platform_user_id`, `text`,
`sent_at`, and nullable `direction`. Unknown wrapper/entity fields and conflicting aliases reject
the whole page. The connector never returns a trusted completion flag or content-derived digest.

`continuation = null` without valid operation-specific boundary evidence is invalid, not complete.

## Normalized failures

- `IntentValidationError`: request violates the connector boundary.
- `SessionError`: no valid local authenticated session is available.
- `AuthorizationError`: preparation or upstream authorization failed.
- `UpstreamResponseError`: upstream returned a non-authorization failure or malformed response.

## Adapter comparison criteria

Any future page-native or locally prepared adapter should be evaluated using the same fixture suite:

- identical observations for the same pages;
- deterministic cursor progression and termination;
- session/account binding;
- behavior across configuration rotation;
- explicit schema incompatibility;
- absence of credentials and authorization details in returned observations;
- bounded retry behavior.

The current renewable adapter satisfies the local preparation side of this comparison for `identity` and `conversations`. The development rotation runner owns private generation activation, detects revision or authorization failures, refreshes once, and retries once. Product integration can reuse the same bounded provider behavior without depending on the development CLI.
