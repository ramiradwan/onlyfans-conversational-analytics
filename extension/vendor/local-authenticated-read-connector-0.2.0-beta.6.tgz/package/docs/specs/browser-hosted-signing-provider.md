# Browser-hosted signing provider

## Purpose

The browser-hosted provider is the production-facing boundary intended for a Chrome MV3 extension. It keeps the authenticated session in the creator's normal browser, prepares renewable signatures locally, performs only typed reads in the OnlyFans MAIN world, and returns validated response data to its caller in memory.

The existing CDP commands remain development tools and the live-validation oracle. A production extension does not enable remote debugging, create a dedicated profile, or run the CLI.

## Public module

The package exposes the browser-safe implementation at:

```js
import {
  createChromeBrowserSigningProvider,
} from 'local-authenticated-read-connector/browser-signing';

const signer = await createChromeBrowserSigningProvider({
  chromeApi: chrome,
  expectedIdentity: verifiedPlatformCreatorId,
});
const controller = new AbortController();
const result = await signer.read({
  operation: 'conversations',
  parameters: { query: { limit: 10 } },
  refreshMode: 'allow',
  signal: controller.signal,
});

if (result.success) {
  await ingestTypedConversationResponse(result.data);
}
```

The package import must be bundled into the extension. It is not a remotely hosted script.

## Host requirements

The reference Chrome host requires these MV3 permissions:

```json
{
  "permissions": ["storage", "scripting", "webRequest"],
  "host_permissions": ["https://onlyfans.com/*"]
}
```

The signer calls `chrome.tabs.query` and `chrome.tabs.reload`, but it does not require the broad `tabs` permission. Chrome exposes those methods without that declaration, and the exact OnlyFans host permission supplies the URL access needed by the query. A consuming extension should retain `tabs` only if another feature needs unrestricted sensitive tab metadata.

`webRequest` is observation-only. It captures the approved non-cookie identity headers during rule refresh. It does not use `webRequestBlocking`, alter browser traffic, export cookies, or observe arbitrary origins.

`chrome.scripting.executeScript` runs two closure-free functions in the OnlyFans MAIN world:

- current-runtime signing-rule discovery;
- a typed GET executor restricted to `identity`, `conversations`, and `message-page`.

The typed executor uses browser-managed credentials. It rejects arbitrary destinations, mutation methods, cookie headers, authorization headers, transport headers, and unknown candidate headers.

## Permission constraints

| Permission or capability | Signer requirement | Constraint |
| --- | --- | --- |
| `storage` | Required | Signing state is small and fits ordinary `chrome.storage.local`; do not request `unlimitedStorage` for the signer. |
| `scripting` | Required by the reference host | Needed for direct result-returning MAIN-world execution. A static MAIN-world content script could replace it, but would require a separately secured message bridge. |
| `webRequest` | Required by the reference host | Used only while observing one identity request. It may increase Chrome Web Store privacy scrutiny even though no request is changed. |
| `https://onlyfans.com/*` | Required | Chrome host match patterns cannot meaningfully narrow access to API path prefixes. This is the principal user-facing site-access grant. |
| `tabs` | Not required by the signer | Keep it only when another extension feature needs unrestricted tab URL/title metadata. |
| `cookies` | Prohibited | Cookies stay browser-managed and are never read or exported. |
| `debugger`, `nativeMessaging`, `webRequestBlocking` | Not required | Production integration must not inherit the CDP development mechanism or traffic-modification privileges. |
| `alarms`, `offscreen` | Not required by the signer | A consuming extension may need scheduling separately, but should not add either merely to keep a worker alive. |

For the lowest-friction install, declare the single-domain OnlyFans host permission directly because the extension cannot function without it. Moving it to `optional_host_permissions` trades the install-time site warning for an additional user gesture and runtime permission prompt during connection.

Production builds should remove localhost and placeholder origins, use exact HTTPS/WSS backend origins, and restrict `externally_connectable` to the exact analytics application origin. None of those backend permissions are required by this signer package itself.

## Refresh lifecycle

1. Find an inactive, hidden OnlyFans tab with no composer draft.
2. Observe an identity request while safely reloading that tab.
3. Keep only the approved candidate headers; cookies and browser transport headers are discarded at capture time.
4. Inspect the current page runtime and derive the renewable rule configuration.
5. Reproduce the browser signature independently.
6. Execute a candidate identity read and a corrupted-sign comparison.
7. Require strong differential proof and response-revision agreement.
8. Atomically activate the generation in `chrome.storage.local`.

Refreshes are coalesced within one service-worker instance. Canceling one waiter does not cancel a refresh still needed by another waiter. Missing state, revision mismatch, or an authorization-shaped `401` or `403` triggers one refresh and one retry. `refreshMode: "never"` reports that refresh is required without capturing or reloading. There is no background watcher or unbounded retry.

## Private state

The standalone Chrome persistence adapter stores one `browser_signing_state_v1` document containing only the active and previous generations. One `chrome.storage.local.set` replaces the complete document, so a failed write cannot partially update pointers. Startup validates the entire stored document before use. Product integrations may instead pass an explicit `{ load, save }` persistence adapter to `createChromeBrowserSigningProvider`; this is how account-partitioned hosts keep signing generations in the account's own durable store and avoid installation-global account state.

The factory requests `TRUSTED_CONTEXTS` storage access when the Chrome version supports it. Raw signing rules and authenticated user context remain private extension state. They are never sent to content scripts, page messages, the analytics backend, logs, or status reports.

## Response-data boundary

Unlike the diagnostic CDP probe, a successful browser-hosted read returns the parsed typed response as `result.data`. This is necessary for a separate extension to normalize and enqueue analytics observations.

Successful response objects are exact schemas. Unknown top-level or nested fields, conflicting
aliases, malformed identifiers/timestamps, pages above 100 items, and message text above the
bounded entity budget make the response semantically invalid. Accepted upstream aliases are
reduced immediately to these canonical in-memory entities:

```text
identity:     { id }
conversation: { id, platform_user_id, display_name, updated_at }
message:      { id, chat_id, sender_platform_user_id, text, sent_at, direction }
page:         { items, continuation, boundary }
```

`chat_id` and `direction` may be `null` only when the consuming account-bound adapter can derive
them from the requested conversation and verified creator identity. The consumer must reject any
conflict with that context. No raw response wrapper or unrecognized field crosses this boundary.

A successful result includes only the typed `data`, the active generation identifier, whether and why one refresh occurred, and a bounded public response summary. For `429`, `response.retry_after_ms` is clamped to at most one hour. Callers may cancel reads, refreshes, or rollback validation with an `AbortSignal`.

The signer itself:

- never persists response bodies;
- never prints response bodies;
- drops bodies for unsuccessful or semantically invalid responses;
- does not define analytics schemas, pairing, backend transport, ingestion, or account enrollment.

Those responsibilities belong to the consuming application. This repository provides only authenticated typed reads and signing-rule lifecycle management.

## Service-worker restart behavior

MV3 service workers may stop at any time. On the next wake, construct the provider again. It reloads and validates the active/previous document from `chrome.storage.local`; an ordinary read then proceeds without capture or reload. If state is missing or invalid, the provider fails closed or performs the normal strongly validated bootstrap.

The reference identity-capture timeout is 20 seconds, below Chrome's normal idle-worker window. Identity traffic should occur immediately after reload; a missing request fails visibly rather than attempting to keep the worker alive. Runtime inspection and proof use Chrome API activity and remain bounded.

`chrome.storage.local` is appropriate for the two small signing generations, but not for an analytics message archive or durable full-history outbox. The consuming extension should place bulk conversation data in IndexedDB and keep only compact coordination state in extension storage.

Typed response bodies cross the MAIN-world execution boundary as structured results. Callers should use bounded page sizes and incremental pagination to avoid large single execution results.

## Integration acceptance criteria

Before a consuming extension adopts this provider, its integration tests must prove:

1. signer code is bundled locally and no remote executable code is loaded;
2. signing storage is unavailable to content scripts;
3. the MAIN-world call always uses `world: "MAIN"` and a typed operation;
4. passive or proactive response data is normalized before durable ingestion;
5. the extension does not expose a mutation command through the signer;
6. service-worker restart reuses a validated generation;
7. logged-out or unavailable browser state preserves the last-known-good generation;
8. no cookie, raw signing rule, user ID, or response body enters logs or backend protocol frames.
