# Signing-rule rotation

## Developer workflow

Run a typed read with automatic bootstrap and rotation:

```powershell
npm run dev:read -- --operation identity
```

Optional commands:

```powershell
npm run dev:status
npm run dev:refresh
npm run dev:rollback
```

All commands accept `--cdp` and a private `--state-root`. `dev:read` also accepts `--params` for conversations and explicitly selected message pages.

The tools never launch the browser or automate sign-in. If the dedicated authenticated tab is unavailable they leave signing state unchanged and print the exact browser action required.

## Private generation state

The default root is `.local/signing/`:

```text
active.json
previous.json
pending.json                 # exists only during a pointer transaction
refresh.lock                 # exists only during refresh
generations/<generation>/
  capture.private.json
  config.private.json
  context.private.json
  candidate.private.json
  proof.json
  manifest.json
```

Generation directories are immutable after creation. `active.json` and `previous.json` contain only generation IDs, timestamps, and revision fingerprints. A pending pointer transaction is completed automatically on the next state access. Generations not referenced by active or previous are deleted.

## Refresh transaction

1. Acquire the private refresh lock; concurrent callers reuse the generation activated by the lock holder.
2. Reload the dedicated OnlyFans tab and capture a current identity request.
3. Inspect the loaded runtime, derive current rules and authenticated session context, and reproduce the browser signature.
4. Prepare a fresh local identity candidate.
5. Require the candidate to return the expected identity shape and a corrupted-sign request to diverge.
6. Require the candidate response revision, when present, to match the extracted revision.
7. Write an immutable generation, record the old active generation as previous, and atomically update the active pointer.
8. Remove generations other than current and previous.

Any failure before step 7 leaves active and previous unchanged.

## Automatic read behavior

`dev:read` refreshes when active state is missing, the response `x-of-rev` differs from the active private configuration, or a semantic failure returns HTTP 400, 401, or 403. It then retries the requested read exactly once. Other failures are returned without rotation, and a failed retry never starts another refresh.

Raw response revisions are compared only in memory. Reports and pointer files contain fingerprints. Response bodies continue to be summarized and discarded.

## Rollback

`dev:rollback` prepares a fresh identity request from the previous generation and requires the same strong differential proof plus revision agreement. Only then are active and previous swapped. A stale or invalid previous generation remains inactive.
