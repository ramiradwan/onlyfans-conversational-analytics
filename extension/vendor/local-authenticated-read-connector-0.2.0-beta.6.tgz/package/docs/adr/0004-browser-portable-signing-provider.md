# ADR 0004: Separate portable signing policy from browser and CDP hosts

- Status: accepted
- Date: 2026-07-18

## Context

The validated renewable adapter and atomic rotation workflow originally depended on Node hashing, CDP execution, and filesystem generations. Those dependencies are appropriate for an isolated development harness but would force creators to enable remote debugging if reused directly by a production extension.

The product already has a Chrome extension runtime. The signer therefore needs to preserve its strict read-only and strong-proof behavior while allowing a consuming extension to supply browser execution and private persistence.

## Decision

1. Put typed operations, header policy, renewable configuration validation, signing preparation, response-shape validation, and runtime-rule derivation in browser-safe modules beneath `src/signing/`.
2. Keep Node hashing, CDP, filesystem generations, diagnostic summaries, and CLI commands as development adapters.
3. Expose an injected browser-host contract with `captureIdentity`, `inspectSigningRuntime`, and `executeTypedRead` operations.
4. Provide a reference Chrome MV3 host that observes only allow-listed identity headers and executes only the three typed GET operations in the MAIN world.
5. Persist active and previous browser generations as one validated `chrome.storage.local` document restricted to trusted extension contexts.
6. Return a successful typed response body in memory to the consuming extension, but never persist or log it in the signer.
7. Keep pairing, analytics normalization, durable ingestion, backend transport, and extension UI outside this isolated repository.

## Consequences

- Production integration no longer depends on CDP or a dedicated browser profile.
- The existing live harness remains an independent oracle for the portable implementation.
- Rule refresh may reload the authenticated tab, but normal reads do not.
- A consuming extension must bundle these modules and supply its own account binding and ingestion path.
- Chrome requires the observation-only `webRequest` permission in addition to storage, scripting, and the OnlyFans host permission. The signer does not require the broad `tabs` permission.
