# ADR 0003: Activate signing-rule rotation through private atomic generations

- Status: accepted
- Date: 2026-07-18

## Context

The renewable adapter can prepare fresh signatures, but its capture, extraction, preparation, and proof steps originally required separate commands. A rule or profile change could therefore leave a developer manually replacing multiple private files, with no atomic activation or automatic retry.

## Decision

1. Make `dev:read` the primary development entry point.
2. Store immutable validated generations beneath `.local/signing/` and activate them through atomic `active.json` and `previous.json` pointers.
3. Refresh automatically when no active generation exists, a response revision differs, or a typed read returns authorization-shaped HTTP 400, 401, or 403.
4. Reload the dedicated authenticated browser tab during refresh, then require a strong identity proof before activation.
5. Retry the requested read at most once after refresh.
6. Coalesce in-process refreshes and use a private two-minute refresh lock across processes.
7. Retain only current and previous generations. Validate the previous generation with strong proof before rollback.
8. Fail closed when the browser is unavailable or refresh validation fails; never replace the last-known-good pointers.

## Consequences

- First use and ordinary rule rotation become a single command.
- Crashes during pointer updates are recoverable from a private pending transaction.
- A failed refresh can reload the dedicated tab but cannot partially activate configuration.
- A query error that returns HTTP 400 may cause one harmless refresh attempt, but retry remains bounded.
- The existing low-level development commands remain useful for diagnosis and do not depend on generation state.
