# Local authenticated read connector

This package provides a typed, read-only connector for local applications that use an account owner's authenticated browser session. It keeps request authorization separate from downstream scheduling, storage, and analytics.

## Goals

- Define stable read operations independently of any upstream request-authorization mechanism.
- Compare page-native and locally prepared authenticated request strategies behind the same contract.
- Prove deterministic single-page validation, history-boundary evidence, session binding, rule rotation, retries, and explicit failure behavior.
- Produce integration evidence without depending on the conversational-analytics repository.

## Boundaries

The package validates and returns one authenticated read page per call. Its consumer owns every
cross-page loop, durable cursor, retry schedule, commit boundary, and coverage state transition.

- Read operations only.
- The account owner's authenticated session remains local; dedicated browser state and private artifacts stay beneath gitignored `.local/` and are removed after research sessions.
- No credential export to another service.
- No generic arbitrary-URL request proxy.
- No message sending, media retrieval, account mutation, fingerprint manipulation, proxy rotation, challenge circumvention, or traffic-disguise features.
- No live header values, account identifiers, browser identifiers, or revision-specific signing parameters are stored in source control. Runtime-derived configuration stays beneath `.local/`; no external rule feed is used.

The executable harness uses a simulated upstream service and a conventional HMAC-based authorization scheme. Its purpose is to test adapter boundaries and lifecycle behavior, not to reproduce a live platform.

## Architecture

```text
semantic read intent
        |
        v
authenticated read connector
  | session provider
  | authorization adapter
  | constrained transport
        |
        v
simulated upstream API
        |
        v
page results + coverage evidence
```

The connector accepts a small set of semantic resources and relative paths. The authorization adapter never receives permission to choose arbitrary destinations or methods.

## Run

Node.js 22 or newer is sufficient; there are no runtime dependencies.

```powershell
npm test
npm run test:coverage
```

## Documents

- [ADR 0001](docs/adr/0001-local-read-connector-boundary.md) records the stable architectural boundary.
- [Connector contract](docs/specs/connector-contract.md) describes the evolving executable interface.
- [Development validation harness](docs/specs/development-validation-harness.md) documents browser capture, preparation, comparison, and live proof.
- [Renewable signing adapter](docs/specs/renewable-signing-adapter.md) documents private runtime extraction, local signing, refresh conditions, and live evidence.
- [Signing-rule rotation](docs/specs/signing-rule-rotation.md) documents one-command reads, atomic activation, bounded retry, and rollback.
- [Browser-hosted signing provider](docs/specs/browser-hosted-signing-provider.md) documents the Chrome MV3 host contract, private browser generations, and typed in-memory response handoff.

## Development validation harness

The browser-session validation suite separates four activities:

1. Capture one known-good read request from an already authenticated browser tab.
2. Prepare a candidate request through a replaceable authorization adapter.
3. Compare request shapes without printing raw header values.
4. Probe the candidate from inside the same authenticated browser context and classify the response semantically.

All private artifacts are forced under `.local/`, which is gitignored. The validated smoke-test adapter replays one exact capture and cannot renew expired authorization. See the harness specification before using the live probe.

For normal local development, `npm run dev:read -- --operation identity` is the primary entry point. It creates signing state on first use and performs one automatic refresh and retry when rules become stale. The explicit capture/extract/prepare/probe commands remain available for diagnostics.

The browser-safe `browser-signing` package export provides the same typed signing and rotation policy without CDP or filesystem dependencies. The consuming extension supplies account pairing, normalization, durable scheduling, and ingestion; those application concerns remain outside this package.

## Status

The simulator, runtime-derived renewable signing adapter, atomic rotation workflow, and authenticated `identity` and `conversations` probes are validated. The browser-hosted provider has parity, storage, strong-proof, retry, typed-body, and Chrome-host contract tests. Message-page signing is covered by the typed path and unit contracts but still requires an explicitly selected conversation for a live probe.
