export class ConnectorError extends Error {
  constructor(message, options = {}) {
    super(message, options);
    this.name = new.target.name;
  }
}

export class IntentValidationError extends ConnectorError {}
export class SessionError extends ConnectorError {}
export class AuthorizationError extends ConnectorError {}
export class UpstreamResponseError extends ConnectorError {}
