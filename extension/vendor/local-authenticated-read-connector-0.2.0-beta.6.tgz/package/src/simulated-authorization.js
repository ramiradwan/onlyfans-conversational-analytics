import { signPreparedRequest } from './canonical-request.js';
import { AuthorizationError } from './errors.js';

export function validateSimulatedAuthorizationConfig(config) {
  if (
    !config ||
    typeof config.revision !== 'string' ||
    config.revision.length === 0 ||
    typeof config.secret !== 'string' ||
    config.secret.length < 16 ||
    typeof config.issuedAt !== 'string' ||
    Number.isNaN(Date.parse(config.issuedAt))
  ) {
    throw new AuthorizationError('Simulated authorization configuration failed validation.');
  }
  return Object.freeze({ ...config });
}
export class SimulatedHmacAuthorizationAdapter {
  validateConfig(config) {
    return validateSimulatedAuthorizationConfig(config);
  }

  async prepare({ method, url, session, config, now }) {
    const validated = this.validateConfig(config);
    return {
      headers: signPreparedRequest({
        method,
        url,
        sessionId: session.sessionId,
        config: validated,
        now,
      }),
    };
  }
}
