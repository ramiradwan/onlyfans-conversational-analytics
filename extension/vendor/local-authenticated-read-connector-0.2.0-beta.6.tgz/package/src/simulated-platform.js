import { createServer } from 'node:http';

import { verifyPreparedRequest } from './canonical-request.js';

function json(response, status, body) {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(body));
}
function parseCursor(raw) {
  if (raw === null) return 0;
  if (!/^\d+$/.test(raw)) return null;
  return Number(raw);
}

export class SimulatedPlatform {
  #authorizationRegistry;
  #sessions;
  #messagesByAccount;
  #server = null;
  #origin = null;
  #now;

  constructor({ authorizationRegistry, sessions, messagesByAccount, now = Date.now }) {
    this.#authorizationRegistry = authorizationRegistry;
    this.#sessions = new Map(Object.entries(sessions));
    this.#messagesByAccount = messagesByAccount;
    this.#now = now;
  }

  async start() {
    if (this.#server) return this.#origin;
    this.#server = createServer((request, response) => this.#handle(request, response));
    await new Promise((resolve, reject) => {
      this.#server.once('error', reject);
      this.#server.listen(0, '127.0.0.1', resolve);
    });
    const address = this.#server.address();
    this.#origin = `http://127.0.0.1:${address.port}`;
    return this.#origin;
  }

  async close() {
    if (!this.#server) return;
    await new Promise((resolve, reject) =>
      this.#server.close((error) => (error ? reject(error) : resolve())),
    );
    this.#server = null;
    this.#origin = null;
  }

  async #handle(request, response) {
    const url = new URL(request.url, this.#origin);
    const verification = verifyPreparedRequest({
      method: request.method,
      url,
      headers: new Headers(request.headers),
      config: this.#authorizationRegistry.current(),
      maximumAgeMs: 30_000,
      now: this.#now,
    });
    if (!verification.ok) {
      json(response, 401, { code: verification.code });
      return;
    }

    const creatorAccountId = this.#sessions.get(verification.sessionId);
    if (!creatorAccountId) {
      json(response, 401, { code: 'session_unknown' });
      return;
    }

    const match = url.pathname.match(/^\/api\/read\/conversations\/([^/]+)\/messages$/);
    if (!match) {
      json(response, 404, { code: 'resource_not_found' });
      return;
    }

    const conversationId = decodeURIComponent(match[1]);
    const accountMessages = this.#messagesByAccount[creatorAccountId] ?? {};
    if (!Object.hasOwn(accountMessages, conversationId)) {
      json(response, 404, { code: 'conversation_not_found' });
      return;
    }

    const cursor = parseCursor(url.searchParams.get('cursor'));
    const limit = Number(url.searchParams.get('limit'));
    if (cursor === null || !Number.isSafeInteger(limit) || limit < 1 || limit > 100) {
      json(response, 400, { code: 'pagination_invalid' });
      return;
    }

    const allItems = accountMessages[conversationId];
    const items = allItems.slice(cursor, cursor + limit);
    const nextOffset = cursor + items.length;
    const exhausted = nextOffset >= allItems.length;
    json(response, 200, {
      items,
      next_cursor: exhausted ? null : String(nextOffset),
      boundary: {
        kind: exhausted ? 'history_start' : null,
        reached: exhausted,
      },
    });
  }
}
