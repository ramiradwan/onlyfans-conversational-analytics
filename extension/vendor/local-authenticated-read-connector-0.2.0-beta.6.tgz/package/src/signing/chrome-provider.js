import { ChromeMainWorldSigningHost } from './chrome-host.js';
import {
  createChromeSigningGenerationStore,
  restrictSigningStorageToTrustedContexts,
} from './chrome-storage.js';
import { BrowserSigningProvider } from './provider.js';

export async function createChromeBrowserSigningProvider({
  chromeApi = globalThis.chrome,
  storageKey,
  now,
  idFactory,
  sha1Hex,
  captureTimeoutMs,
  tabId,
  delay,
  inspectionAttempts,
  inspectionIntervalMs,
  expectedIdentity = null,
  persistence = null,
} = {}) {
  if (persistence === null) await restrictSigningStorageToTrustedContexts(chromeApi);
  const store = createChromeSigningGenerationStore({
    chromeApi,
    key: storageKey,
    now,
    idFactory,
    ...(persistence === null ? {} : { persistence }),
  });
  await store.initialize();
  const host = new ChromeMainWorldSigningHost({
    chromeApi,
    captureTimeoutMs,
    tabId,
    ...(idFactory ? { idFactory } : {}),
  });
  return new BrowserSigningProvider({
    store,
    host,
    ...(now ? { now } : {}),
    ...(sha1Hex ? { sha1Hex } : {}),
    ...(delay ? { delay } : {}),
    ...(inspectionAttempts === undefined ? {} : { inspectionAttempts }),
    ...(inspectionIntervalMs === undefined ? {} : { inspectionIntervalMs }),
    expectedIdentity,
  });
}
