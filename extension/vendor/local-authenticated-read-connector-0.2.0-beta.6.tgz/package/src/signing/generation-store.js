import { validateRenewableSigningConfig, validateSigningSession } from './renewable-signing.js';

const STATE_SCHEMA = 'browser-signing-state/v1';
const GENERATION_SCHEMA = 'browser-signing-generation/v1';

const clone = (value) => structuredClone(value);

function validateGeneration(generation) {
  if (
    !generation ||
    generation.schema !== GENERATION_SCHEMA ||
    typeof generation.id !== 'string' ||
    generation.id.length === 0 ||
    typeof generation.created_at !== 'string' ||
    Number.isNaN(Date.parse(generation.created_at)) ||
    generation.proof_outcome !== 'strong'
  ) {
    throw new TypeError('Browser signing generation is invalid.');
  }
  validateRenewableSigningConfig(generation.config);
  validateSigningSession(generation.context?.session);
  return generation;
}

function validateState(state) {
  if (!state || state.schema !== STATE_SCHEMA) {
    throw new TypeError('Browser signing state is invalid.');
  }
  if (state.active !== null) validateGeneration(state.active);
  if (state.previous !== null) validateGeneration(state.previous);
  if (state.active && state.previous && state.active.id === state.previous.id) {
    throw new TypeError('Active and previous signing generations must be distinct.');
  }
  return state;
}

export class AtomicSigningGenerationStore {
  constructor({ persistence, now = Date.now, idFactory = () => crypto.randomUUID() }) {
    if (!persistence?.load || !persistence?.save) {
      throw new TypeError('Signing generation persistence requires load and save operations.');
    }
    this.persistence = persistence;
    this.now = now;
    this.idFactory = idFactory;
    this.state = null;
    this.initialization = null;
    this.writeChain = Promise.resolve();
  }

  async initialize() {
    if (this.state !== null) return this.snapshot();
    if (this.initialization === null) {
      this.initialization = (async () => {
        const saved = await this.persistence.load();
        this.state = saved === null || saved === undefined
          ? { schema: STATE_SCHEMA, active: null, previous: null }
          : validateState(saved);
        return this.snapshot();
      })();
    }
    return this.initialization;
  }

  snapshot() {
    if (this.state === null) throw new Error('Signing generation store is not initialized.');
    return clone(this.state);
  }

  async active() {
    await this.initialize();
    await this.writeChain;
    return this.state.active === null ? null : clone(this.state.active);
  }

  async previous() {
    await this.initialize();
    await this.writeChain;
    return this.state.previous === null ? null : clone(this.state.previous);
  }

  async status() {
    await this.initialize();
    await this.writeChain;
    return {
      active: this.state.active === null ? null : {
        id: this.state.active.id,
        created_at: this.state.active.created_at,
        proof_outcome: this.state.active.proof_outcome,
      },
      previous: this.state.previous === null ? null : {
        id: this.state.previous.id,
        created_at: this.state.previous.created_at,
        proof_outcome: this.state.previous.proof_outcome,
      },
    };
  }

  async activate({ config, context, reason, proof, summary = {} }) {
    validateRenewableSigningConfig(config);
    validateSigningSession(context?.session);
    if (proof?.outcome !== 'strong') {
      throw new TypeError('Only a strong signing proof can be activated.');
    }
    const createdAt = new Date(this.now()).toISOString();
    const generation = validateGeneration({
      schema: GENERATION_SCHEMA,
      id: `${createdAt}-${this.idFactory()}`,
      created_at: createdAt,
      reason,
      proof_outcome: proof.outcome,
      config: clone(config),
      context: clone(context),
      summary: clone(summary),
    });
    return this.#mutate((state) => ({
      schema: STATE_SCHEMA,
      active: generation,
      previous: state.active,
    }), generation);
  }

  async rollback() {
    await this.initialize();
    if (this.state.previous === null) {
      throw new Error('No previous signing generation is available.');
    }
    const nextActive = clone(this.state.previous);
    return this.#mutate((state) => ({
      schema: STATE_SCHEMA,
      active: state.previous,
      previous: state.active,
    }), nextActive);
  }

  async #mutate(operation, result) {
    await this.initialize();
    const write = this.writeChain.then(async () => {
      const candidate = validateState(operation(clone(this.state)));
      await this.persistence.save(clone(candidate));
      this.state = candidate;
      return clone(result);
    });
    this.writeChain = write.then(() => undefined, () => undefined);
    return write;
  }
}

export class MemorySigningPersistence {
  constructor(initialState = null) {
    this.value = initialState === null ? null : clone(initialState);
  }

  async load() {
    return this.value === null ? null : clone(this.value);
  }

  async save(value) {
    this.value = clone(value);
  }
}

export { GENERATION_SCHEMA, STATE_SCHEMA };
