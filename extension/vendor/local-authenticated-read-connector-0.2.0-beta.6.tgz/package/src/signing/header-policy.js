const FORBIDDEN_HEADERS = new Set([
  'accept-charset',
  'accept-encoding',
  'accept-language',
  'access-control-request-headers',
  'access-control-request-method',
  'authorization',
  'connection',
  'constructor',
  'content-length',
  'cookie',
  'date',
  'dnt',
  'expect',
  'host',
  'keep-alive',
  'origin',
  'permissions-policy',
  'proxy-authorization',
  'prototype',
  'referer',
  'set-cookie',
  'te',
  'trailer',
  'transfer-encoding',
  'upgrade',
  'user-agent',
  'via',
  '__proto__',
]);

const HEADER_NAME = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
const CSRF_HEADER = /(?:^|[-_])(?:csrf|xsrf)(?:$|[-_])/;

export function normalizeHeaderName(name) {
  if (typeof name !== 'string' || !HEADER_NAME.test(name)) {
    throw new TypeError('Header names must be valid HTTP field names.');
  }
  return name.toLowerCase();
}

export function isForbiddenHeader(name) {
  const normalized = normalizeHeaderName(name);
  return (
    FORBIDDEN_HEADERS.has(normalized) ||
    normalized.startsWith('proxy-') ||
    normalized.startsWith('sec-') ||
    CSRF_HEADER.test(normalized)
  );
}

export function assertAllowedHeader(name, label = 'Header') {
  const normalized = normalizeHeaderName(name);
  if (isForbiddenHeader(normalized)) {
    throw new TypeError(`${label} is browser-managed or credential-bearing: ${name}.`);
  }
  return normalized;
}

export { FORBIDDEN_HEADERS };
