import { ORIGIN } from './operations.js';
import { validateRenewableSigningConfig } from './renewable-signing.js';

// This function is intentionally closure-free so extension hosts can pass it to
// chrome.scripting.executeScript({ world: 'MAIN' }).
export function discoverSigningRulesInPage({ path }) {
  const isSigningOutput = (headers, capturedInput) => {
    if (!headers || typeof headers !== 'object' || typeof capturedInput !== 'string') return false;
    const values = Object.values(headers);
    const hasTime = values.some(
      (value) => typeof value === 'number' || (typeof value === 'string' && /^\d{13}$/.test(value)),
    );
    const hasSign = values.some(
      (value) =>
        typeof value === 'string' &&
        value.split(':').length === 4 &&
        /^[0-9a-f]{40}$/i.test(value.split(':')[1] ?? ''),
    );
    return hasTime && hasSign && capturedInput.split('\n').length === 4;
  };

  const loadRuntime = () => {
    for (const globalName of Object.keys(self)) {
      if (!globalName.startsWith('webpackChunk')) continue;
      let candidate;
      try {
        candidate = self[globalName];
      } catch {
        continue;
      }
      if (!Array.isArray(candidate)) continue;
      let runtime = null;
      try {
        const probeId = `local-signing-${Date.now()}-${Math.random()}`;
        candidate.push([[probeId], {}, (value) => { runtime = value; }]);
      } catch {}
      if (typeof runtime === 'function' && runtime.m && typeof runtime.m === 'object') {
        return { globalName, runtime };
      }
    }
    throw new Error('No loaded webpack runtime was found.');
  };

  const { globalName, runtime } = loadRuntime();
  const moduleEntries = Object.entries(runtime.m);
  const shaCandidates = moduleEntries.filter(([, factory]) => {
    const source = Function.prototype.toString.call(factory);
    return source.includes('js-sha1') ||
      (source.includes('finalize already called') && source.includes('sha1'));
  });
  if (shaCandidates.length === 0) throw new Error('The loaded SHA-1 module was not found.');

  const instantiate = ({ signerFactory, shaModuleId, replacementDigest = null }) => {
    const originalSha = runtime(shaModuleId);
    let capturedInput = null;
    const wrappedSha = (...args) => {
      const [input] = args;
      if (typeof input === 'string' && input.split('\n').length === 4) {
        capturedInput = input;
        if (replacementDigest !== null) return replacementDigest;
      }
      return originalSha(...args);
    };
    Object.assign(wrappedSha, originalSha);
    const instrumentedRequire = (moduleId) =>
      String(moduleId) === String(shaModuleId) ? wrappedSha : runtime(moduleId);
    Object.assign(instrumentedRequire, runtime);
    const freshModule = { exports: {} };
    signerFactory(freshModule, freshModule.exports, instrumentedRequire);
    const exported = typeof freshModule.exports === 'function'
      ? [['default', freshModule.exports]]
      : Object.entries(freshModule.exports);
    return { exported, capturedInput: () => capturedInput };
  };

  let selected = null;
  for (const [shaModuleId] of shaCandidates) {
    const signerCandidates = moduleEntries.filter(([moduleId, factory]) =>
      moduleId !== shaModuleId && Function.prototype.toString.call(factory).includes(String(shaModuleId)),
    );
    for (const [signerModuleId, signerFactory] of signerCandidates) {
      try {
        const instance = instantiate({ signerFactory, shaModuleId });
        for (const [exportKey, exported] of instance.exported) {
          if (typeof exported !== 'function') continue;
          try {
            const headers = exported({ url: path });
            const capturedInput = instance.capturedInput();
            if (isSigningOutput(headers, capturedInput)) {
              selected = { shaModuleId, signerModuleId, signerFactory, exportKey };
              break;
            }
          } catch {}
        }
      } catch {}
      if (selected) break;
    }
    if (selected) break;
  }
  if (!selected) throw new Error('The loaded request-signing module was not found.');

  const invoke = (replacementDigest = null) => {
    const instance = instantiate({
      signerFactory: selected.signerFactory,
      shaModuleId: selected.shaModuleId,
      replacementDigest,
    });
    const exported = instance.exported.find(([key]) => key === selected.exportKey)?.[1];
    const headers = exported({ url: path });
    return { capturedInput: instance.capturedInput(), headers };
  };

  const real = invoke();
  const baseDigest = '0'.repeat(40);
  const base = invoke(baseDigest);
  const variants = Array.from({ length: 40 }, (_, index) => {
    const digest = `${baseDigest.slice(0, index)}1${baseDigest.slice(index + 1)}`;
    return invoke(digest).headers;
  });

  return {
    webpackGlobal: globalName,
    shaModuleId: selected.shaModuleId,
    signerModuleId: selected.signerModuleId,
    exportKey: selected.exportKey,
    real,
    baseDigest,
    baseHeaders: base.headers,
    variants,
  };
}

function findHeaderEntry(headers, predicate) {
  return Object.entries(headers ?? {}).find(([, value]) => predicate(value));
}

export function deriveSigningGeneration({ discovery, capture, calculatedDigest }) {
  if (!capture || capture.method !== 'GET' || typeof capture.url !== 'string') {
    throw new TypeError('Signing discovery requires a captured GET request.');
  }
  const captureUrl = new URL(capture.url);
  if (captureUrl.origin !== ORIGIN || !captureUrl.pathname.startsWith('/api2/v2/')) {
    throw new TypeError('Signing capture is outside the typed OnlyFans origin.');
  }
  if (!capture.headers || typeof capture.headers !== 'object' || Array.isArray(capture.headers)) {
    throw new TypeError('Signing capture headers are invalid.');
  }
  if (!discovery?.real?.capturedInput || !discovery.baseHeaders || !Array.isArray(discovery.variants)) {
    throw new TypeError('Browser signing discovery result is incomplete.');
  }
  if (typeof calculatedDigest !== 'string' || !/^[0-9a-f]{40}$/i.test(calculatedDigest)) {
    throw new TypeError('Signing discovery verification requires a SHA-1 digest.');
  }

  const signEntry = findHeaderEntry(
    discovery.real.headers,
    (value) =>
      typeof value === 'string' &&
      value.split(':').length === 4 &&
      /^[0-9a-f]{40}$/i.test(value.split(':')[1] ?? ''),
  );
  const timeEntry = findHeaderEntry(
    discovery.real.headers,
    (value) => typeof value === 'number' || (typeof value === 'string' && /^\d{13}$/.test(value)),
  );
  if (!signEntry || !timeEntry) throw new TypeError('Signing output does not contain sign and time.');

  const [signHeader, realSign] = signEntry;
  const [timeHeader, realTime] = timeEntry;
  const [prefix, realDigest, realChecksum, suffix] = realSign.split(':');
  const baseSign = discovery.baseHeaders[signHeader]?.split(':');
  if (
    !baseSign ||
    baseSign.length !== 4 ||
    discovery.baseDigest !== '0'.repeat(40) ||
    discovery.variants.length !== 40
  ) {
    throw new TypeError('Synthetic checksum observations are incomplete.');
  }
  const baseChecksum = Number.parseInt(baseSign[2], 16);
  const variantChecksums = discovery.variants.map((headers) =>
    Number.parseInt(headers[signHeader]?.split(':')[2], 16),
  );
  if (![baseChecksum, ...variantChecksums].every(Number.isSafeInteger)) {
    throw new TypeError('Synthetic checksum observations are invalid.');
  }
  const deltas = variantChecksums.map((value) => value - baseChecksum);
  const nonzeroDeltas = deltas.filter((value) => value !== 0);
  if (nonzeroDeltas.length === 0 || nonzeroDeltas.some((value) => Math.sign(value) !== Math.sign(nonzeroDeltas[0]))) {
    throw new TypeError('Checksum orientation could not be derived.');
  }
  const orientation = Math.sign(nonzeroDeltas[0]);
  const weights = deltas.map((value) => value * orientation);
  if (weights.some((value) => !Number.isSafeInteger(value) || value < 0 || value > 8)) {
    throw new TypeError('Checksum weights could not be derived safely.');
  }
  const checksumIndexes = weights.flatMap((weight, index) =>
    Array.from({ length: weight }, () => index),
  );
  const checksumConstant = orientation * baseChecksum -
    checksumIndexes.length * discovery.baseDigest.charCodeAt(0);

  const inputParts = discovery.real.capturedInput.split('\n');
  if (inputParts.length !== 4 || inputParts[1] !== String(realTime)) {
    throw new TypeError('Signing input does not have the expected four-field structure.');
  }
  const [staticParam, , normalizedPath, userId] = inputParts;
  const capturePath = `${captureUrl.pathname}${captureUrl.search}`;
  if (normalizedPath !== capturePath || !/^\d+$/.test(userId)) {
    throw new TypeError('Signing input is not bound to the captured request and authenticated user.');
  }

  const calculatedChecksum = Math.abs(
    checksumIndexes.reduce(
      (sum, index) => sum + calculatedDigest.charCodeAt(index),
      checksumConstant,
    ),
  ).toString(16);
  const calculatedSign = [prefix, calculatedDigest, calculatedChecksum, suffix].join(':');
  if (calculatedDigest !== realDigest || calculatedChecksum !== realChecksum || calculatedSign !== realSign) {
    throw new TypeError('Derived signing rule does not reproduce the browser signature.');
  }

  const headers = Object.fromEntries(
    Object.entries(capture.headers).filter(
      ([name]) => !['sign', 'time', 'user-id'].includes(name),
    ),
  );
  const sourceRevision = headers['x-of-rev'];
  if (typeof sourceRevision !== 'string' || sourceRevision.length === 0) {
    throw new TypeError('Captured request does not contain x-of-rev.');
  }

  const config = {
    schema: 'local-renewable-signing-config/v1',
    source_revision: sourceRevision,
    static_param: staticParam,
    format: {
      prefix,
      suffix,
      checksum_indexes: checksumIndexes,
      checksum_constant: checksumConstant,
    },
    headers,
  };
  validateRenewableSigningConfig(config);
  return {
    config,
    context: { session: { userId } },
    summary: {
      webpack_global: discovery.webpackGlobal,
      signer_module: String(discovery.signerModuleId),
      sha_module: String(discovery.shaModuleId),
      sign_header: signHeader,
      time_header: timeHeader,
      static_parameter_length: staticParam.length,
      user_id_length: userId.length,
      checksum_index_count: checksumIndexes.length,
      checksum_unique_index_count: new Set(checksumIndexes).size,
      checksum_constant: checksumConstant,
      reproduced_browser_signature: true,
    },
  };
}
