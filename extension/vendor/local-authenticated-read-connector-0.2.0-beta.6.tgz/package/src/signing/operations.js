import { IntentValidationError } from '../errors.js';

const ORIGIN = 'https://onlyfans.com';
const MAX_PAGE_LIMIT = 100;
const MAX_CURSOR_LENGTH = 512;
const MAX_CONVERSATION_ID_LENGTH = 128;
const SAFE_CURSOR = /^[A-Za-z0-9._~-]+$/;
const SAFE_CONVERSATION_ID = /^[A-Za-z0-9_-]+$/;

function requirePlainObject(value, label) {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new IntentValidationError(`${label} must be an object.`);
  }
  return value;
}

function rejectUnknownKeys(value, allowedKeys, label) {
  const unknown = Object.keys(value).filter((key) => !allowedKeys.has(key));
  if (unknown.length > 0) {
    throw new IntentValidationError(`${label} contains unsupported field ${unknown[0]}.`);
  }
}

function normalizePageQuery(query) {
  if (query === undefined) return {};
  requirePlainObject(query, 'Operation query');
  rejectUnknownKeys(query, new Set(['limit', 'cursor']), 'Operation query');

  const normalized = {};
  if (query.limit !== undefined) {
    if (!Number.isSafeInteger(query.limit) || query.limit < 1 || query.limit > MAX_PAGE_LIMIT) {
      throw new IntentValidationError(
        `Operation query limit must be an integer from 1 through ${MAX_PAGE_LIMIT}.`,
      );
    }
    normalized.limit = String(query.limit);
  }
  if (query.cursor !== undefined && query.cursor !== null) {
    if (
      typeof query.cursor !== 'string' ||
      query.cursor.length < 1 ||
      query.cursor.length > MAX_CURSOR_LENGTH ||
      !SAFE_CURSOR.test(query.cursor)
    ) {
      throw new IntentValidationError('Operation query cursor is not a safe opaque token.');
    }
    normalized.cursor = query.cursor;
  }
  return normalized;
}

const DEFINITIONS = Object.freeze({
  identity: {
    pathPattern: /^\/api2\/v2\/users\/me\/?$/,
    buildPath() {
      return '/api2/v2/users/me';
    },
    expectedJsonKey: 'id',
    expectedKind: 'present',
    boundary: null,
    validateParameters(parameters) {
      requirePlainObject(parameters, 'identity parameters');
      rejectUnknownKeys(parameters, new Set(), 'identity parameters');
      return {};
    },
  },
  conversations: {
    pathPattern: /^\/api2\/v2\/chats\/?$/,
    buildPath() {
      return '/api2/v2/chats';
    },
    expectedJsonKey: 'list',
    expectedKind: 'array',
    boundary: 'inventory_end',
    validateParameters(parameters) {
      requirePlainObject(parameters, 'conversations parameters');
      rejectUnknownKeys(parameters, new Set(['query']), 'conversations parameters');
      return { query: normalizePageQuery(parameters.query) };
    },
  },
  'message-page': {
    pathPattern: /^\/api2\/v2\/chats\/[^/]+\/messages\/?$/,
    buildPath(parameters) {
      const conversationId = parameters.conversationId;
      if (
        typeof conversationId !== 'string' ||
        conversationId.length < 1 ||
        conversationId.length > MAX_CONVERSATION_ID_LENGTH ||
        !SAFE_CONVERSATION_ID.test(conversationId)
      ) {
        throw new IntentValidationError('message-page requires an alphanumeric conversationId.');
      }
      return `/api2/v2/chats/${encodeURIComponent(conversationId)}/messages`;
    },
    expectedJsonKey: 'messages',
    expectedKind: 'array',
    boundary: 'history_start',
    validateParameters(parameters) {
      requirePlainObject(parameters, 'message-page parameters');
      rejectUnknownKeys(
        parameters,
        new Set(['conversationId', 'query']),
        'message-page parameters',
      );
      const conversationId = parameters.conversationId;
      if (
        typeof conversationId !== 'string' ||
        conversationId.length < 1 ||
        conversationId.length > MAX_CONVERSATION_ID_LENGTH ||
        !SAFE_CONVERSATION_ID.test(conversationId)
      ) {
        throw new IntentValidationError('message-page requires an alphanumeric conversationId.');
      }
      return { conversationId, query: normalizePageQuery(parameters.query) };
    },
  },
});

export function getOperation(name) {
  const definition = DEFINITIONS[name];
  if (!definition) {
    throw new IntentValidationError(
      `Unknown operation ${name}. Expected one of: ${Object.keys(DEFINITIONS).join(', ')}.`,
    );
  }
  return definition;
}

export function buildOperationRequest(name, parameters = {}) {
  const definition = getOperation(name);
  const normalized = definition.validateParameters(parameters);
  const url = new URL(definition.buildPath(normalized), ORIGIN);
  const query = normalized.query ?? {};
  for (const [key, value] of Object.entries(query)) url.searchParams.set(key, value);
  return { operation: name, method: 'GET', url };
}

export function matchesOperation(name, rawUrl, method = 'GET') {
  if (method.toUpperCase() !== 'GET') return false;
  const url = new URL(rawUrl);
  return url.origin === ORIGIN && getOperation(name).pathPattern.test(url.pathname);
}

export function expectedResponse(name) {
  const definition = getOperation(name);
  return {
    key: definition.expectedJsonKey,
    kind: definition.expectedKind,
    boundary: definition.boundary,
  };
}

export {
  DEFINITIONS,
  MAX_CURSOR_LENGTH,
  MAX_PAGE_LIMIT,
  ORIGIN,
  SAFE_CURSOR,
};
