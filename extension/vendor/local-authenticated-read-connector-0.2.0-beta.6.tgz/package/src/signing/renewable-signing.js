import { assertAllowedHeader } from './header-policy.js';
import { DEFINITIONS, matchesOperation } from './operations.js';

export const RENEWABLE_SIGNING_SCHEMA = 'local-renewable-signing-config/v1';

const DYNAMIC_HEADERS = new Set(['sign', 'time', 'user-id']);
const REQUIRED_STATIC_HEADERS = ['app-token', 'x-bc', 'x-of-rev'];

function validateFormat(format) {
  if (
    !format ||
    typeof format.prefix !== 'string' ||
    format.prefix.length === 0 ||
    format.prefix.includes(':') ||
    typeof format.suffix !== 'string' ||
    format.suffix.length === 0 ||
    format.suffix.includes(':') ||
    !Array.isArray(format.checksum_indexes) ||
    format.checksum_indexes.length === 0 ||
    !Number.isSafeInteger(format.checksum_constant)
  ) {
    throw new TypeError('Renewable signing format is invalid.');
  }
  for (const index of format.checksum_indexes) {
    if (!Number.isSafeInteger(index) || index < 0 || index >= 40) {
      throw new TypeError('Checksum indexes must address a SHA-1 hexadecimal digest.');
    }
  }
  return Object.freeze({
    prefix: format.prefix,
    suffix: format.suffix,
    checksumIndexes: Object.freeze([...format.checksum_indexes]),
    checksumConstant: format.checksum_constant,
  });
}

export function validateRenewableSigningConfig(config) {
  if (
    !config ||
    config.schema !== RENEWABLE_SIGNING_SCHEMA ||
    typeof config.source_revision !== 'string' ||
    config.source_revision.length === 0 ||
    typeof config.static_param !== 'string' ||
    config.static_param.length === 0 ||
    config.static_param.includes('\n') ||
    typeof config.headers !== 'object' ||
    config.headers === null ||
    Array.isArray(config.headers)
  ) {
    throw new TypeError('Renewable signing configuration is invalid.');
  }

  const headers = {};
  for (const [name, value] of Object.entries(config.headers)) {
    const normalized = assertAllowedHeader(name, 'Renewable adapter header');
    if (DYNAMIC_HEADERS.has(normalized)) {
      throw new TypeError(`Dynamic header must not be stored in renewable configuration: ${name}.`);
    }
    if (typeof value !== 'string' || value.length === 0) {
      throw new TypeError(`Renewable adapter header ${name} must be a non-empty string.`);
    }
    headers[normalized] = value;
  }
  for (const name of REQUIRED_STATIC_HEADERS) {
    if (!Object.hasOwn(headers, name)) {
      throw new TypeError(`Renewable signing configuration is missing ${name}.`);
    }
  }
  if (headers['x-of-rev'] !== config.source_revision) {
    throw new TypeError('Signing source revision does not match x-of-rev.');
  }

  return Object.freeze({
    schema: config.schema,
    sourceRevision: config.source_revision,
    staticParam: config.static_param,
    format: validateFormat(config.format),
    headers: Object.freeze(headers),
  });
}

export function validateSigningSession(session) {
  if (!session || typeof session.userId !== 'string' || !/^\d+$/.test(session.userId)) {
    throw new TypeError('Renewable signing requires a numeric session userId.');
  }
  return session.userId;
}

export function validateSigningRequest(method, url) {
  if (!(url instanceof URL) || typeof method !== 'string' || method.toUpperCase() !== 'GET') {
    throw new TypeError('Renewable signing accepts typed GET operations only.');
  }
  const supported = Object.keys(DEFINITIONS).some((operation) => matchesOperation(operation, url, method));
  if (!supported) {
    throw new TypeError('Renewable signing request is outside the typed read-operation boundary.');
  }
}

export function createSigningInput({ config, path, timestamp, userId }) {
  if (typeof path !== 'string' || !path.startsWith('/api2/v2/')) {
    throw new TypeError('Signing path is invalid.');
  }
  if (typeof timestamp !== 'string' || !/^\d+$/.test(timestamp)) {
    throw new TypeError('Signing timestamp is invalid.');
  }
  if (typeof userId !== 'string' || !/^\d+$/.test(userId)) {
    throw new TypeError('Signing user ID is invalid.');
  }
  return [config.staticParam, timestamp, path, userId].join('\n');
}

export function createSignatureFromDigest({ config, digest }) {
  if (typeof digest !== 'string' || !/^[0-9a-f]{40}$/i.test(digest)) {
    throw new TypeError('Signing digest must be a SHA-1 hexadecimal value.');
  }
  const checksum = Math.abs(
    config.format.checksumIndexes.reduce(
      (sum, index) => sum + digest.charCodeAt(index),
      config.format.checksumConstant,
    ),
  ).toString(16);
  return [config.format.prefix, digest.toLowerCase(), checksum, config.format.suffix].join(':');
}

export function createPortableRenewableAdapter({ config, sha1Hex }) {
  if (typeof sha1Hex !== 'function') throw new TypeError('A SHA-1 digest provider is required.');
  const validated = validateRenewableSigningConfig(config);
  return {
    id: 'runtime-derived-renewable-signing',
    async prepare({ method, url, session, now }) {
      validateSigningRequest(method, url);
      const userId = validateSigningSession(session);
      const currentTime = now();
      if (!Number.isSafeInteger(currentTime) || currentTime <= 0) {
        throw new TypeError('Renewable signing clock returned an invalid timestamp.');
      }
      const timestamp = String(currentTime);
      const path = `${url.pathname}${url.search}`;
      const input = createSigningInput({
        config: validated,
        path,
        timestamp,
        userId,
      });
      const digest = await sha1Hex(input);
      const sign = createSignatureFromDigest({ config: validated, digest });
      return {
        headers: {
          ...validated.headers,
          'user-id': userId,
          time: timestamp,
          sign,
        },
        controlHeaders: ['sign'],
        diagnostics: {
          revision: validated.sourceRevision,
          checksumIndexCount: validated.format.checksumIndexes.length,
        },
      };
    },
  };
}

export async function webCryptoSha1Hex(input, cryptoApi = globalThis.crypto) {
  if (!cryptoApi?.subtle) throw new Error('Web Crypto SHA-1 support is unavailable.');
  const digest = await cryptoApi.subtle.digest('SHA-1', new TextEncoder().encode(input));
  return [...new Uint8Array(digest)]
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('');
}
