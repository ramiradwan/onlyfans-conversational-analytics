import { AtomicSigningGenerationStore } from './generation-store.js';

const DEFAULT_KEY = 'browser_signing_state_v1';

function callChrome(chromeApi, receiver, method, args) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      const error = chromeApi?.runtime?.lastError;
      if (error) reject(new Error(error.message));
      else resolve(value);
    };
    try {
      const returned = method.call(receiver, ...args, finish);
      if (returned?.then) returned.then(finish, reject);
    } catch (error) {
      reject(error);
    }
  });
}

export function createChromeSigningPersistence({
  chromeApi = globalThis.chrome,
  storageArea = chromeApi?.storage?.local,
  key = DEFAULT_KEY,
} = {}) {
  if (!storageArea?.get || !storageArea?.set) {
    throw new TypeError('chrome.storage.local is required for signing persistence.');
  }
  return {
    async load() {
      const saved = await callChrome(chromeApi, storageArea, storageArea.get, [[key]]);
      return saved?.[key] ?? null;
    },
    async save(value) {
      await callChrome(chromeApi, storageArea, storageArea.set, [{ [key]: value }]);
    },
  };
}

export async function restrictSigningStorageToTrustedContexts(chromeApi = globalThis.chrome) {
  const storageArea = chromeApi?.storage?.local;
  if (!storageArea?.setAccessLevel) return false;
  await callChrome(chromeApi, storageArea, storageArea.setAccessLevel, [
    { accessLevel: 'TRUSTED_CONTEXTS' },
  ]);
  return true;
}

export function createChromeSigningGenerationStore(options = {}) {
  return new AtomicSigningGenerationStore({
    persistence: options.persistence ?? createChromeSigningPersistence(options),
    now: options.now,
    idFactory: options.idFactory,
  });
}

export { DEFAULT_KEY as CHROME_SIGNING_STATE_KEY };
