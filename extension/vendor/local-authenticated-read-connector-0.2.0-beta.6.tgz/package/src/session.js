import { SessionError } from './errors.js';

export class StaticSessionProvider {
  #session;

  constructor(session) {
    this.#session = Object.freeze({ ...session });
  }

  async current() {
    if (
      typeof this.#session.sessionId !== 'string' ||
      this.#session.sessionId.length === 0 ||
      typeof this.#session.creatorAccountId !== 'string' ||
      this.#session.creatorAccountId.length === 0
    ) {
      throw new SessionError('No valid local authenticated session is available.');
    }
    return this.#session;
  }
}
