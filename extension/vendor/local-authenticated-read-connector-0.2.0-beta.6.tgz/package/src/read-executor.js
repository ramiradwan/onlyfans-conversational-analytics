import {
  AuthorizationError,
  IntentValidationError,
  UpstreamResponseError,
} from './errors.js';

function validateIntent(intent) {
  if (!intent || (intent.method ?? 'GET').toUpperCase() !== 'GET') {
    throw new IntentValidationError('Only GET read intents are accepted.');
  }
  if (intent.body !== undefined && intent.body !== null) {
    throw new IntentValidationError('Read intents cannot contain a request body.');
  }
  if (typeof intent.path !== 'string' || !intent.path.startsWith('/api/read/')) {
    throw new IntentValidationError('The path is outside the allowed read namespace.');
  }
  if (intent.path.includes('..') || intent.path.includes('://') || intent.path.includes('@')) {
    throw new IntentValidationError('The path contains a forbidden component.');
  }
  if (intent.path.includes('?') || intent.path.includes('#') || intent.path.includes('\\')) {
    throw new IntentValidationError('Query, fragment, and backslash components must not be embedded in the path.');
  }
}

function makeUrl(origin, intent) {
  const url = new URL(intent.path, origin);
  if (url.origin !== origin.origin || !url.pathname.startsWith('/api/read/')) {
    throw new IntentValidationError('The normalized destination is outside the allowed read namespace.');
  }
  for (const [key, rawValue] of Object.entries(intent.query ?? {})) {
    if (rawValue === undefined || rawValue === null) continue;
    const values = Array.isArray(rawValue) ? rawValue : [rawValue];
    for (const value of values) url.searchParams.append(key, String(value));
  }
  return url;
}

export class AuthenticatedReadExecutor {
  #origin;
  #sessionProvider;
  #configProvider;
  #authorizationAdapter;
  #transport;
  #now;

  constructor({
    origin,
    sessionProvider,
    configProvider,
    authorizationAdapter,
    transport = fetch,
    now = Date.now,
  }) {
    this.#origin = new URL(origin);
    this.#sessionProvider = sessionProvider;
    this.#configProvider = configProvider;
    if (!authorizationAdapter || typeof authorizationAdapter.prepare !== 'function') {
      throw new AuthorizationError('An authorization adapter is required.');
    }
    this.#authorizationAdapter = authorizationAdapter;
    this.#transport = transport;
    this.#now = now;
  }

  async execute(intent) {
    validateIntent(intent);
    const session = await this.#sessionProvider.current();
    const url = makeUrl(this.#origin, intent);

    const first = await this.#send({ url, session, config: await this.#configProvider.get() });
    if (first.status !== 401 || first.body?.code !== 'authorization_revision_stale') {
      return this.#unwrap(first);
    }

    const refreshed = await this.#configProvider.refresh();
    const second = await this.#send({ url, session, config: refreshed });
    if (second.status === 401) {
      throw new AuthorizationError(
        `Upstream authorization failed after one configuration refresh: ${second.body?.code ?? 'unknown'}.`,
      );
    }
    return this.#unwrap(second);
  }

  async #send({ url, session, config }) {
    const prepared = await this.#authorizationAdapter.prepare({
      method: 'GET',
      url,
      session,
      config,
      now: this.#now,
    });
    if (!prepared || typeof prepared.headers !== 'object' || prepared.headers === null) {
      throw new AuthorizationError('Authorization adapter returned an invalid prepared request.');
    }
    const response = await this.#transport(url, { method: 'GET', headers: prepared.headers });
    let body = null;
    try {
      body = await response.json();
    } catch (cause) {
      throw new UpstreamResponseError('Upstream returned a non-JSON response.', { cause });
    }
    return { status: response.status, body };
  }

  #unwrap(result) {
    if (result.status === 401) {
      throw new AuthorizationError(`Upstream authorization failed: ${result.body?.code ?? 'unknown'}.`);
    }
    if (result.status < 200 || result.status >= 300) {
      throw new UpstreamResponseError(
        `Upstream read failed with status ${result.status}: ${result.body?.code ?? 'unknown'}.`,
      );
    }
    return result.body;
  }
}
