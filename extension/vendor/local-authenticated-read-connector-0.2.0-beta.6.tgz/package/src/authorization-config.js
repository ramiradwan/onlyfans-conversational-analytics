import { AuthorizationError } from './errors.js';

function validateBaseConfig(config) {
  if (
    !config ||
    typeof config.revision !== 'string' ||
    config.revision.length === 0 ||
    typeof config.issuedAt !== 'string' ||
    Number.isNaN(Date.parse(config.issuedAt))
  ) {
    throw new AuthorizationError('Authorization configuration failed validation.');
  }
  return Object.freeze({ ...config });
}

export class InMemoryAuthorizationRegistry {
  #current;
  #validate;

  constructor(initialConfig, { validate = validateBaseConfig } = {}) {
    this.#validate = validate;
    this.#current = this.#validate(initialConfig);
  }

  current() {
    return this.#current;
  }

  rotate(nextConfig) {
    const validated = this.#validate(nextConfig);
    if (validated.revision === this.#current.revision) {
      throw new AuthorizationError('A revision must identify immutable configuration content.');
    }
    this.#current = validated;
    return this.#current;
  }
}

export class CachedAuthorizationConfigProvider {
  #fetchCurrent;
  #validate;
  #cached = null;
  #refreshing = null;

  constructor(fetchCurrent, { validate = validateBaseConfig } = {}) {
    this.#fetchCurrent = fetchCurrent;
    this.#validate = validate;
  }

  async get() {
    if (!this.#cached) await this.refresh();
    return this.#cached;
  }

  async refresh() {
    if (!this.#refreshing) {
      this.#refreshing = Promise.resolve()
        .then(() => this.#fetchCurrent())
        .then((config) => this.#validate(config))
        .then((config) => {
          this.#cached = config;
          return config;
        })
        .finally(() => {
          this.#refreshing = null;
        });
    }
    return this.#refreshing;
  }

  cachedRevision() {
    return this.#cached?.revision ?? null;
  }
}

export { validateBaseConfig };
