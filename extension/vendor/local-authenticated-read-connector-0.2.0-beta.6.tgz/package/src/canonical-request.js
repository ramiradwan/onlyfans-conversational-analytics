import { createHmac, timingSafeEqual } from 'node:crypto';

import { AuthorizationError, IntentValidationError } from './errors.js';

const HEADER_NAMES = Object.freeze({
  revision: 'x-local-auth-revision',
  issuedAt: 'x-local-auth-time',
  sessionId: 'x-local-auth-session',
  signature: 'x-local-auth-signature',
});

function encode(value) {
  return encodeURIComponent(value).replace(/[!'()*]/g, (character) =>
    `%${character.charCodeAt(0).toString(16).toUpperCase()}`,
  );
}

export function canonicalQuery(searchParams) {
  return [...searchParams.entries()]
    .sort(([leftKey, leftValue], [rightKey, rightValue]) =>
      leftKey.localeCompare(rightKey) || leftValue.localeCompare(rightValue),
    )
    .map(([key, value]) => `${encode(key)}=${encode(value)}`)
    .join('&');
}

export function canonicalRequest({ method, url, issuedAt, sessionId, revision }) {
  const parsed = url instanceof URL ? url : new URL(url);
  return [
    method.toUpperCase(),
    parsed.pathname,
    canonicalQuery(parsed.searchParams),
    String(issuedAt),
    sessionId,
    revision,
  ].join('\n');
}

export function signPreparedRequest({ method, url, sessionId, config, now = Date.now }) {
  if (method.toUpperCase() !== 'GET') {
    throw new IntentValidationError('The authorization adapter accepts GET requests only.');
  }
  if (!config || typeof config.revision !== 'string' || typeof config.secret !== 'string') {
    throw new AuthorizationError('Authorization configuration is invalid.');
  }

  const issuedAt = now();
  const canonical = canonicalRequest({
    method,
    url,
    issuedAt,
    sessionId,
    revision: config.revision,
  });
  const signature = createHmac('sha256', config.secret).update(canonical).digest('hex');

  return {
    [HEADER_NAMES.revision]: config.revision,
    [HEADER_NAMES.issuedAt]: String(issuedAt),
    [HEADER_NAMES.sessionId]: sessionId,
    [HEADER_NAMES.signature]: signature,
  };
}

export function verifyPreparedRequest({ method, url, headers, config, maximumAgeMs, now = Date.now }) {
  const revision = headers.get(HEADER_NAMES.revision);
  const issuedAtText = headers.get(HEADER_NAMES.issuedAt);
  const sessionId = headers.get(HEADER_NAMES.sessionId);
  const suppliedSignature = headers.get(HEADER_NAMES.signature);

  if (!revision || !issuedAtText || !sessionId || !suppliedSignature) {
    return { ok: false, code: 'authorization_missing' };
  }
  if (revision !== config.revision) {
    return { ok: false, code: 'authorization_revision_stale' };
  }

  const issuedAt = Number(issuedAtText);
  if (!Number.isSafeInteger(issuedAt) || Math.abs(now() - issuedAt) > maximumAgeMs) {
    return { ok: false, code: 'authorization_expired' };
  }

  const canonical = canonicalRequest({ method, url, issuedAt, sessionId, revision });
  const expected = createHmac('sha256', config.secret).update(canonical).digest();
  let supplied;
  try {
    supplied = Buffer.from(suppliedSignature, 'hex');
  } catch {
    return { ok: false, code: 'authorization_invalid' };
  }

  if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
    return { ok: false, code: 'authorization_invalid' };
  }

  return { ok: true, sessionId };
}

export { HEADER_NAMES };
