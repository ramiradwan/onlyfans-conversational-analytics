# Renewable signing adapter

`renewable-signing.js` is the Node hashing wrapper for the package's portable renewable-signing implementation. It prepares typed read operations from private runtime-derived rules and separate private session context.

The browser-safe provider is exported as `local-authenticated-read-connector/browser-signing`. Private signing rules, captures, and session context must remain outside source control. See `docs/specs/renewable-signing-adapter.md` in this package for the configuration and refresh contract.
