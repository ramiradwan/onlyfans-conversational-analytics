# Development authorization adapters

Adapters in this directory are local research modules loaded by `dev:prepare`.

The included adapters are:

- `renewable-signing.js` generates fresh `time` and `sign` values locally from a private runtime-derived rule configuration and a separate private session context. It accepts typed read operations only.
- `captured-header-replay.js` accepts a private browser-capture artifact, binds replay to the exact captured method/path/query, and uses `sign` as a negative control when present.
- `static-header-set.js` accepts an explicit private header configuration for contract and shape checks.

Put raw values, captures, signing configuration, and session context beneath `.local/`, never in source control. Browser-managed, credential-bearing, CSRF, and security transport headers are rejected centrally. See the [renewable signing specification](../docs/specs/renewable-signing-adapter.md) for the extraction and refresh workflow.

The reusable browser-safe implementation is exported as `local-authenticated-read-connector/browser-signing`. The adapter in this directory is its Node hashing wrapper for the development harness.
