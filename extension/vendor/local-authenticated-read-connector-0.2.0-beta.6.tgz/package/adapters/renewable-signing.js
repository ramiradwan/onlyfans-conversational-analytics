import { createHash } from 'node:crypto';

import {
  createPortableRenewableAdapter,
  createSignatureFromDigest,
  createSigningInput,
  validateRenewableSigningConfig,
} from '../src/signing/renewable-signing.js';

function nodeSha1Hex(input) {
  return createHash('sha1').update(input).digest('hex');
}

export function createRequestSignature({ config, path, timestamp, userId }) {
  const input = createSigningInput({ config, path, timestamp, userId });
  return createSignatureFromDigest({ config, digest: nodeSha1Hex(input) });
}

export function createAdapter({ config }) {
  return createPortableRenewableAdapter({ config, sha1Hex: nodeSha1Hex });
}

export {
  RENEWABLE_SIGNING_SCHEMA,
  validateRenewableSigningConfig,
} from '../src/signing/renewable-signing.js';
